﻿# PartTimer — Database Schema Design (MongoDB + Mongoose)

This document describes the **actual MongoDB collections** (often called “tables” in reports) and their **attributes/fields** as implemented in the backend Mongoose models.

MongoDB is **schema-flexible**, but in this project the schema is defined through Mongoose in `backend/models`.

## What is ObjectId?

`ObjectId` is MongoDB’s default **unique identifier type**.

- Every document automatically has an `_id` of type `ObjectId` (unless you override it).
- In reports, you can treat `_id` as the **Primary Key (PK)**.
- When another collection stores an `ObjectId` that points to a different document’s `_id` (via Mongoose `ref`), it behaves like a **Foreign Key (FK-like reference)**.

Example value (looks like a 24-hex string): `507f1f77bcf86cd799439011`

Important (MongoDB vs SQL): MongoDB does **not** enforce FK constraints automatically. So the application should validate that referenced IDs actually exist when needed.

## Embedded vs Referenced (important for ERD)

- **Embedded fields** (objects/arrays stored inside the same document) do **not** create new collections.
  - Example: `Job.company`, `Job.payment`, `Job.applicationDetails`, and `Application.statusHistory[]`.
- **Referenced fields** are `ObjectId` values that point to another collection’s `_id`.
  - Example: `Application.job` → `Job._id` and `Job.employerId` → `User._id`.

Note: In `ER_DIAGRAM.md`, embedded objects (like the user profile fields) are sometimes shown as **flattened fields** under the parent entity so that all attributes are visible in a report.

## ERD flattened field mapping (report-friendly)

This section maps the **flattened ERD attribute names** (used in `ER_DIAGRAM.md`) to the **actual MongoDB document paths** (as stored in Mongoose).

| ERD (flattened) field name        | Real document path                                                                           |
| --------------------------------- | -------------------------------------------------------------------------------------------- |
| `profile_common_phone`            | `user.profile.common.phone`                                                                  |
| `profile_common_location`         | `user.profile.common.location`                                                               |
| `profile_common_gender`           | `user.profile.common.gender`                                                                 |
| `profile_common_birthDate`        | `user.profile.common.birthDate`                                                              |
| `profile_common_usePrideAvatar`   | `user.profile.common.usePrideAvatar`                                                         |
| `profile_common_avatarPreset`     | `user.profile.common.avatarPreset`                                                           |
| `profile_common_bio`              | `user.profile.common.bio`                                                                    |
| `employerProfile_companyName`     | `user.employerProfile.companyName` (mirrored in `user.profile.employer.companyName`)         |
| `employerProfile_industry`        | `user.employerProfile.industry` (mirrored in `user.profile.employer.industry`)               |
| `employerProfile_city`            | `user.employerProfile.city` (mirrored in `user.profile.employer.city`)                       |
| `employerProfile_state`           | `user.employerProfile.state` (mirrored in `user.profile.employer.state`)                     |
| `employerProfile_website`         | `user.employerProfile.website` (mirrored in `user.profile.employer.website`)                 |
| `employerProfile_about`           | `user.employerProfile.about` (mirrored in `user.profile.employer.about`)                     |
| `employerProfile_companyLocation` | `user.employerProfile.companyLocation` (mirrored in `user.profile.employer.companyLocation`) |
| `jobSeekerProfile_headline`       | `user.jobSeekerProfile.headline` (mirrored in `user.profile.jobseeker.headline`)             |
| `jobSeekerProfile_city`           | `user.jobSeekerProfile.city` (mirrored in `user.profile.jobseeker.city`)                     |
| `jobSeekerProfile_state`          | `user.jobSeekerProfile.state` (mirrored in `user.profile.jobseeker.state`)                   |
| `jobSeekerProfile_skills[]`       | `user.jobSeekerProfile.skills[]` (mirrored in `user.profile.jobseeker.skills[]`)             |
| `jobSeekerProfile_education`      | `user.jobSeekerProfile.education` (mirrored in `user.profile.jobseeker.education`)           |
| `jobSeekerProfile_experience`     | `user.jobSeekerProfile.experience` (mirrored in `user.profile.jobseeker.experience`)         |
| `jobSeekerProfile_portfolioUrl`   | `user.jobSeekerProfile.portfolioUrl` (mirrored in `user.profile.jobseeker.portfolioUrl`)     |
| `moderation_isLocked`             | `user.moderation.isLocked`                                                                   |
| `moderation_lockedUntil`          | `user.moderation.lockedUntil`                                                                |
| `moderation_message`              | `user.moderation.message`                                                                    |
| `moderation_reason`               | `user.moderation.reason`                                                                     |
| `moderation_lockedAt`             | `user.moderation.lockedAt`                                                                   |
| `moderation_lockedBy`             | `user.moderation.lockedBy`                                                                   |
| `moderation_warningMessage`       | `user.moderation.warningMessage`                                                             |
| `moderation_warnedAt`             | `user.moderation.warnedAt`                                                                   |
| `moderation_warnedBy`             | `user.moderation.warnedBy`                                                                   |
| `company_name`                    | `job.company.name`                                                                           |
| `company_industry`                | `job.company.industry`                                                                       |
| `company_city`                    | `job.company.city`                                                                           |
| `company_state`                   | `job.company.state`                                                                          |
| `payment_amount`                  | `job.payment.amount`                                                                         |
| `payment_type`                    | `job.payment.type`                                                                           |
| `applicationDetails_openings`     | `job.applicationDetails.openings`                                                            |
| `applicationDetails_lastDate`     | `job.applicationDetails.lastDate`                                                            |
| `statusHistory_status`            | `application.statusHistory[].status`                                                         |
| `statusHistory_changedAt`         | `application.statusHistory[].changedAt`                                                      |
| `statusHistory_changedBy`         | `application.statusHistory[].changedBy`                                                      |

Tip: In Mongoose, referenced fields are usually defined like:

- `type: mongoose.Schema.Types.ObjectId, ref: "User"`

And you can fetch the referenced document using `populate()` in code.

## Collections Overview

- `User`
- `Job`
- `Application`
- `Activity`

All collections use Mongoose `{ timestamps: true }`, so `createdAt` and `updatedAt` are automatically stored.

---

## 1) User Collection

**Purpose:** Stores authentication + role + profile details and admin moderation status.

**Fields**

| Field              | Type     | Constraints                                                            |
| ------------------ | -------- | ---------------------------------------------------------------------- |
| `_id`              | ObjectId | Primary identifier (auto-generated)                                    |
| `name`             | String   | **required**                                                           |
| `email`            | String   | **required**, **unique**                                               |
| `password`         | String   | **required**                                                           |
| `role`             | String   | **required**, enum: `admin`, `employer`, `jobseeker`                   |
| `profilePhotoPath` | String   | optional (local server path, e.g. `/uploads/...`)                      |
| `resumePdfPath`    | String   | required for jobseeker profile updates (PDF path, e.g. `/uploads/...`) |
| `profile`          | Object   | embedded profile object (common + role-specific)                       |
| `employerProfile`  | Object   | legacy/compatibility copy (employer fields)                            |
| `jobSeekerProfile` | Object   | legacy/compatibility copy (jobseeker fields)                           |
| `moderation`       | Object   | admin warn/lock state + messages                                       |
| `createdAt`        | Date     | auto (timestamps)                                                      |
| `updatedAt`        | Date     | auto (timestamps)                                                      |

Note (platform rule): Although MongoDB stores many profile fields with defaults, PartTimer enforces **mandatory profile completion** at the API/controller layer when saving profiles.

**Embedded profile objects (implemented)**

Top-level embedded object: `profile`

- `profile.common` (shared fields)
- `profile.jobseeker` (jobseeker fields)
- `profile.employer` (employer fields)

The project also keeps `employerProfile` and `jobSeekerProfile` in sync for backward compatibility with older frontend shapes.

Common profile (`profile.common`):

| Field                           | Type    | Constraints                                                    |
| ------------------------------- | ------- | -------------------------------------------------------------- |
| `profile.common.phone`          | String  | required for profile updates (validated)                       |
| `profile.common.location`       | String  | required for profile updates (validated)                       |
| `profile.common.gender`         | String  | required for profile updates (enum: `male`, `female`, `other`) |
| `profile.common.birthDate`      | String  | required for profile updates (validated)                       |
| `profile.common.usePrideAvatar` | Boolean | optional preference (not required)                             |
| `profile.common.avatarPreset`   | String  | optional preference (not required)                             |
| `profile.common.bio`            | String  | required for profile updates (validated)                       |

Note: The items below (like `employerProfile.companyName`, `jobSeekerProfile.skills`, etc.) are **nested fields inside embedded objects** stored within the same `User` document. They are not separate collections/tables and not separate top-level fields. In code you access them via dot-notation (example: `user.jobSeekerProfile.skills`).

Employer profile (`profile.employer` and mirrored to `employerProfile`):

| Field                             | Type   | Constraints                                       |
| --------------------------------- | ------ | ------------------------------------------------- |
| `employerProfile.companyName`     | String | required for employer profile updates (validated) |
| `employerProfile.industry`        | String | required for employer profile updates (validated) |
| `employerProfile.city`            | String | required for employer profile updates (validated) |
| `employerProfile.state`           | String | required for employer profile updates (validated) |
| `employerProfile.website`         | String | required for employer profile updates (validated) |
| `employerProfile.companyLocation` | String | required for employer profile updates (validated) |
| `employerProfile.about`           | String | required for employer profile updates (validated) |

Jobseeker profile (`profile.jobseeker` and mirrored to `jobSeekerProfile`):

| Field                           | Type     | Constraints                                                    |
| ------------------------------- | -------- | -------------------------------------------------------------- |
| `jobSeekerProfile.headline`     | String   | required for jobseeker profile updates (validated)             |
| `jobSeekerProfile.city`         | String   | required for jobseeker profile updates (validated)             |
| `jobSeekerProfile.state`        | String   | required for jobseeker profile updates (validated)             |
| `jobSeekerProfile.skills`       | [String] | required for jobseeker profile updates (validated; at least 1) |
| `jobSeekerProfile.education`    | String   | required for jobseeker profile updates (validated)             |
| `jobSeekerProfile.experience`   | String   | required for jobseeker profile updates (validated)             |
| `jobSeekerProfile.portfolioUrl` | String   | required for jobseeker profile updates (validated)             |

**Local image storage (implemented)**

- Profile photos are stored in a server folder (example: `backend/uploads/`).
- MongoDB stores only a string path like `profilePhotoPath: "/uploads/jobseekers/U2/photo.jpg"`.
- If a user does not upload a photo, the UI shows a **default placeholder avatar**.

**Resume PDF storage (implemented)**

- Jobseeker resumes are uploaded as PDF files and stored under `backend/uploads/`.
- MongoDB stores only a string path like `resumePdfPath: "/uploads/resumes/jobseeker/<userId>/resume-<timestamp>.pdf"`.

---

## 2) Job Collection

**Purpose:** Stores job postings created by employers.

**Fields**

| Field                         | Type     | Constraints                                                       |
| ----------------------------- | -------- | ----------------------------------------------------------------- |
| `_id`                         | ObjectId | Primary identifier (auto-generated)                               |
| `title`                       | String   | required for create/full update (validated)                       |
| `jobType`                     | String   | required for create/full update (validated)                       |
| `locationType`                | String   | required for create/full update (validated)                       |
| `duration`                    | String   | required for create/full update (validated)                       |
| `status`                      | String   | enum: `Active`, `Closed` (default: `Active`)                      |
| `company.name`                | String   | **required**                                                      |
| `company.industry`            | String   | required for create/full update (validated)                       |
| `company.city`                | String   | required for create/full update (validated)                       |
| `company.state`               | String   | required for create/full update (validated)                       |
| `payment.amount`              | String   | **required**                                                      |
| `payment.type`                | String   | **required**                                                      |
| `description`                 | String   | required for create/full update (validated)                       |
| `responsibilities`            | [String] | required for create/full update (validated; at least 1)           |
| `requirements`                | [String] | required for create/full update (validated; at least 1)           |
| `skills`                      | [String] | required for create/full update (validated; at least 1)           |
| `applicationDetails.openings` | Number   | required for create/full update (validated; >= 1)                 |
| `applicationDetails.lastDate` | String   | required for create/full update (validated)                       |
| `expiresAt`                   | Date     | required for create/full update (TTL auto-delete after this time) |
| `employerId`                  | ObjectId | references `User` (employer)                                      |
| `createdAt`                   | Date     | auto (timestamps)                                                 |
| `updatedAt`                   | Date     | auto (timestamps)                                                 |

**Relationship**

- One `User` (role = employer) can post many `Job` documents via `Job.employerId`.

**Auto removal (implemented)**

- Jobs are configured to **auto-delete after a specific date/time** using `Job.expiresAt`.
- This is implemented via a MongoDB **TTL index** on `expiresAt`.
- Note: TTL deletion is performed by MongoDB in the background (not necessarily exactly at the second).

---

## 3) Application Collection

**Purpose:** Stores job applications submitted by jobseekers.

**Fields**

| Field             | Type             | Constraints                                                  |
| ----------------- | ---------------- | ------------------------------------------------------------ |
| `_id`             | ObjectId         | Primary identifier (auto-generated)                          |
| `job`             | ObjectId         | **required**, references `Job`                               |
| `jobSeeker`       | ObjectId         | **required**, references `User` (jobseeker)                  |
| `status`          | String           | enum: `Applied`, `Accepted`, `Rejected` (default: `Applied`) |
| `statusHistory[]` | Array of objects | embedded history entries (see below)                         |
| `createdAt`       | Date             | auto (timestamps)                                            |
| `updatedAt`       | Date             | auto (timestamps)                                            |

**Embedded sub-document: `statusHistory[]` items**

| Field                       | Type     | Constraints                             |
| --------------------------- | -------- | --------------------------------------- |
| `statusHistory[].status`    | String   | enum: `Applied`, `Accepted`, `Rejected` |
| `statusHistory[].changedAt` | Date     | default: `Date.now`                     |
| `statusHistory[].changedBy` | ObjectId | references `User`                       |

**Indexes / Rules**

- **Unique compound index:** `(job, jobSeeker)` must be unique.
  - Meaning: the same jobseeker cannot apply twice to the same job.

**Relationships**

- One `Job` can have many `Application` documents.
- One `User` (jobseeker) can create many `Application` documents.

---

## 4) Activity Collection

**Purpose:** Activity tracking/audit log for important actions.

**Fields**

| Field         | Type     | Constraints                             |
| ------------- | -------- | --------------------------------------- |
| `_id`         | ObjectId | Primary identifier (auto-generated)     |
| `type`        | String   | **required**, enum values listed below  |
| `user`        | ObjectId | **required**, references `User` (actor) |
| `targetUser`  | ObjectId | optional, references `User`             |
| `job`         | ObjectId | optional, references `Job`              |
| `application` | ObjectId | optional, references `Application`      |
| `description` | String   | **required**                            |
| `metadata`    | Mixed    | optional                                |
| `createdAt`   | Date     | auto (timestamps)                       |
| `updatedAt`   | Date     | auto (timestamps)                       |

Note: `targetUser`, `job`, `application`, and `metadata` are optional because they are included **only when relevant** to the activity type.

**Activity `type` enum values**

- `user_registered`
- `profile_updated`
- `job_posted`
- `job_updated`
- `job_closed`
- `application_submitted`
- `application_accepted`
- `application_rejected`
- `user_warned`
- `user_locked`
- `user_unlocked`

**Indexes**

- `{ user: 1, createdAt: -1 }`
- `{ type: 1, createdAt: -1 }`
- `{ createdAt: -1 }`

---

## PK/FK (How to write it in your report)

- **PK:** `_id` is the primary identifier in each collection.
- **FK-like fields (references):**
  - `Job.employerId` → `User._id`
  - `Application.job` → `Job._id`
  - `Application.jobSeeker` → `User._id`
  - `Application.statusHistory.changedBy` → `User._id`
  - `Activity.user` → `User._id`
  - `Activity.targetUser` → `User._id`
  - `Activity.job` → `Job._id`
  - `Activity.application` → `Application._id`

Note: MongoDB does **not** enforce FK constraints automatically; the app code should validate references when needed.

---

## Sample Documents (JSON)

These examples show how documents look in MongoDB (including embedded objects/arrays). IDs below are sample `ObjectId` values.

### User (Employer)

```json
{
  "_id": "6745c0a2d1f0e2a9b3c6d101",
  "name": "Asha Patil",
  "email": "asha@company.com",
  "password": "<hashed-password>",
  "role": "employer",
  "createdAt": "2025-12-20T10:15:00.000Z",
  "updatedAt": "2025-12-20T10:15:00.000Z"
}
```

### User (Jobseeker)

```json
{
  "_id": "6745c0a2d1f0e2a9b3c6d102",
  "name": "Rahul Sharma",
  "email": "rahul@gmail.com",
  "password": "<hashed-password>",
  "role": "jobseeker",
  "createdAt": "2025-12-21T09:00:00.000Z",
  "updatedAt": "2025-12-21T09:00:00.000Z"
}
```

### Job

```json
{
  "_id": "6745c0a2d1f0e2a9b3c6d201",
  "title": "Part-Time Barista",
  "jobType": "Part-Time",
  "locationType": "On-site",
  "duration": "3 months",
  "status": "Active",
  "company": {
    "name": "Cafe Aroma",
    "industry": "Food & Beverage",
    "city": "Pune",
    "state": "MH"
  },
  "payment": {
    "amount": "15000",
    "type": "Monthly"
  },
  "description": "Looking for a friendly barista for evening shifts.",
  "responsibilities": ["Prepare beverages", "Handle billing"],
  "requirements": ["Basic communication"],
  "skills": ["Coffee brewing", "Customer service"],
  "applicationDetails": {
    "openings": 2,
    "lastDate": "2025-12-31"
  },
  "employerId": "6745c0a2d1f0e2a9b3c6d101",
  "createdAt": "2025-12-21T12:30:00.000Z",
  "updatedAt": "2025-12-21T12:30:00.000Z"
}
```

### Application

```json
{
  "_id": "6745c0a2d1f0e2a9b3c6d301",
  "job": "6745c0a2d1f0e2a9b3c6d201",
  "jobSeeker": "6745c0a2d1f0e2a9b3c6d102",
  "status": "Applied",
  "statusHistory": [
    {
      "status": "Applied",
      "changedAt": "2025-12-22T08:10:00.000Z",
      "changedBy": "6745c0a2d1f0e2a9b3c6d102"
    }
  ],
  "createdAt": "2025-12-22T08:10:00.000Z",
  "updatedAt": "2025-12-22T08:10:00.000Z"
}
```

### Activity

```json
{
  "_id": "6745c0a2d1f0e2a9b3c6d401",
  "type": "application_submitted",
  "user": "6745c0a2d1f0e2a9b3c6d102",
  "targetUser": "6745c0a2d1f0e2a9b3c6d101",
  "job": "6745c0a2d1f0e2a9b3c6d201",
  "application": "6745c0a2d1f0e2a9b3c6d301",
  "description": "Jobseeker submitted an application.",
  "metadata": {
    "source": "web"
  },
  "createdAt": "2025-12-22T08:11:00.000Z",
  "updatedAt": "2025-12-22T08:11:00.000Z"
}
```

---

## Roles & Access Control (Current Implementation)

The User.role field controls access in the backend using JWT + role middleware.

- admin: can access admin endpoints for dashboard stats and user lists, and can view all activities via activity endpoints.
- employer: can create/manage jobs and review applications for their jobs.
- jobseeker: can browse jobs and apply, and view their own applications.

Admin moderation is implemented via warn/lock/unlock endpoints, backed by the `User.moderation` subdocument and enforced in auth middleware.
