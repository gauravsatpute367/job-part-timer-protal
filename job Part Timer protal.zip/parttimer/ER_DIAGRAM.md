﻿# PartTimer — ER Diagram (Based on Backend Schemas)

This ERD reflects the actual MongoDB/Mongoose schemas in `backend/models`.

## What is ObjectId?

In MongoDB, `ObjectId` is the default type used for document IDs.

- Every document has an `_id: ObjectId` (auto-generated). In ER diagrams, you can treat `_id` as **PK**.
- When a field stores an `ObjectId` that references another collection’s `_id` (using Mongoose `ref`), we mark it as **FK** in the ERD.
- MongoDB does **not** enforce FK constraints at the database level (unlike SQL). These are “FK-like references”.

```mermaid
erDiagram
  USER {
    ObjectId _id PK
    string name
    string email UK
    string password
    string role "admin|employer|jobseeker"
    %% Implemented: embedded profile objects + local photo path
    string profilePhotoPath
    %% Implemented: jobseeker resume PDF upload
    string resumePdfPath
    %% Embedded profile fields (flattened here for report/ERD clarity)
    %% Stored inside USER as embedded objects (not separate collections)
    string profile_common_phone
    string profile_common_location
    string profile_common_gender
    string profile_common_birthDate
    boolean profile_common_usePrideAvatar
    string profile_common_avatarPreset
    string profile_common_bio

    %% Employer profile (embedded; also mirrored in profile.employer)
    string employerProfile_companyName
    string employerProfile_industry
    string employerProfile_city
    string employerProfile_state
    string employerProfile_website
    string employerProfile_about
    string employerProfile_companyLocation

    %% Jobseeker profile (embedded; also mirrored in profile.jobseeker)
    string jobSeekerProfile_headline
    string jobSeekerProfile_city
    string jobSeekerProfile_state
    string jobSeekerProfile_skills[]
    string jobSeekerProfile_education
    string jobSeekerProfile_experience
    string jobSeekerProfile_portfolioUrl

    %% Moderation (embedded; flattened for report/ERD clarity)
    boolean moderation_isLocked
    datetime moderation_lockedUntil
    string moderation_message
    string moderation_reason
    datetime moderation_lockedAt
    ObjectId moderation_lockedBy FK
    string moderation_warningMessage
    datetime moderation_warnedAt
    ObjectId moderation_warnedBy FK
    datetime createdAt
    datetime updatedAt
  }

  JOB {
    ObjectId _id PK
    string title
    string jobType
    string locationType
    string duration
    string status "Active|Closed"

    string company_name
    string company_industry
    string company_city
    string company_state

    string payment_amount
    string payment_type

    string description
    string responsibilities[]
    string requirements[]
    string skills[]

    int applicationDetails_openings
    string applicationDetails_lastDate

    %% TTL-based auto removal (expiresAt required for new/edited jobs)
    datetime expiresAt

    ObjectId employerId FK
    datetime createdAt
    datetime updatedAt
  }

  APPLICATION {
    ObjectId _id PK
    ObjectId job FK
    ObjectId jobSeeker FK
    string status "Applied|Accepted|Rejected"
    %% Embedded array: statusHistory[] (flattened for report/ERD clarity)
    string statusHistory_status
    datetime statusHistory_changedAt
    ObjectId statusHistory_changedBy FK
    datetime createdAt
    datetime updatedAt
  }

  ACTIVITY {
    ObjectId _id PK
    string type "user_registered|profile_updated|job_posted|job_updated|job_closed|application_submitted|application_accepted|application_rejected|user_warned|user_locked|user_unlocked"
    ObjectId user FK
    ObjectId targetUser FK
    ObjectId job FK
    ObjectId application FK
    string description
    mixed metadata
    datetime createdAt
    datetime updatedAt
  }

  %% Relationships
  USER ||--o{ JOB : "posts (employerId)"
  JOB  ||--o{ APPLICATION : "receives"
  USER ||--o{ APPLICATION : "submits (jobSeeker)"

  USER ||--o{ ACTIVITY : "logs (user)"
  USER ||--o{ ACTIVITY : "targetUser (optional)"
  JOB ||--o{ ACTIVITY : "job (optional)"
  APPLICATION ||--o{ ACTIVITY : "application (optional)"
```

## Notes

- **MongoDB Collections (actual tables):** `User`, `Job`, `Application`, `Activity` (4 total).
- **Implemented:** User profiles for employer/jobseeker are stored as **embedded fields inside `User`** (no new collections). Profile photo + resume PDF are stored on the server (MongoDB stores only the local file path).
- **ERD note:** Embedded objects are sometimes **flattened** above (for example: profile fields, moderation fields, and `Application.statusHistory[]`) purely to make all attributes visible in a report/ER diagram. In the real MongoDB documents, these remain embedded objects/arrays.
- If `profilePhotoPath` is empty/not provided, the UI shows a default placeholder avatar.
- Jobseeker profiles require a resume upload for profile completion; legacy data may still have an empty `resumePdfPath`.
- Profile field details (inside `employerProfile` and `jobSeekerProfile`) are documented in `SCHEMA_DESIGN.md`.
- `JOB.company`, `JOB.payment`, and `JOB.applicationDetails` are embedded sub-documents in MongoDB; they’re flattened above just to display clearly in the ERD.
- `JOB.expiresAt` is used for TTL-based auto removal; job posts require it (legacy data may still have it empty).
- `APPLICATION.statusHistory[]` is an embedded array of sub-documents (stored inside the `Application` document). It’s not a separate collection/table.
- `ACTIVITY.metadata` is kept as `mixed` because it can store arbitrary JSON depending on the activity.
- `ACTIVITY.targetUser`, `ACTIVITY.job`, and `ACTIVITY.application` are optional references depending on the activity type.
- `APPLICATION` enforces a unique constraint on `(job, jobSeeker)` to prevent duplicate applications for the same job.

## PK/FK clarification (MongoDB + Mongoose)

In this project you didn’t explicitly “assign” PK/FK the way you would in SQL while defining tables, because MongoDB works differently:

- **Primary Key (PK):** MongoDB automatically creates an `_id` field for every document in every collection. That `_id` is the PK.
- **Foreign Key (FK):** MongoDB does **not** enforce FK constraints at the database level. However, in Mongoose, any field defined as `ObjectId` with `ref: "SomeModel"` is a **reference** to another collection and is treated as an FK-like field in an ER diagram.

So when you draw an ERD for this project:

- Mark `_id` as **PK** for each entity (`User`, `Job`, `Application`, `Activity`).
- Mark these as **FK** (because they reference another entity’s `_id`):
  - `Job.employerId` → `User._id`
  - `Application.job` → `Job._id`
  - `Application.jobSeeker` → `User._id`
  - `Application.statusHistory.changedBy` → `User._id`
  - `Activity.user`, `Activity.targetUser` → `User._id`
  - `Activity.job` → `Job._id`
  - `Activity.application` → `Application._id`

Tip: If a reference field is not `required: true` in the schema, label it as “optional FK” in your explanation.

---

## Sample IDs (How relationships connect)

Example `ObjectId` values showing how the references link entities:

```text
User (employer) _id        = 6745c0a2d1f0e2a9b3c6d101
User (jobseeker) _id       = 6745c0a2d1f0e2a9b3c6d102
Job _id                    = 6745c0a2d1f0e2a9b3c6d201
Job.employerId             = 6745c0a2d1f0e2a9b3c6d101   -> User (employer)
Application _id            = 6745c0a2d1f0e2a9b3c6d301
Application.job            = 6745c0a2d1f0e2a9b3c6d201   -> Job
Application.jobSeeker      = 6745c0a2d1f0e2a9b3c6d102   -> User (jobseeker)
Activity.application       = 6745c0a2d1f0e2a9b3c6d301   -> Application
Activity.job               = 6745c0a2d1f0e2a9b3c6d201   -> Job
Activity.user              = 6745c0a2d1f0e2a9b3c6d102   -> User (actor)
Activity.targetUser        = 6745c0a2d1f0e2a9b3c6d101   -> User (target)
```

For full field-by-field schema details and sample JSON documents, see `SCHEMA_DESIGN.md`.

---

## Admin role (what exists today)

Admin is not a separate collection/table. Admin is a User with role = admin.

Current backend supports:

- Admin dashboard stats (counts of employers/jobseekers/jobs/applications)
- Viewing employer and jobseeker lists (with counts)
- Viewing all activities (activity log)

Admin moderation endpoints exist for warning, locking and unlocking users.
