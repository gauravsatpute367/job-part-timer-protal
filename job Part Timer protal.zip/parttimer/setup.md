# PartTimer — Setup Guide (Windows)

This guide walks you through running **PartTimer** locally (backend + frontend).

## Prerequisites

- **Node.js** (recommended: latest LTS)
- **npm** (bundled with Node)
- **MongoDB** (local install, or MongoDB Atlas connection string)

## 1) Install dependencies

Open **PowerShell** in the project root.

### One-command dev (recommended)

PartTimer uses **two apps**:

- `backend/` (Express API)
- `frontend/` (Vite React app)

So there are **multiple `package.json` files**. A root-level `package.json` is added only to run **both apps together**.

From the project root:

```powershell
npm install
npm run dev
```

This starts backend + frontend together.

### Backend

```powershell
cd .\backend
npm install
```

### Frontend

```powershell
cd ..\frontend
npm install
```

## 2) Configure environment variables (backend)

Copy `backend/.env.example` to `backend/.env`, then fill in values.

If you prefer creating it manually, use:

```env
# Mongo connection string
MONGO_URI=mongodb://127.0.0.1:27017/parttimer

# JWT signing secret (choose a strong random string)
JWT_SECRET=replace_with_a_long_random_secret
```

Notes:

- `MONGO_URI` is required by `backend/config/db.js`.
- `JWT_SECRET` is required for login/token verification.

## 3) Run the backend API

From the `backend` folder:

```powershell
npm run dev
```

Backend runs on:

- `http://localhost:5000`

Quick check:

- Visit `http://localhost:5000/` and you should see: `PartTimer Backend Running`

## 4) Run the frontend

Open a second terminal.

```powershell
cd .\frontend
npm run dev
```

Vite will print the local dev URL (commonly):

- `http://localhost:5173`

## 5) API endpoints used by the frontend

The current frontend login uses a hard-coded API URL:

- `http://localhost:5000/api/auth/login`

So you must have the backend running on port **5000**.

## Notes (uploads + auto-remove jobs)

- **Uploads:** Profile photos and resume PDFs are stored under `backend/uploads/` and served by the backend at the `/uploads` path.
- **Auto-remove jobs:** Jobs require an `expiresAt` timestamp (auto-remove date). MongoDB uses a **TTL index** to auto-delete expired jobs in the background (not instant to the second).

## Common issues

- **MongoDB connection failed**

  - Make sure MongoDB is running.
  - Verify `MONGO_URI` in `backend/.env`.

- **Token invalid / Not authorized**

  - Ensure the backend has `JWT_SECRET` set.
  - If you changed `JWT_SECRET`, clear localStorage in the browser and log in again.

- **Port already in use (5000)**
  - Stop the other process using port 5000, then re-run `npm run dev`.

## Recommended workflow

- Option A (one command): project root → `npm run dev`
- Option B (two terminals):
  - Terminal 1: `backend` → `npm run dev`
  - Terminal 2: `frontend` → `npm run dev`
