import { Link, useNavigate, useLocation } from "react-router-dom";
import { isLoggedIn } from "../utils/auth";

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();

  const loggedIn = isLoggedIn();
  const userName = localStorage.getItem("userName");

  const handleDashboardClick = () => {
    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
      return;
    }

    navigate("/dashboard");
  };

  const handleLoginClick = () => {
    navigate("/login", {
      state: { from: location.pathname },
    });
  };

  return (
    <nav className="bg-white border-b border-gray-200 fixed top-0 left-0 w-full z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-6">
          {/* Logo */}
          <Link to="/" className="text-2xl font-extrabold text-orange-500">
            PartTimer
          </Link>

          {/* Links (beside logo) */}
          <div className="hidden md:flex items-center gap-6 text-gray-700 font-medium">
            <Link to="/" className="hover:text-orange-500">
              Home
            </Link>
            <Link to="/jobs" className="hover:text-orange-500">
              Browse Jobs
            </Link>
          </div>
        </div>

        {/* Middle stays blank */}
        <div className="flex-1" />

        <div className="flex items-center gap-3">
          {/* Login/Username (beside dashboard) */}
          <div className="hidden md:flex items-center gap-3">
            {!loggedIn && (
              <button
                className="hover:text-orange-500 cursor-pointer text-gray-700 font-medium"
                onClick={handleLoginClick}
              >
                Login
              </button>
            )}

            {loggedIn && (
              <span className="text-sm bg-orange-100 text-orange-700 px-2 py-1 rounded">
                {userName}
              </span>
            )}
          </div>

          {/* CTA */}
          <button
            onClick={handleDashboardClick}
            className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
          >
            Dashboard
          </button>
        </div>
      </div>
    </nav>
  );
}
