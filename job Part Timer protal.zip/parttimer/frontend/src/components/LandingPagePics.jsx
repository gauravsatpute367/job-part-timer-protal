import { useEffect, useRef, useState } from "react";

const images = [
  "/LandingImages/LandingImages-illu-img1.jpg",
  "/LandingImages/LandingImages-illu-img2.jpeg",
  "/LandingImages/LandingImages-illu-img3.jpg",
  "/LandingImages/LandingImages-illu-img4.jpg",
  "/LandingImages/LandingImages-illu-img5.jpg",
];

export default function LandingPagePics() {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(true);
  const lockRef = useRef(false); // 🔒 prevent rapid triggers

  // 🔹 slow auto-play (VERY calm)
  useEffect(() => {
    const timer = setInterval(() => {
      // eslint-disable-next-line react-hooks/immutability
      changeImage(1);
    }, 5000); // ⏱️ 5 seconds (slow)

    return () => clearInterval(timer);
  }, []);

  const changeImage = (direction) => {
    if (lockRef.current) return; // block spam
    lockRef.current = true;

    setVisible(false); // fade out
    setTimeout(() => {
      setIndex((prev) => {
        if (direction === 1) return (prev + 1) % images.length;
        return prev === 0 ? images.length - 1 : prev - 1;
      });
      setVisible(true); // fade in
    }, 600);

    setTimeout(() => {
      lockRef.current = false;
    }, 1200); // allow next interaction after animation
  };

  // 🖱️ mouse wheel ONLY (no hover)
  const handleWheel = (e) => {
    if (e.deltaY > 0) changeImage(1);
    else changeImage(-1);
  };

  return (
    <div
      className="w-full h-full flex items-center justify-center"
      onWheel={handleWheel}
    >
      <img
        src={images[index]}
        alt="Landing visuals"
        className={`h-full max-h-72 object-contain rounded-xl transition-opacity duration-700 ${
          visible ? "opacity-100" : "opacity-0"
        }`}
      />
    </div>
  );
}
