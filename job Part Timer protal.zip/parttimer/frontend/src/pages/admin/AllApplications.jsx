import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function AdminAllApplications() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [payload, setPayload] = useState(null);

  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token) {
      setError("Please login to view applications");
      setLoading(false);
      return;
    }

    if (role !== "admin") {
      setError("Access denied. Admin only.");
      setLoading(false);
      return;
    }

    const run = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(
          "http://localhost:5000/api/auth/admin/applications",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load applications");
        setPayload(data);
      } catch (err) {
        setError(err?.message || "Failed to load applications");
      } finally {
        setLoading(false);
      }
    };

    run();
  }, []);

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">All Applications</h1>
            <p className="text-gray-600 mt-1">
              All applications submitted on PartTimer
            </p>
          </div>

          <button
            onClick={() => navigate(-1)}
            className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            Back
          </button>
        </div>

        <div className="bg-white rounded-xl shadow overflow-x-auto">
          {loading && (
            <p className="p-6 text-gray-500">Loading applications...</p>
          )}
          {error && <p className="p-6 text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full border-collapse">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-4 text-left">No.</th>
                  <th className="p-4 text-left">Applied At</th>
                  <th className="p-4 text-left">Applicant</th>
                  <th className="p-4 text-left">Job</th>
                  <th className="p-4 text-left">Status</th>
                  <th className="p-4 text-left">Action</th>
                </tr>
              </thead>
              <tbody>
                {(payload?.applications || []).map((app, index) => (
                  <tr key={app._id} className="border-t">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 whitespace-nowrap">
                      {app.createdAt ? formatDateTime(app.createdAt) : "—"}
                    </td>
                    <td className="p-4">
                      <div className="font-medium">
                        {app.jobSeeker?.name || "—"}
                      </div>
                      <div className="text-sm text-gray-500">
                        {app.jobSeeker?.email || ""}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-medium">{app.job?.title || "—"}</div>
                      <div className="text-sm text-gray-500">
                        {app.job?.company?.name || ""}
                      </div>
                    </td>
                    <td className="p-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          app.status === "Accepted"
                            ? "bg-green-100 text-green-700"
                            : app.status === "Rejected"
                            ? "bg-red-100 text-red-700"
                            : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {app.status || "Applied"}
                      </span>
                    </td>
                    <td className="p-4">
                      <Link
                        to={`/jobs/${app.job?._id}`}
                        className="text-orange-600 font-semibold hover:underline"
                      >
                        View Job
                      </Link>
                    </td>
                  </tr>
                ))}

                {Array.isArray(payload?.applications) &&
                  payload.applications.length === 0 && (
                    <tr>
                      <td colSpan="6" className="p-6 text-center text-gray-500">
                        No applications found.
                      </td>
                    </tr>
                  )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
