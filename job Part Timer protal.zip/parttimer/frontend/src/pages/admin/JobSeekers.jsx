import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function AdminJobSeekers() {
  const [jobSeekers, setJobSeekers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");
    if (!token) {
      setError("Please login to view job seekers");
      setLoading(false);
      return;
    }

    if (role !== "admin") {
      setError("Access denied. Admin only.");
      setLoading(false);
      return;
    }

    // Wrap in async function to avoid synchronous setState
    const fetchJobSeekers = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(
          "http://localhost:5000/api/auth/admin/jobseekers",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();

        if (Array.isArray(data)) {
          setJobSeekers(data);
        } else {
          setError(data.message || "Failed to load job seekers");
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchJobSeekers();
  }, []);

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* ===== HEADER ===== */}
        <div>
          <h1 className="text-3xl font-bold">Job Seekers</h1>
          <p className="text-gray-600 mt-1">
            List of all registered job seekers on PartTimer
          </p>
        </div>

        {/* ===== JOB SEEKERS TABLE ===== */}
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          {loading && (
            <p className="p-6 text-gray-500">Loading job seekers...</p>
          )}
          {error && <p className="p-6 text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full border-collapse">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-4 text-left">No.</th>
                  <th className="p-4 text-left">Name</th>
                  <th className="p-4 text-left">Email</th>
                  <th className="p-4 text-left">Applications</th>
                  <th className="p-4 text-left">Action</th>
                </tr>
              </thead>

              <tbody>
                {jobSeekers.map((js, index) => (
                  <tr key={js._id} className="border-t">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 font-medium">{js.name}</td>
                    <td className="p-4">{js.email}</td>
                    <td className="p-4">{js.applications}</td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-x-4 gap-y-2">
                        <Link
                          to={`/users/${js._id}/profile`}
                          className="text-orange-600 font-semibold hover:underline"
                        >
                          View Profile
                        </Link>
                        <Link
                          to={`/admin/jobseekers/${js._id}/applications`}
                          className="text-blue-600 font-semibold hover:underline"
                        >
                          View Applications
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}

                {jobSeekers.length === 0 && (
                  <tr>
                    <td colSpan="5" className="p-6 text-center text-gray-500">
                      No job seekers found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
