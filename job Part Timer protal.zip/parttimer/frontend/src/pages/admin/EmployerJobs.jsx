import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

export default function AdminEmployerJobs() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [payload, setPayload] = useState(null);

  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token) {
      setError("Please login to view jobs");
      setLoading(false);
      return;
    }

    if (role !== "admin") {
      setError("Access denied. Admin only.");
      setLoading(false);
      return;
    }

    const run = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(
          `http://localhost:5000/api/auth/admin/employers/${id}/jobs`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to load jobs");
        setPayload(data);
      } catch (err) {
        setError(err?.message || "Failed to load jobs");
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [id]);

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Employer Jobs</h1>
            <p className="text-gray-600 mt-1">
              {payload?.employer?.name
                ? `${payload.employer.name} • ${payload.employer.email || ""}`
                : "Jobs posted by this employer"}
            </p>
          </div>

          <div className="flex gap-3">
            <Link
              to={`/users/${id}/profile`}
              className="border border-orange-500 text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-orange-50 transition"
            >
              View Profile
            </Link>
            <button
              onClick={() => navigate(-1)}
              className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Back
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow overflow-x-auto">
          {loading && <p className="p-6 text-gray-500">Loading jobs...</p>}
          {error && <p className="p-6 text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full border-collapse">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-4 text-left">No.</th>
                  <th className="p-4 text-left">Posted At</th>
                  <th className="p-4 text-left">Title</th>
                  <th className="p-4 text-left">Company</th>
                  <th className="p-4 text-left">Job Status</th>
                  <th className="p-4 text-left">Applications</th>
                  <th className="p-4 text-left">Action</th>
                </tr>
              </thead>
              <tbody>
                {(payload?.jobs || []).map((job, index) => (
                  <tr key={job._id} className="border-t">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 whitespace-nowrap">
                      {job.createdAt ? formatDateTime(job.createdAt) : "—"}
                    </td>
                    <td className="p-4 font-medium">{job.title || "—"}</td>
                    <td className="p-4">{job.company?.name || "—"}</td>
                    <td className="p-4">{job.status || "—"}</td>
                    <td className="p-4">{job.applications ?? 0}</td>
                    <td className="p-4">
                      <Link
                        to={`/jobs/${job._id}`}
                        className="text-orange-600 font-semibold hover:underline"
                      >
                        View Job
                      </Link>
                    </td>
                  </tr>
                ))}

                {Array.isArray(payload?.jobs) && payload.jobs.length === 0 && (
                  <tr>
                    <td colSpan="7" className="p-6 text-center text-gray-500">
                      No jobs found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
