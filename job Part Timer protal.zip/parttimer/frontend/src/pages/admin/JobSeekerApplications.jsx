import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

export default function AdminJobSeekerApplications() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [payload, setPayload] = useState(null);

  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token) {
      setError("Please login to view applications");
      setLoading(false);
      return;
    }

    if (role !== "admin") {
      setError("Access denied. Admin only.");
      setLoading(false);
      return;
    }

    const run = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(
          `http://localhost:5000/api/auth/admin/jobseekers/${id}/applications`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load applications");
        setPayload(data);
      } catch (err) {
        setError(err?.message || "Failed to load applications");
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [id]);

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Job Seeker Applications</h1>
            <p className="text-gray-600 mt-1">
              {payload?.jobSeeker?.name
                ? `${payload.jobSeeker.name} • ${payload.jobSeeker.email || ""}`
                : "Applications submitted by this job seeker"}
            </p>
          </div>

          <div className="flex gap-3">
            <Link
              to={`/users/${id}/profile`}
              className="border border-orange-500 text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-orange-50 transition"
            >
              View Profile
            </Link>
            <button
              onClick={() => navigate(-1)}
              className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Back
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow overflow-x-auto">
          {loading && (
            <p className="p-6 text-gray-500">Loading applications...</p>
          )}
          {error && <p className="p-6 text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full border-collapse">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-4 text-left">No.</th>
                  <th className="p-4 text-left">Applied At</th>
                  <th className="p-4 text-left">Job</th>
                  <th className="p-4 text-left">Company</th>
                  <th className="p-4 text-left">Job Status</th>
                  <th className="p-4 text-left">Application Status</th>
                  <th className="p-4 text-left">Action</th>
                </tr>
              </thead>
              <tbody>
                {(payload?.applications || []).map((app, index) => (
                  <tr key={app._id} className="border-t">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 whitespace-nowrap">
                      {app.createdAt ? formatDateTime(app.createdAt) : "—"}
                    </td>
                    <td className="p-4 font-medium">{app.job?.title || "—"}</td>
                    <td className="p-4">{app.job?.company?.name || "—"}</td>
                    <td className="p-4">{app.job?.status || "—"}</td>
                    <td className="p-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          app.status === "Accepted"
                            ? "bg-green-100 text-green-700"
                            : app.status === "Rejected"
                            ? "bg-red-100 text-red-700"
                            : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {app.status || "Applied"}
                      </span>
                    </td>
                    <td className="p-4">
                      {app.job?._id ? (
                        <Link
                          to={`/jobs/${app.job._id}`}
                          className="text-orange-600 font-semibold hover:underline"
                        >
                          View Job
                        </Link>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                ))}

                {Array.isArray(payload?.applications) &&
                  payload.applications.length === 0 && (
                    <tr>
                      <td colSpan="7" className="p-6 text-center text-gray-500">
                        No applications found.
                      </td>
                    </tr>
                  )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
