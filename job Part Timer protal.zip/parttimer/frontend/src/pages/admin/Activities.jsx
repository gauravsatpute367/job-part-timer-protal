import { useEffect, useMemo, useState } from "react";

export default function AdminActivities() {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!token) {
      setError("Please login to view activities");
      setLoading(false);
      return;
    }

    if (role !== "admin") {
      setError("Access denied. Admin only.");
      setLoading(false);
      return;
    }

    const fetchActivities = async () => {
      setLoading(true);
      setError("");

      try {
        const limit = 200;
        const res = await fetch(
          `http://localhost:5000/api/activities?limit=${limit}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load activities");

        setActivities(Array.isArray(data) ? data : []);
      } catch (err) {
        setError(err?.message || "Failed to load activities");
      } finally {
        setLoading(false);
      }
    };

    fetchActivities();
  }, [formatDateTime]);

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Activity Log</h1>
            <p className="text-gray-600 mt-1">
              Monitor all platform activities (admin)
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow overflow-x-auto max-h-[70vh] overflow-y-auto">
          {loading && (
            <p className="p-6 text-gray-500">Loading activities...</p>
          )}
          {error && <p className="p-6 text-red-600">{error}</p>}

          {!loading && !error && (
            <table className="w-full border-collapse">
              <thead className="bg-gray-100 sticky top-0 z-10">
                <tr>
                  <th className="p-4 text-left">No.</th>
                  <th className="p-4 text-left">Time</th>
                  <th className="p-4 text-left">Type</th>
                  <th className="p-4 text-left">Performer</th>
                  <th className="p-4 text-left">Company</th>
                  <th className="p-4 text-left">Job</th>
                  <th className="p-4 text-left">Description</th>
                </tr>
              </thead>

              <tbody>
                {activities.map((a, index) => (
                  <tr key={a._id} className="border-t align-top">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 whitespace-nowrap">
                      {a.createdAt ? formatDateTime(a.createdAt) : "—"}
                    </td>
                    <td className="p-4 whitespace-nowrap">
                      <span className="px-2 py-1 rounded bg-gray-100 text-gray-700 text-xs font-semibold">
                        {a.type || "—"}
                      </span>
                    </td>
                    <td className="p-4">
                      {a.user?.name ? (
                        <div className="space-y-1">
                          <div className="font-medium">{a.user.name}</div>
                          <div className="text-xs text-gray-500">
                            {a.user.role || ""}
                          </div>
                        </div>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="p-4">
                      {a.job?.company?.name || a.metadata?.company || "—"}
                    </td>
                    <td className="p-4">
                      {a.job?.title ? (
                        <div className="space-y-1">
                          <div className="font-medium">{a.job.title}</div>
                          <div className="text-xs text-gray-500">
                            {a.job.company?.name || ""}
                          </div>
                        </div>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="p-4">{a.description || "—"}</td>
                  </tr>
                ))}

                {activities.length === 0 && (
                  <tr>
                    <td colSpan="7" className="p-6 text-center text-gray-500">
                      No activities found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
