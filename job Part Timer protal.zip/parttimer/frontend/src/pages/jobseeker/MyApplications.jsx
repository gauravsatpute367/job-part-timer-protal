import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function MyApplications() {
  const navigate = useNavigate();

  const [appliedJobs, setAppliedJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Date formatter for Asia/Kolkata
  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  useEffect(() => {
    const role = localStorage.getItem("role");
    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login", { state: { from: "/jobseeker/my-applications" } });
      return;
    }

    if (role !== "jobseeker") {
      setError("Access denied. Job seeker only.");
      return;
    }

    const fetchAppliedJobs = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(
          "http://localhost:5000/api/applications/my-applications",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.message || "Failed to load applications");
        }

        setAppliedJobs(Array.isArray(data) ? data : []);
      } catch (err) {
        setError(err.message || "Failed to load applications");
      } finally {
        setLoading(false);
      }
    };

    fetchAppliedJobs();
  }, [navigate]);

  return (
    <div className="pt-24 p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">My Applications</h1>
          <p className="text-gray-600 mt-1">
            Track your applied jobs and application status
          </p>
        </div>

        <Link
          to="/dashboard"
          className="border border-gray-300 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
        >
          Back to Dashboard
        </Link>
      </div>

      <div className="bg-white rounded-xl shadow overflow-x-auto">
        {loading && (
          <p className="p-6 text-gray-500">Loading applications...</p>
        )}
        {error && <p className="p-6 text-red-600">{error}</p>}

        {!loading && !error && (
          <table className="w-full border-collapse">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 text-left">Job Title</th>
                <th className="p-4 text-left">Company</th>
                <th className="p-4 text-left">Applied Date</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left">Action</th>
              </tr>
            </thead>

            <tbody>
              {appliedJobs.map((app) => (
                <tr key={app._id} className="border-t">
                  <td className="p-4 font-medium">{app.job?.title || "N/A"}</td>
                  <td className="p-4">{app.job?.company?.name || "N/A"}</td>
                  <td className="p-4">{formatDateTime(app.createdAt)}</td>

                  <td className="p-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        app.status === "Accepted"
                          ? "bg-green-100 text-green-700"
                          : app.status === "Rejected"
                          ? "bg-red-100 text-red-700"
                          : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {app.status}
                    </span>
                  </td>

                  <td className="p-4">
                    <Link
                      to={`/jobseeker/applications/${app._id}`}
                      className="text-orange-600 font-medium hover:underline"
                    >
                      View Details
                    </Link>
                  </td>
                </tr>
              ))}

              {appliedJobs.length === 0 && (
                <tr>
                  <td colSpan="5" className="p-6 text-center text-gray-500">
                    You have not applied to any jobs yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
