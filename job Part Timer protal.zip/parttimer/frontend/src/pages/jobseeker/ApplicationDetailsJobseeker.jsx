import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { formatDate, formatDateTime } from "../../utils/date";

export default function AppliedJobDetails() {
  const { id } = useParams();
  const [application, setApplication] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchApplication = async () => {
      const token = localStorage.getItem("token");

      if (!token) {
        setError("Please login to view application details");
        setLoading(false);
        return;
      }

      setLoading(true);
      setError("");

      try {
        const url = `http://localhost:5000/api/applications/${id}`;
        console.log("Fetching application from:", url);

        const res = await fetch(url, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        console.log("Response status:", res.status);
        const data = await res.json();
        console.log("Application data:", data);

        if (!res.ok) {
          throw new Error(data.message || `HTTP error! status: ${res.status}`);
        }

        setApplication(data);
      } catch (err) {
        console.error("Error:", err);
        setError(err.message || "Failed to load application");
      } finally {
        setLoading(false);
      }
    };

    fetchApplication();
  }, [id]);

  if (loading) {
    return (
      <div className="pt-24 px-6 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading application...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pt-24 px-6 min-h-screen">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
            <h2 className="text-xl font-bold text-red-700 mb-2">
              Error Loading Application
            </h2>
            <p className="text-red-600">{error}</p>
          </div>
          <Link
            to="/dashboard"
            className="inline-block bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  if (!application) {
    return (
      <div className="pt-24 px-6 min-h-screen">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-gray-600 mb-6">Application not found</p>
          <Link
            to="/dashboard"
            className="inline-block bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const applicationId = `PT-APP-${application._id.slice(-6).toUpperCase()}`;
  const lastUpdated = formatDateTime(
    application.updatedAt || application.createdAt
  );

  // Format payment properly (it's an object with {amount, type})
  const formatPayment = (payment) => {
    if (!payment) return "N/A";
    if (typeof payment === "string") return payment;
    if (payment.amount && payment.type) {
      return `₹${payment.amount} ${payment.type}`;
    }
    return "N/A";
  };

  const statusMessage =
    application.status === "Accepted"
      ? "Congratulations! You have been selected for this job."
      : application.status === "Rejected"
      ? "Unfortunately, your application was not selected."
      : "Your application is under review. Please wait for employer response.";

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* ===== HEADER ===== */}
        <div>
          <h1 className="text-3xl font-bold">
            {application.job?.title || "N/A"}
          </h1>
          <p className="text-gray-600 mt-1">
            {application.job?.company?.name || "N/A"}
          </p>
        </div>

        {/* ===== APPLICATION SUMMARY ===== */}
        <div className="bg-white rounded-xl shadow p-6 space-y-3">
          <p>
            <strong>Application ID:</strong> {applicationId}
          </p>

          <p>
            <strong>Applied On:</strong> {formatDate(application.createdAt)}
          </p>

          <p>
            <strong>Status:</strong>
            <span
              className={`ml-2 px-3 py-1 rounded-full text-sm font-medium ${
                application.status === "Accepted"
                  ? "bg-green-100 text-green-700"
                  : application.status === "Rejected"
                  ? "bg-red-100 text-red-700"
                  : "bg-blue-100 text-blue-700"
              }`}
            >
              {application.status}
            </span>
          </p>
        </div>

        {/* ===== STATUS MESSAGE ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <p className="text-gray-700">{statusMessage}</p>
        </div>

        {/* ===== APPLICATION METADATA ===== */}
        <div className="bg-white rounded-xl shadow p-6 space-y-2">
          <h2 className="text-xl font-semibold mb-2">Application Details</h2>

          <p>
            <strong>Current Status:</strong> {application.status}
          </p>

          <p>
            <strong>Last Updated:</strong> {lastUpdated}
          </p>

          <p className="text-sm text-gray-500">
            Status updates are managed by the employer.
          </p>
        </div>

        {/* ===== JOB SNAPSHOT ===== */}
        {application.job && (
          <div className="bg-white rounded-xl shadow p-6 space-y-2">
            <h2 className="text-xl font-semibold mb-2">Job Snapshot</h2>

            <p>
              <strong>Job Type:</strong> {application.job.jobType || "N/A"}
            </p>

            <p>
              <strong>Location:</strong> {application.job.locationType || "N/A"}
            </p>

            <p>
              <strong>Duration:</strong> {application.job.duration || "N/A"}
            </p>

            <p>
              <strong>Payment:</strong> {formatPayment(application.job.payment)}
            </p>

            {application.job.description && (
              <div className="mt-4">
                <strong>Description:</strong>
                <p className="text-gray-700 mt-1">
                  {application.job.description}
                </p>
              </div>
            )}
          </div>
        )}

        {/* ===== ACTION ===== */}
        <div>
          <Link
            to="/dashboard"
            className="inline-block border border-gray-300 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
