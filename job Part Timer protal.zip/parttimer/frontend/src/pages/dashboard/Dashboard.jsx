import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { resolveProfilePhotoUrl } from "../../utils/profilePic";

const Dashboard = () => {
  const role = localStorage.getItem("role");
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    navigate("/login");
  };

  // Employer stats state
  const [employerStats, setEmployerStats] = useState({
    totalJobs: 0,
    activeJobs: 0,
    closedJobs: 0,
    applicationsTotal: 0,
    applicationsPending: 0,
  });
  const [statsLoading, setStatsLoading] = useState(false);
  const [statsError, setStatsError] = useState("");

  // Job seeker applications state
  const [jobSeekerProfile, setJobSeekerProfile] = useState(null);
  const [jobSeekerProfileLoading, setJobSeekerProfileLoading] = useState(false);
  const [jobSeekerProfileError, setJobSeekerProfileError] = useState("");

  // Employer profile (basic info)
  const [employerProfile, setEmployerProfile] = useState(null);
  const [employerProfileLoading, setEmployerProfileLoading] = useState(false);
  const [employerProfileError, setEmployerProfileError] = useState("");

  // Recent activities state
  const [recentActivities, setRecentActivities] = useState([]);
  const [activitiesLoading, setActivitiesLoading] = useState(false);
  const [activitiesError, setActivitiesError] = useState("");
  const [showAllActivities, setShowAllActivities] = useState(false);

  // Admin stats state
  const [adminStats, setAdminStats] = useState({
    totalEmployers: 0,
    totalJobSeekers: 0,
    totalJobs: 0,
    totalApplications: 0,
  });
  const [adminStatsLoading, setAdminStatsLoading] = useState(false);
  const [adminStatsError, setAdminStatsError] = useState("");

  // Date formatter for Asia/Kolkata
  const formatDateTime = useMemo(() => {
    return (value) =>
      new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
  }, []);

  // Fetch employer stats
  useEffect(() => {
    if (role !== "employer") return;
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchStats = async () => {
      setStatsLoading(true);
      setStatsError("");

      try {
        const [jobsRes, appsRes] = await Promise.all([
          fetch("http://localhost:5000/api/jobs/mine", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch("http://localhost:5000/api/applications/mine", {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        const jobs = await jobsRes.json();
        const apps = await appsRes.json();

        if (!jobsRes.ok) throw new Error(jobs.message || "Failed to load jobs");
        if (!appsRes.ok)
          throw new Error(apps.message || "Failed to load applications");

        const totalJobs = jobs.length;
        const activeJobs = jobs.filter((j) => j.status === "Active").length;
        const closedJobs = jobs.filter((j) => j.status === "Closed").length;
        const applicationsTotal = Array.isArray(apps) ? apps.length : 0;
        const applicationsPending = Array.isArray(apps)
          ? apps.filter((a) => a.status === "Applied").length
          : 0;

        setEmployerStats({
          totalJobs,
          activeJobs,
          closedJobs,
          applicationsTotal,
          applicationsPending,
        });
      } catch (err) {
        setStatsError(err.message || "Failed to load stats");
      } finally {
        setStatsLoading(false);
      }
    };

    fetchStats();
  }, [role]);

  // Fetch recent activities for employer
  useEffect(() => {
    if (role !== "employer") return;
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchActivities = async () => {
      setActivitiesLoading(true);
      setActivitiesError("");

      try {
        const res = await fetch(
          `http://localhost:5000/api/activities/recent?limit=${
            showAllActivities ? 50 : 5
          }`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const data = await res.json();

        if (!res.ok)
          throw new Error(data.message || "Failed to load activities");

        setRecentActivities(data);
      } catch (err) {
        const msg = err?.message || "Failed to load activities";
        console.error(msg);
        setActivitiesError(msg);
      } finally {
        setActivitiesLoading(false);
      }
    };

    fetchActivities();
  }, [role, showAllActivities]);

  // Fetch job seeker profile (basic info)
  useEffect(() => {
    if (role !== "jobseeker") return;
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchMyProfile = async () => {
      setJobSeekerProfileLoading(true);
      setJobSeekerProfileError("");

      try {
        const res = await fetch("http://localhost:5000/api/users/me/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.message || "Failed to load profile");

        setJobSeekerProfile(data);
      } catch (err) {
        setJobSeekerProfileError(err.message || "Failed to load profile");
      } finally {
        setJobSeekerProfileLoading(false);
      }
    };

    fetchMyProfile();
  }, [role]);

  // Fetch employer profile (basic info)
  useEffect(() => {
    if (role !== "employer") return;
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchMyProfile = async () => {
      setEmployerProfileLoading(true);
      setEmployerProfileError("");

      try {
        const res = await fetch("http://localhost:5000/api/users/me/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.message || "Failed to load profile");

        setEmployerProfile(data);
      } catch (err) {
        setEmployerProfileError(err.message || "Failed to load profile");
      } finally {
        setEmployerProfileLoading(false);
      }
    };

    fetchMyProfile();
  }, [role]);

  // Fetch admin dashboard stats
  useEffect(() => {
    if (role !== "admin") return;
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchAdminStats = async () => {
      setAdminStatsLoading(true);
      setAdminStatsError("");

      try {
        const res = await fetch("http://localhost:5000/api/auth/admin/stats", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (!res.ok)
          throw new Error(data.message || "Failed to load admin stats");

        setAdminStats({
          totalEmployers: data.totalEmployers || 0,
          totalJobSeekers: data.totalJobSeekers || 0,
          totalJobs: data.totalJobs || 0,
          totalApplications: data.totalApplications || 0,
        });
      } catch (err) {
        setAdminStatsError(err.message || "Failed to load admin stats");
      } finally {
        setAdminStatsLoading(false);
      }
    };

    fetchAdminStats();
  }, [role]);

  return (
    <div className="pt-24 p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">
            {role === "jobseeker"
              ? "Job Seeker Dashboard"
              : role === "employer"
              ? "Employer Dashboard"
              : role === "admin"
              ? "Admin Dashboard"
              : "Dashboard"}
          </h1>
          {role === "employer" && (
            <p className="text-gray-600 mt-1">
              Overview of your jobs and applications
            </p>
          )}
          {role === "admin" && (
            <p className="text-gray-600 mt-1">
              Monitor overall activity on PartTimer
            </p>
          )}
        </div>

        <div className="flex items-center justify-end gap-3 flex-wrap">
          {role === "employer" ? (
            <>
              <Link
                to="/profile"
                className="border border-orange-500 text-orange-500 px-4 py-2 rounded-md font-semibold hover:bg-orange-50 transition"
              >
                👤 View My Profile
              </Link>
              <Link
                to="/profile/edit"
                className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
              >
                ✏️ Edit My Profile
              </Link>
              <Link
                to="/employer/post-job"
                className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
              >
                ➕ Post a New Job
              </Link>
            </>
          ) : role === "jobseeker" ? (
            <>
              <Link
                to="/profile"
                className="border border-orange-500 text-orange-500 px-4 py-2 rounded-md font-semibold hover:bg-orange-50 transition"
              >
                👤 View My Profile
              </Link>
              <Link
                to="/profile/edit"
                className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
              >
                ✏️ Edit My Profile
              </Link>
              <Link
                to="/jobseeker/my-applications"
                className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md font-semibold hover:bg-gray-100 transition"
              >
                My Applications
              </Link>
            </>
          ) : null}

          <button
            onClick={handleLogout}
            className="bg-red-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-red-600 transition"
          >
            Logout
          </button>
        </div>
      </div>

      {/* ================= JOB SEEKER SECTION ================= */}
      {role === "jobseeker" && (
        <div className="space-y-8">
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="text-xl font-semibold mb-4">Basic Info</h3>

            {jobSeekerProfileLoading ? (
              <p className="text-gray-500">Loading profile...</p>
            ) : jobSeekerProfileError ? (
              <p className="text-red-600">{jobSeekerProfileError}</p>
            ) : jobSeekerProfile ? (
              (() => {
                const profile = jobSeekerProfile.profile || {};
                const common = profile.common || {};
                const jobseeker = profile.jobseeker || {};
                const user = jobSeekerProfile.user || {};
                const userName =
                  user.name || localStorage.getItem("userName") || "Jobseeker";
                const photoUrl = resolveProfilePhotoUrl(
                  jobSeekerProfile.profilePhotoPath,
                  user.role,
                  common.gender,
                  common.avatarPreset,
                  common.usePrideAvatar
                );
                const resumePdfPath = jobSeekerProfile.resumePdfPath;
                const locationText =
                  common.location ||
                  [jobseeker.city, jobseeker.state]
                    .filter(Boolean)
                    .join(", ") ||
                  "—";

                return (
                  <div className="flex flex-col gap-4">
                    <div className="flex items-start gap-4">
                      <img
                        src={photoUrl}
                        alt="Profile"
                        className="w-16 h-16 rounded-full border object-cover"
                      />

                      <div className="min-w-0 flex-1">
                        <p className="text-lg font-semibold text-gray-900">
                          {userName}
                        </p>
                        <p className="text-sm text-gray-600">Jobseeker</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Profile Photo</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {jobSeekerProfile.profilePhotoPath
                            ? "Uploaded"
                            : "Default"}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Resume (PDF)</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {resumePdfPath ? (
                            <a
                              className="text-orange-600 font-semibold hover:underline"
                              href={`http://localhost:5000${resumePdfPath}`}
                              target="_blank"
                              rel="noreferrer"
                            >
                              View
                            </a>
                          ) : (
                            "—"
                          )}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Phone</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {common.phone || "—"}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Gender</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {common.gender || "—"}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Birth Date</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {common.birthDate || "—"}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3 sm:col-span-2">
                        <p className="text-xs text-gray-500">Location</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {locationText}
                        </p>
                      </div>
                    </div>

                    <div className="rounded-lg border border-gray-200 p-3">
                      <p className="text-xs text-gray-500">Bio</p>
                      <p className="text-sm text-gray-800 whitespace-pre-wrap">
                        {common.bio || "—"}
                      </p>
                    </div>
                  </div>
                );
              })()
            ) : (
              <p className="text-gray-500">Profile not found</p>
            )}
          </div>
        </div>
      )}

      {/* ================= EMPLOYER SECTION ================= */}
      {role === "employer" && (
        <div className="space-y-10">
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="text-xl font-semibold mb-4">Basic Info</h3>

            {employerProfileLoading ? (
              <p className="text-gray-500">Loading profile...</p>
            ) : employerProfileError ? (
              <p className="text-red-600">{employerProfileError}</p>
            ) : employerProfile ? (
              (() => {
                const profile = employerProfile.profile || {};
                const common = profile.common || {};
                const employer = profile.employer || {};
                const user = employerProfile.user || {};

                const photoUrl = resolveProfilePhotoUrl(
                  employerProfile.profilePhotoPath,
                  user.role,
                  common.gender,
                  common.avatarPreset,
                  common.usePrideAvatar
                );

                const companyLocationText =
                  employer.companyLocation ||
                  [employer.city, employer.state].filter(Boolean).join(", ") ||
                  "—";

                const displayName = employer.companyName || "—";
                const displayIndustry = employer.industry || "—";
                const displayPhone = common.phone || "—";
                const displayCompanyLocation = companyLocationText;
                const displayLocation = common.location || "—";
                const displayAbout = employer.about || "—";
                const displayGender = common.gender || "—";
                const displayBirthDate = common.birthDate || "—";

                const normalizeLocation = (value) =>
                  String(value || "")
                    .trim()
                    .toLowerCase();
                const companyLocNorm = normalizeLocation(
                  displayCompanyLocation
                );
                const locNorm = normalizeLocation(displayLocation);
                const showLocationCard =
                  locNorm &&
                  locNorm !== "—" &&
                  (companyLocNorm === "—" || locNorm !== companyLocNorm);

                return (
                  <div className="flex flex-col gap-4">
                    <div className="flex items-start gap-4">
                      <img
                        src={photoUrl}
                        alt="Profile"
                        className="w-16 h-16 rounded-full border object-cover"
                      />

                      <div className="min-w-0 flex-1">
                        <p className="text-lg font-semibold text-gray-900">
                          {displayName}
                        </p>
                        <p className="text-sm text-gray-600">
                          {displayIndustry}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Profile Photo</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {employerProfile.profilePhotoPath
                            ? "Uploaded"
                            : "Default"}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Website</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {employer.website ? (
                            <a
                              className="text-orange-600 font-semibold hover:underline"
                              href={employer.website}
                              target="_blank"
                              rel="noreferrer"
                            >
                              Visit
                            </a>
                          ) : (
                            "—"
                          )}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">
                          Company Location
                        </p>
                        <p className="text-sm font-semibold text-gray-800">
                          {displayCompanyLocation}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Phone</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {displayPhone}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Gender</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {displayGender}
                        </p>
                      </div>

                      <div className="rounded-lg border border-gray-200 p-3">
                        <p className="text-xs text-gray-500">Birth Date</p>
                        <p className="text-sm font-semibold text-gray-800">
                          {displayBirthDate}
                        </p>
                      </div>

                      {showLocationCard ? (
                        <div className="rounded-lg border border-gray-200 p-3 sm:col-span-2">
                          <p className="text-xs text-gray-500">Location</p>
                          <p className="text-sm font-semibold text-gray-800">
                            {displayLocation}
                          </p>
                        </div>
                      ) : null}
                    </div>

                    <div className="rounded-lg border border-gray-200 p-3">
                      <p className="text-xs text-gray-500">About</p>
                      <p className="text-sm text-gray-800 whitespace-pre-wrap">
                        {displayAbout}
                      </p>
                    </div>
                  </div>
                );
              })()
            ) : (
              <p className="text-gray-500">Profile not found</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <EmployerSummaryCard
              title="Total Jobs Posted"
              value={employerStats.totalJobs}
              to="/employer/my-jobs"
            />
            <EmployerSummaryCard
              title="Closed Jobs"
              value={employerStats.closedJobs}
              to="/employer/my-jobs"
            />
            <EmployerSummaryCard
              title="Applications Received"
              value={employerStats.applicationsTotal}
              to="/employer/applications"
            />
            <EmployerSummaryCard
              title="Pending Applications"
              value={employerStats.applicationsPending}
              to="/employer/applications"
            />
          </div>
          {statsLoading && (
            <p className="text-gray-500 text-sm">Loading stats…</p>
          )}
          {statsError && <p className="text-red-600 text-sm">{statsError}</p>}

          <div className="bg-white rounded-xl shadow p-6">
            <div className="flex items-center justify-between gap-4 mb-3">
              <h2 className="text-xl font-semibold">Recent Activity</h2>
              <button
                onClick={() => setShowAllActivities((v) => !v)}
                className="text-orange-600 font-semibold hover:underline"
              >
                {showAllActivities ? "Show Less" : "Show All"}
              </button>
            </div>
            {activitiesLoading ? (
              <p className="text-gray-500 text-sm">Loading activities...</p>
            ) : activitiesError ? (
              <p className="text-red-600 text-sm">{activitiesError}</p>
            ) : recentActivities.length > 0 ? (
              <div
                className={`text-gray-700 overflow-y-auto ${
                  showAllActivities ? "max-h-80 pr-2" : ""
                }`}
              >
                <ul className="space-y-2">
                  {recentActivities.map((activity) => (
                    <li key={activity._id}>
                      • {activity.description || "Activity"}
                      {activity.createdAt ? (
                        <span className="text-gray-500 text-sm">
                          {" "}
                          ({formatDateTime(activity.createdAt)})
                        </span>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <p className="text-gray-500 text-sm">No recent activity</p>
            )}
          </div>
        </div>
      )}

      {/* ================= ADMIN SECTION ================= */}
      {role === "admin" && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <AdminStatCard
              title="Total Employers"
              value={adminStats.totalEmployers}
              to="/admin/employers"
            />
            <AdminStatCard
              title="Total Job Seekers"
              value={adminStats.totalJobSeekers}
              to="/admin/jobseekers"
            />
            <AdminStatCard
              title="Total Jobs"
              value={adminStats.totalJobs}
              to="/admin/jobs"
            />
            <AdminStatCard
              title="Total Applications"
              value={adminStats.totalApplications}
              to="/admin/applications"
            />
          </div>

          {adminStatsLoading && (
            <p className="text-gray-500 text-sm">Loading admin stats…</p>
          )}
          {adminStatsError && (
            <p className="text-red-600 text-sm">{adminStatsError}</p>
          )}

          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="text-xl font-semibold mb-4">Quick Access</h3>

            <div className="flex flex-wrap gap-4">
              <Link
                to="/admin/activities"
                className="border border-gray-500 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-50 transition"
              >
                🧾 View Activity Log
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function EmployerSummaryCard({ title, value, to }) {
  const content = (
    <div className="bg-white rounded-xl shadow p-6">
      <p className="text-gray-600 text-sm">{title}</p>
      <p className="text-3xl font-bold mt-2">{value}</p>
      {to ? (
        <p className="text-orange-600 text-sm font-semibold mt-1 text-right">
          view
        </p>
      ) : null}
    </div>
  );

  if (to) {
    return (
      <Link to={to} className="block hover:opacity-95 transition">
        {content}
      </Link>
    );
  }

  return content;
}

function AdminStatCard({ title, value, to }) {
  const content = (
    <div className="bg-white rounded-xl shadow p-6">
      <p className="text-gray-600 text-sm">{title}</p>
      <p className="text-3xl font-bold mt-2">{value}</p>
      {to ? (
        <p className="text-orange-600 text-sm font-semibold mt-1 text-right">
          view
        </p>
      ) : null}
    </div>
  );

  if (to) {
    return (
      <Link to={to} className="block hover:opacity-95 transition">
        {content}
      </Link>
    );
  }

  return content;
}

export default Dashboard;
