import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { isLoggedIn } from "../../utils/auth";
import { resolveProfilePhotoUrl } from "../../utils/profilePic";

export default function ViewProfile() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [data, setData] = useState(null);

  const [adminActionLoading, setAdminActionLoading] = useState(false);
  const [adminActionError, setAdminActionError] = useState("");
  const [adminActionSuccess, setAdminActionSuccess] = useState("");

  const [warnMessage, setWarnMessage] = useState("");
  const [warnReason, setWarnReason] = useState("");

  const [lockMessage, setLockMessage] = useState("");
  const [lockReason, setLockReason] = useState("");
  const [lockDays, setLockDays] = useState("");
  const [lockedUntil, setLockedUntil] = useState(""); // datetime-local value

  const isOwnProfile = !id;
  const viewerRole = localStorage.getItem("role");
  const isAdminViewingOtherUser = viewerRole === "admin" && Boolean(id);

  useEffect(() => {
    if (!isLoggedIn()) {
      navigate("/login", {
        state: { from: id ? `/users/${id}/profile` : "/profile" },
      });
      return;
    }

    const token = localStorage.getItem("token");

    const url = id
      ? `http://localhost:5000/api/users/${id}/profile`
      : "http://localhost:5000/api/users/me/profile";

    const fetchProfile = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.message || "Failed to load profile");
        setData(json);

        // Prefill moderation inputs for admin convenience
        if (viewerRole === "admin") {
          const moderation = json?.moderation || {};
          setWarnMessage(String(moderation.warningMessage || ""));
          setWarnReason(String(moderation.reason || ""));
          setLockMessage(String(moderation.message || ""));
          setLockReason(String(moderation.reason || ""));
          setLockDays("");
          setLockedUntil("");
        }
      } catch (err) {
        setError(err.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [id, navigate, viewerRole]);

  if (loading) return <div className="pt-24 px-6">Loading profile...</div>;
  if (error) return <div className="pt-24 px-6 text-red-600">{error}</div>;
  if (!data) return <div className="pt-24 px-6">Profile not found</div>;

  const { user, profile, profilePhotoPath, resumePdfPath, moderation } = data;
  const common = profile?.common || {};
  const jobseeker = profile?.jobseeker || {};
  const employer = profile?.employer || {};
  const photoUrl = resolveProfilePhotoUrl(
    profilePhotoPath,
    user?.role,
    common.gender,
    common.avatarPreset,
    common.usePrideAvatar
  );

  const now = new Date();
  const lockedUntilDate = moderation?.lockedUntil
    ? new Date(moderation.lockedUntil)
    : null;
  const isCurrentlyLocked =
    Boolean(moderation?.isLocked) &&
    (!lockedUntilDate || (lockedUntilDate && lockedUntilDate > now));
  const lockedUntilText =
    lockedUntilDate && !Number.isNaN(lockedUntilDate.getTime())
      ? lockedUntilDate.toLocaleString()
      : null;

  const refreshProfile = async () => {
    const token = localStorage.getItem("token");
    const url = id
      ? `http://localhost:5000/api/users/${id}/profile`
      : "http://localhost:5000/api/users/me/profile";

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.message || "Failed to refresh profile");
    setData(json);
  };

  const postAdminModeration = async (endpoint, payload) => {
    const token = localStorage.getItem("token");
    setAdminActionLoading(true);
    setAdminActionError("");
    setAdminActionSuccess("");
    try {
      const res = await fetch(`http://localhost:5000${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: payload ? JSON.stringify(payload) : undefined,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Action failed");

      setAdminActionSuccess(json.message || "Saved");
      await refreshProfile();
    } catch (err) {
      setAdminActionError(err.message || "Action failed");
    } finally {
      setAdminActionLoading(false);
    }
  };

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <img
              src={photoUrl}
              alt="Profile"
              className="w-20 h-20 rounded-full border object-cover"
            />
            <div>
              <h1 className="text-3xl font-bold">{user?.name || "Profile"}</h1>
              <p className="text-gray-600 mt-1">
                {user?.role ? user.role.toUpperCase() : ""}
                {user?.email ? ` • ${user.email}` : ""}
              </p>
            </div>
          </div>

          {isOwnProfile && (
            <Link
              to="/profile/edit"
              className="border border-gray-300 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Edit Profile
            </Link>
          )}
        </div>

        {/* Common */}
        <div className="bg-white rounded-xl shadow p-6 space-y-2">
          <h2 className="text-xl font-semibold">Basic</h2>
          <p>
            <strong>Profile Photo:</strong>{" "}
            {profilePhotoPath ? "Uploaded" : "Default"}
          </p>
          {user?.role === "jobseeker" && (
            <p>
              <strong>Resume (PDF):</strong>{" "}
              {resumePdfPath ? (
                <a
                  className="text-orange-600 font-semibold hover:underline"
                  href={`http://localhost:5000${resumePdfPath}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  View
                </a>
              ) : (
                "—"
              )}
            </p>
          )}
          <p>
            <strong>Phone:</strong> {common.phone || "—"}
          </p>
          <p>
            <strong>Location:</strong> {common.location || "—"}
          </p>
          <p>
            <strong>Gender:</strong> {common.gender || "—"}
          </p>
          <p>
            <strong>Birth Date:</strong> {common.birthDate || "—"}
          </p>
          <div>
            <strong>Bio:</strong>
            <p className="text-gray-700 mt-1 whitespace-pre-wrap">
              {common.bio || "—"}
            </p>
          </div>
        </div>

        {/* Role-specific */}
        {user?.role === "jobseeker" && (
          <div className="bg-white rounded-xl shadow p-6 space-y-2">
            <h2 className="text-xl font-semibold">Job Seeker</h2>
            <p>
              <strong>Headline:</strong> {jobseeker.headline || "—"}
            </p>
            <p>
              <strong>City:</strong> {jobseeker.city || "—"}
            </p>
            <p>
              <strong>State:</strong> {jobseeker.state || "—"}
            </p>
            <p>
              <strong>Skills:</strong>{" "}
              {Array.isArray(jobseeker.skills) && jobseeker.skills.length
                ? jobseeker.skills.join(", ")
                : "—"}
            </p>
            <div>
              <strong>Education:</strong>
              <p className="text-gray-700 mt-1 whitespace-pre-wrap">
                {jobseeker.education || "—"}
              </p>
            </div>
            <p>
              <strong>Portfolio URL:</strong> {jobseeker.portfolioUrl || "—"}
            </p>
            <div>
              <strong>Experience:</strong>
              <p className="text-gray-700 mt-1 whitespace-pre-wrap">
                {jobseeker.experience || "—"}
              </p>
            </div>
          </div>
        )}

        {user?.role === "employer" && (
          <div className="bg-white rounded-xl shadow p-6 space-y-2">
            <h2 className="text-xl font-semibold">Employer</h2>
            <p>
              <strong>Company Name:</strong> {employer.companyName || "—"}
            </p>
            <p>
              <strong>Industry:</strong> {employer.industry || "—"}
            </p>
            <p>
              <strong>City:</strong> {employer.city || "—"}
            </p>
            <p>
              <strong>State:</strong> {employer.state || "—"}
            </p>
            <p>
              <strong>Website:</strong> {employer.website || "—"}
            </p>
            <p>
              <strong>Company Location:</strong>{" "}
              {employer.companyLocation || "—"}
            </p>
            <div>
              <strong>About:</strong>
              <p className="text-gray-700 mt-1 whitespace-pre-wrap">
                {employer.about || "—"}
              </p>
            </div>
          </div>
        )}

        {/* Admin moderation */}
        {isAdminViewingOtherUser ? (
          <div className="bg-white rounded-xl shadow p-6 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-xl font-semibold">Admin Moderation</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Warn or lock this account for unethical practices.
                </p>
              </div>

              <div className="text-right">
                <div
                  className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${
                    isCurrentlyLocked
                      ? "border-red-200 bg-red-50 text-red-700"
                      : "border-green-200 bg-green-50 text-green-700"
                  }`}
                >
                  {isCurrentlyLocked ? "LOCKED" : "ACTIVE"}
                </div>
                {isCurrentlyLocked ? (
                  <div className="text-xs text-gray-600 mt-1">
                    Until: {lockedUntilText || "Not specified"}
                  </div>
                ) : null}
              </div>
            </div>

            {adminActionError ? (
              <div className="border border-red-200 bg-red-50 text-red-700 rounded-lg px-4 py-3 text-sm">
                {adminActionError}
              </div>
            ) : null}
            {adminActionSuccess ? (
              <div className="border border-green-200 bg-green-50 text-green-700 rounded-lg px-4 py-3 text-sm">
                {adminActionSuccess}
              </div>
            ) : null}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Warn */}
              <div className="space-y-3">
                <h3 className="font-semibold">Warn User</h3>
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Warning message (shown after successful login)
                  </label>
                  <textarea
                    value={warnMessage}
                    onChange={(e) => setWarnMessage(e.target.value)}
                    rows={4}
                    className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                    placeholder="Example: Stop applying for multiple jobs for fun. Continued behavior will result in a lock."
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Reason
                  </label>
                  <input
                    value={warnReason}
                    onChange={(e) => setWarnReason(e.target.value)}
                    className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                    placeholder="Unethical activity / spam"
                    required
                  />
                </div>
                <button
                  type="button"
                  disabled={adminActionLoading}
                  onClick={() => {
                    if (!String(warnMessage || "").trim()) {
                      setAdminActionError("Warning message is required.");
                      return;
                    }
                    if (!String(warnReason || "").trim()) {
                      setAdminActionError("Reason is required.");
                      return;
                    }
                    postAdminModeration(`/api/auth/admin/users/${id}/warn`, {
                      message: warnMessage,
                      reason: warnReason,
                    });
                  }}
                  className="bg-orange-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-orange-600 transition disabled:opacity-60"
                >
                  {adminActionLoading ? "Saving..." : "Send Warning"}
                </button>
                <button
                  type="button"
                  disabled={adminActionLoading || !moderation?.warningMessage}
                  onClick={() => {
                    setWarnMessage("");
                    postAdminModeration(`/api/auth/admin/users/${id}/warn`, {
                      message: "",
                    });
                  }}
                  className="border border-gray-300 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition disabled:opacity-60"
                >
                  {adminActionLoading ? "Saving..." : "Clear Warning"}
                </button>
                {moderation?.warningMessage ? (
                  <p className="text-xs text-gray-600">
                    Current warning is active.
                  </p>
                ) : null}
              </div>

              {/* Lock/Unlock */}
              <div className="space-y-3">
                <h3 className="font-semibold">Lock / Unlock User</h3>
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Lock message (shown on login)
                  </label>
                  <textarea
                    value={lockMessage}
                    onChange={(e) => setLockMessage(e.target.value)}
                    rows={3}
                    className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                    placeholder="Example: Your account is locked due to suspicious activity."
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Reason
                  </label>
                  <input
                    value={lockReason}
                    onChange={(e) => setLockReason(e.target.value)}
                    className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                    placeholder="Spam / unethical practices"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Lock days
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={lockDays}
                      onChange={(e) => setLockDays(e.target.value)}
                      className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                      placeholder="30"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Locked until
                    </label>
                    <input
                      type="datetime-local"
                      value={lockedUntil}
                      onChange={(e) => setLockedUntil(e.target.value)}
                      className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  <button
                    type="button"
                    disabled={adminActionLoading}
                    onClick={() => {
                      if (!String(lockMessage || "").trim()) {
                        setAdminActionError("Lock message is required.");
                        return;
                      }
                      if (!String(lockReason || "").trim()) {
                        setAdminActionError("Reason is required.");
                        return;
                      }
                      const hasDays = String(lockDays || "").trim() !== "";
                      const hasUntil = String(lockedUntil || "").trim() !== "";
                      if (!hasDays && !hasUntil) {
                        setAdminActionError(
                          "Lock duration is required (lock days or locked until)."
                        );
                        return;
                      }
                      postAdminModeration(`/api/auth/admin/users/${id}/lock`, {
                        message: lockMessage,
                        reason: lockReason,
                        lockDays: hasDays ? Number(lockDays) : undefined,
                        lockedUntil: hasUntil
                          ? new Date(lockedUntil).toISOString()
                          : undefined,
                      });
                    }}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-red-700 transition disabled:opacity-60"
                  >
                    {adminActionLoading ? "Locking..." : "Lock Profile"}
                  </button>
                  <button
                    type="button"
                    disabled={adminActionLoading}
                    onClick={() =>
                      postAdminModeration(`/api/auth/admin/users/${id}/unlock`)
                    }
                    className="border border-gray-300 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition disabled:opacity-60"
                  >
                    {adminActionLoading ? "Unlocking..." : "Unlock"}
                  </button>
                </div>

                <p className="text-xs text-gray-600">
                  Note: If you set “Locked until”, it will be used instead of
                  “Lock days”.
                </p>
              </div>
            </div>

            {/* Current moderation details */}
            <div className="pt-2 border-t">
              <h3 className="font-semibold">Current Moderation</h3>
              <p className="text-sm text-gray-700 mt-1">
                <strong>Warning:</strong> {moderation?.warningMessage || "—"}
              </p>
              <p className="text-sm text-gray-700 mt-1">
                <strong>Lock message:</strong> {moderation?.message || "—"}
              </p>
              <p className="text-sm text-gray-700 mt-1">
                <strong>Reason:</strong> {moderation?.reason || "—"}
              </p>
              <p className="text-sm text-gray-700 mt-1">
                <strong>Locked until:</strong> {lockedUntilText || "—"}
              </p>
            </div>
          </div>
        ) : null}

        <div className="flex gap-3"></div>
      </div>
    </div>
  );
}
