import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { isLoggedIn, getUserRole } from "../../utils/auth";
import { resolveProfilePhotoUrl } from "../../utils/profilePic";

export default function EditProfile() {
  const navigate = useNavigate();
  const role = getUserRole();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingResume, setUploadingResume] = useState(false);
  const [error, setError] = useState("");
  const [photoError, setPhotoError] = useState("");
  const [resumeError, setResumeError] = useState("");

  const [profilePhotoPath, setProfilePhotoPath] = useState("");
  const [resumePdfPath, setResumePdfPath] = useState("");
  const [common, setCommon] = useState({
    phone: "",
    location: "",
    gender: "",
    birthDate: "",
    usePrideAvatar: false,
    bio: "",
  });
  const [jobseeker, setJobseeker] = useState({
    headline: "",
    city: "",
    state: "",
    skills: "",
    education: "",
    experience: "",
    portfolioUrl: "",
  });
  const [employer, setEmployer] = useState({
    companyName: "",
    industry: "",
    city: "",
    state: "",
    website: "",
    companyLocation: "",
    about: "",
  });

  useEffect(() => {
    if (!isLoggedIn()) {
      navigate("/login", { state: { from: "/profile/edit" } });
      return;
    }

    const token = localStorage.getItem("token");

    const load = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch("http://localhost:5000/api/users/me/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to load profile");

        setProfilePhotoPath(data.profilePhotoPath || "");
        setResumePdfPath(data.resumePdfPath || "");

        const p = data.profile || {};
        const c = p.common || {};
        setCommon({
          phone: c.phone || "",
          location: c.location || "",
          gender: c.gender || "",
          birthDate: c.birthDate || "",
          usePrideAvatar: Boolean(c.usePrideAvatar),
          bio: c.bio || "",
        });

        if (role === "jobseeker") {
          const js = p.jobseeker || {};
          setJobseeker({
            headline: js.headline || "",
            city: js.city || "",
            state: js.state || "",
            skills: Array.isArray(js.skills) ? js.skills.join(", ") : "",
            education: js.education || "",
            experience: js.experience || "",
            portfolioUrl: js.portfolioUrl || "",
          });
        }

        if (role === "employer") {
          const emp = p.employer || {};
          setEmployer({
            companyName: emp.companyName || "",
            industry: emp.industry || "",
            city: emp.city || "",
            state: emp.state || "",
            website: emp.website || "",
            companyLocation: emp.companyLocation || "",
            about: emp.about || "",
          });
        }
      } catch (err) {
        setError(err.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [navigate, role]);

  const handlePhotoUpload = async (file) => {
    if (!file) return;
    const token = localStorage.getItem("token");

    setUploadingPhoto(true);
    setPhotoError("");

    try {
      const form = new FormData();
      form.append("photo", file);

      const res = await fetch(
        "http://localhost:5000/api/users/me/profile-photo",
        {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
          body: form,
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to upload photo");
      setProfilePhotoPath(data.profilePhotoPath || "");
    } catch (err) {
      setPhotoError(err.message || "Failed to upload photo");
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleResumeUpload = async (file) => {
    if (!file) return;
    const token = localStorage.getItem("token");

    setUploadingResume(true);
    setResumeError("");

    try {
      const form = new FormData();
      form.append("resume", file);

      const res = await fetch("http://localhost:5000/api/users/me/resume", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to upload resume");
      setResumePdfPath(data.resumePdfPath || "");
    } catch (err) {
      setResumeError(err.message || "Failed to upload resume");
    } finally {
      setUploadingResume(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    const requireText = (value, label) => {
      if (!String(value || "").trim()) {
        setError(`${label} is required.`);
        return false;
      }
      return true;
    };

    setError("");

    if (!requireText(common.phone, "Phone")) return;
    if (!requireText(common.location, "Location")) return;

    if (!String(common.gender || "").trim()) {
      setError("Please select your gender.");
      return;
    }

    if (!requireText(common.birthDate, "Birth date")) return;
    if (!requireText(common.bio, "Bio")) return;

    if (role === "jobseeker") {
      if (!resumePdfPath) {
        setError("Resume (PDF) is required.");
        return;
      }
      if (!requireText(jobseeker.headline, "Headline")) return;
      if (!requireText(jobseeker.city, "City")) return;
      if (!requireText(jobseeker.state, "State")) return;

      const skills = String(jobseeker.skills || "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
      if (!skills.length) {
        setError("At least one skill is required.");
        return;
      }

      if (!requireText(jobseeker.education, "Education")) return;
      if (!requireText(jobseeker.portfolioUrl, "Portfolio URL")) return;
      if (!requireText(jobseeker.experience, "Experience")) return;
    }

    if (role === "employer") {
      if (!requireText(employer.companyName, "Company name")) return;
      if (!requireText(employer.industry, "Industry")) return;
      if (!requireText(employer.website, "Website")) return;
      if (!requireText(employer.city, "City")) return;
      if (!requireText(employer.state, "State")) return;
      if (!requireText(employer.companyLocation, "Company location")) return;
      if (!requireText(employer.about, "About")) return;
    }

    const payload = {
      profilePhotoPath,
      resumePdfPath: role === "jobseeker" ? resumePdfPath : undefined,
      common,
      jobseeker:
        role === "jobseeker"
          ? {
              headline: jobseeker.headline,
              city: jobseeker.city,
              state: jobseeker.state,
              skills: jobseeker.skills,
              education: jobseeker.education,
              experience: jobseeker.experience,
              portfolioUrl: jobseeker.portfolioUrl,
            }
          : undefined,
      jobSeekerProfile:
        role === "jobseeker"
          ? {
              headline: jobseeker.headline,
              city: jobseeker.city,
              state: jobseeker.state,
              skills: jobseeker.skills,
              education: jobseeker.education,
              experience: jobseeker.experience,
              portfolioUrl: jobseeker.portfolioUrl,
            }
          : undefined,
      employer:
        role === "employer"
          ? {
              companyName: employer.companyName,
              industry: employer.industry,
              city: employer.city,
              state: employer.state,
              website: employer.website,
              companyLocation: employer.companyLocation,
              about: employer.about,
            }
          : undefined,
      employerProfile:
        role === "employer"
          ? {
              companyName: employer.companyName,
              industry: employer.industry,
              city: employer.city,
              state: employer.state,
              website: employer.website,
              companyLocation: employer.companyLocation,
              about: employer.about,
            }
          : undefined,
    };

    setSaving(true);
    setError("");

    try {
      const res = await fetch("http://localhost:5000/api/users/me/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to save profile");

      navigate("/profile");
    } catch (err) {
      setError(err.message || "Failed to save profile");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="pt-24 px-6">Loading...</div>;

  const photoUrl = resolveProfilePhotoUrl(
    profilePhotoPath,
    role,
    common.gender,
    undefined,
    common.usePrideAvatar
  );

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow p-6 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Edit Profile</h1>
            <p className="text-gray-600 mt-1">Fill your resume-style details</p>
          </div>
          <Link
            to="/profile"
            className="border border-gray-300 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            View Profile
          </Link>
        </div>

        {error && <div className="text-red-600">{error}</div>}

        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">Basic</h2>
            <div className="flex flex-col md:flex-row items-start gap-4">
              <img
                src={photoUrl}
                alt="Profile"
                className="w-24 h-24 rounded-full border object-cover"
              />
              <div className="flex-1 space-y-2">
                <div className="flex flex-col gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handlePhotoUpload(e.target.files?.[0])}
                    className="w-full border rounded-lg px-3 py-2"
                    disabled={uploadingPhoto}
                  />
                  {!!profilePhotoPath && (
                    <button
                      type="button"
                      onClick={() => {
                        setProfilePhotoPath("");
                      }}
                      className="border border-gray-300 px-3 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
                    >
                      Remove Uploaded Photo
                    </button>
                  )}
                  {uploadingPhoto && (
                    <div className="text-gray-600 text-sm">Uploading...</div>
                  )}
                  {photoError && (
                    <div className="text-red-600 text-sm">{photoError}</div>
                  )}
                  {!!profilePhotoPath && (
                    <div className="text-gray-600 text-sm break-all">
                      Saved path: {profilePhotoPath}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {role === "jobseeker" && (
              <div className="space-y-2">
                <div className="font-semibold">Resume (PDF)</div>
                <input
                  type="file"
                  accept="application/pdf,.pdf"
                  onChange={(e) => handleResumeUpload(e.target.files?.[0])}
                  className="w-full border rounded-lg px-3 py-2"
                  disabled={uploadingResume}
                />
                {uploadingResume && (
                  <div className="text-gray-600 text-sm">Uploading...</div>
                )}
                {resumeError && (
                  <div className="text-red-600 text-sm">{resumeError}</div>
                )}
                {!!resumePdfPath && (
                  <div className="text-sm space-y-1">
                    <a
                      className="text-orange-600 font-semibold hover:underline"
                      href={`http://localhost:5000${resumePdfPath}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      View uploaded resume
                    </a>
                    <div className="text-gray-600 break-all">
                      Saved path: {resumePdfPath}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                value={common.phone}
                onChange={(e) =>
                  setCommon({ ...common, phone: e.target.value })
                }
                placeholder="Phone"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <input
                value={common.location}
                onChange={(e) =>
                  setCommon({ ...common, location: e.target.value })
                }
                placeholder="Location"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <select
                value={common.gender}
                onChange={(e) => {
                  const value = e.target.value;
                  setCommon({
                    ...common,
                    gender: value,
                    usePrideAvatar:
                      value === "other" ? common.usePrideAvatar : false,
                  });
                }}
                className="w-full border rounded-lg px-3 py-2"
                required
              >
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
              <input
                type="date"
                value={common.birthDate}
                onChange={(e) =>
                  setCommon({ ...common, birthDate: e.target.value })
                }
                placeholder="Birth Date"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
            </div>
            {common.gender === "other" && (
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={Boolean(common.usePrideAvatar)}
                  onChange={(e) =>
                    setCommon({ ...common, usePrideAvatar: e.target.checked })
                  }
                />
                Use pride avatar
              </label>
            )}
            <textarea
              value={common.bio}
              onChange={(e) => setCommon({ ...common, bio: e.target.value })}
              placeholder="Bio (short intro)"
              rows={4}
              required
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {role === "jobseeker" && (
            <div className="space-y-3">
              <h2 className="text-xl font-semibold">Job Seeker</h2>
              <input
                value={jobseeker.headline}
                onChange={(e) =>
                  setJobseeker({ ...jobseeker, headline: e.target.value })
                }
                placeholder="Headline (e.g., React Developer, Final Year Student)"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  value={jobseeker.city}
                  onChange={(e) =>
                    setJobseeker({ ...jobseeker, city: e.target.value })
                  }
                  placeholder="City"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
                <input
                  value={jobseeker.state}
                  onChange={(e) =>
                    setJobseeker({ ...jobseeker, state: e.target.value })
                  }
                  placeholder="State"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
              </div>
              <input
                value={jobseeker.skills}
                onChange={(e) =>
                  setJobseeker({ ...jobseeker, skills: e.target.value })
                }
                placeholder="Skills (comma separated)"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <textarea
                value={jobseeker.education}
                onChange={(e) =>
                  setJobseeker({ ...jobseeker, education: e.target.value })
                }
                placeholder="Education"
                rows={3}
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <input
                value={jobseeker.portfolioUrl}
                onChange={(e) =>
                  setJobseeker({ ...jobseeker, portfolioUrl: e.target.value })
                }
                placeholder="Portfolio URL"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <textarea
                value={jobseeker.experience}
                onChange={(e) =>
                  setJobseeker({ ...jobseeker, experience: e.target.value })
                }
                placeholder="Experience"
                rows={4}
                required
                className="w-full border rounded-lg px-3 py-2"
              />
            </div>
          )}

          {role === "employer" && (
            <div className="space-y-3">
              <h2 className="text-xl font-semibold">Employer</h2>
              <input
                value={employer.companyName}
                onChange={(e) =>
                  setEmployer({ ...employer, companyName: e.target.value })
                }
                placeholder="Company Name"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  value={employer.industry}
                  onChange={(e) =>
                    setEmployer({ ...employer, industry: e.target.value })
                  }
                  placeholder="Industry"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
                <input
                  value={employer.website}
                  onChange={(e) =>
                    setEmployer({ ...employer, website: e.target.value })
                  }
                  placeholder="Website"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  value={employer.city}
                  onChange={(e) =>
                    setEmployer({ ...employer, city: e.target.value })
                  }
                  placeholder="City"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
                <input
                  value={employer.state}
                  onChange={(e) =>
                    setEmployer({ ...employer, state: e.target.value })
                  }
                  placeholder="State"
                  required
                  className="w-full border rounded-lg px-3 py-2"
                />
              </div>
              <input
                value={employer.companyLocation}
                onChange={(e) =>
                  setEmployer({ ...employer, companyLocation: e.target.value })
                }
                placeholder="Company Location"
                required
                className="w-full border rounded-lg px-3 py-2"
              />
              <textarea
                value={employer.about}
                onChange={(e) =>
                  setEmployer({ ...employer, about: e.target.value })
                }
                placeholder="About the company"
                rows={4}
                required
                className="w-full border rounded-lg px-3 py-2"
              />
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className={`px-6 py-3 rounded-lg font-semibold transition ${
                saving
                  ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                  : "bg-orange-500 text-white hover:bg-orange-600"
              }`}
            >
              {saving ? "Saving..." : "Save Profile"}
            </button>
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="border border-gray-300 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
