import LandingPagePics from "../../components/LandingPagePics";
import { Link } from "react-router-dom";

const features = [
  {
    title: "Quick Job Posting",
    desc: "Employers can post part-time jobs quickly with minimal details, making the hiring process fast and efficient.",
  },
  {
    title: "Flexible Opportunities",
    desc: "Job seekers can explore flexible work options that fit their schedule, skills, and availability.",
  },
  {
    title: "Trusted Employers",
    desc: "All employers are verified to ensure safe, reliable, and genuine job opportunities for users.",
  },
];

const roles = [
  {
    title: "Job Seeker",
    desc: "Students and job seekers can browse jobs, apply easily, and track applications through a personalized dashboard.",
  },
  {
    title: "Employer",
    desc: "Employers can post jobs, manage applications, and connect with suitable candidates from their dashboard.",
  },
];

export default function Landing() {
  const token = localStorage.getItem("token");
  const userName = localStorage.getItem("userName");
  const isLoggedIn = !!token;

  return (
    <div className="bg-white text-gray-800 pt-24">
      {/* HERO SECTION */}
      <section className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-10 items-center ">
        <div>
          <h1 className="text-5xl font-extrabold mb-6">
            Part-Time Jobs,
            <br />
            <span className="text-orange-500">More Opportunities</span>
          </h1>

          <p className="text-gray-600 text-lg mb-8">
            PartTimer helps students and job seekers connect with employers for
            short-term and flexible work opportunities.
          </p>

          <div className="flex gap-4">
            <a
              href="/jobs"
              className="bg-orange-500 text-white px-6 py-3 rounded-md font-semibold hover:bg-orange-600 transition"
            >
              Browse Jobs
            </a>

            {isLoggedIn ? (
              <Link
                to="/dashboard"
                className="border border-orange-500 text-orange-500 px-6 py-3 rounded-md font-semibold hover:bg-orange-50 transition"
              >
                Go to Dashboard
              </Link>
            ) : (
              <>
                <a
                  href="/login"
                  className="border border-orange-500 text-orange-500 px-6 py-3 rounded-md font-semibold hover:bg-orange-50 transition"
                >
                  Login
                </a>
              </>
            )}
          </div>

          {!isLoggedIn && (
            <p className="mt-4 text-sm text-gray-600">
              New to PartTimer?{" "}
              <a
                href="/profile-create"
                className="text-orange-500 font-medium hover:underline"
              >
                Create your profile
              </a>
            </p>
          )}

          {isLoggedIn && userName && (
            <p className="mt-4 text-sm text-gray-600">
              Welcome back,{" "}
              <span className="font-semibold text-orange-500">{userName}</span>!
            </p>
          )}
        </div>

        {/* IMAGE PLACEHOLDER */}
        <div className="h-72 rounded-lg overflow-hidden">
          <LandingPagePics />
        </div>
      </section>

      {/* FEATURES SECTION */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-10">
            Why Choose <span className="text-orange-500">PartTimer</span>
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((item) => (
              <div
                key={item.title}
                className="bg-white p-6 rounded-lg shadow hover:shadow-md transition"
              >
                <div className="text-orange-500 text-3xl mb-4">●</div>
                <h3 className="font-semibold text-xl mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES / ROLE SECTION */}
      <section className="py-16 max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold mb-10">
          Who Can Use <span className="text-orange-500">PartTimer</span>?
        </h2>

        <div className="grid md:grid-cols-2 gap-8 justify-center">
          {roles.map((role) => (
            <div
              key={role.title}
              className="border rounded-lg p-6 hover:border-orange-500 transition"
            >
              <h3 className="font-semibold text-xl mb-3">{role.title}</h3>
              <p className="text-gray-600 text-sm">{role.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-orange-500 text-white py-10">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-8 text-sm">
          <div>
            <h3 className="font-bold text-lg mb-2">PartTimer</h3>
            <p>
              Helping students and job seekers find flexible work opportunities.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Contact</h4>
            <p>Email: support@parttimer.com</p>
            <p>Phone: +91 XXXXX XXXXX</p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Legal</h4>
            <ul className="space-y-1">
              <li>
                <a href="#" className="hover:text-orange-200 transition">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-200 transition">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-6 border-t border-orange-400 mt-8 pt-6 text-center">
          <p>&copy; 2025 PartTimer. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
