import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();

  const [role, setRole] = useState("jobseeker"); // UI only
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [notice, setNotice] = useState(null); // { type: 'success'|'error'|'info', text: string }
  const [moderationInfo, setModerationInfo] = useState(null);
  const [pendingRoleSwitch, setPendingRoleSwitch] = useState(null); // string | null
  const [pendingWarningConfirm, setPendingWarningConfirm] = useState(false);
  const [redirectSeconds, setRedirectSeconds] = useState(null); // number | null
  const redirectTimerRef = useRef(null);
  const redirectIntervalRef = useRef(null);

  useEffect(() => {
    return () => {
      if (redirectTimerRef.current) {
        clearTimeout(redirectTimerRef.current);
      }
      if (redirectIntervalRef.current) {
        clearInterval(redirectIntervalRef.current);
      }
    };
  }, []);

  const from = location.state?.from;
  const redirectAfterLogin = from ? from : "/dashboard";

  const beginRedirect = () => {
    setRedirectSeconds(5);

    if (redirectIntervalRef.current) {
      clearInterval(redirectIntervalRef.current);
      redirectIntervalRef.current = null;
    }
    if (redirectTimerRef.current) {
      clearTimeout(redirectTimerRef.current);
      redirectTimerRef.current = null;
    }

    redirectIntervalRef.current = setInterval(() => {
      setRedirectSeconds((prev) => {
        if (typeof prev !== "number") return prev;
        if (prev <= 1) {
          if (redirectIntervalRef.current) {
            clearInterval(redirectIntervalRef.current);
            redirectIntervalRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    redirectTimerRef.current = setTimeout(() => {
      navigate(redirectAfterLogin);
    }, 5000);
  };

  const handleLogin = async () => {
    try {
      setNotice(null);
      setModerationInfo(null);
      setPendingRoleSwitch(null);
      setPendingWarningConfirm(false);
      setRedirectSeconds(null);
      if (redirectTimerRef.current) {
        clearTimeout(redirectTimerRef.current);
      }
      if (redirectIntervalRef.current) {
        clearInterval(redirectIntervalRef.current);
      }

      const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setNotice({
          type: "error",
          text: data?.message || "Login failed. Please try again.",
        });
        return;
      }

      const actualRole = data?.user?.role;
      const roleMismatch = !!(actualRole && actualRole !== role);

      const moderation = data?.user?.moderation || {};
      const isLocked = Boolean(moderation.isLocked);
      const warningMessage = String(moderation.warningMessage || "").trim();
      const lockMessage = String(moderation.message || "").trim();
      const lockReason = String(moderation.reason || "").trim();

      const lockedUntilRaw = moderation.lockedUntil || null;
      const lockedUntilDate = lockedUntilRaw ? new Date(lockedUntilRaw) : null;
      const lockedUntilText =
        lockedUntilDate && !Number.isNaN(lockedUntilDate.getTime())
          ? lockedUntilDate.toLocaleString()
          : null;

      setModerationInfo({
        isLocked,
        lockedUntilText,
        warningMessage: warningMessage || null,
        lockMessage: lockMessage || null,
        lockReason: lockReason || null,
      });

      // If user is trying from the wrong tab, ask for confirmation.
      // Do NOT log them in yet. They must click login again from the correct tab.
      if (roleMismatch) {
        setPendingRoleSwitch(actualRole);
        setPendingWarningConfirm(false);
        setNotice({
          type: "info",
          text: `You are registered as ${actualRole}. Switch to the ${actualRole} tab and login again?`,
        });
        return;
      }

      // If the account is locked, show the admin message and do not log in / redirect.
      if (isLocked) {
        setNotice({
          type: "error",
          text: "Your profile is locked. You cannot log in right now.",
        });
        setPendingWarningConfirm(false);
        setRedirectSeconds(null);
        if (redirectTimerRef.current) {
          clearTimeout(redirectTimerRef.current);
          redirectTimerRef.current = null;
        }
        if (redirectIntervalRef.current) {
          clearInterval(redirectIntervalRef.current);
          redirectIntervalRef.current = null;
        }
        return;
      }

      // 🔐 STORE TOKEN & ROLE
      localStorage.setItem("token", data.token);
      localStorage.setItem("role", data.user.role);
      localStorage.setItem("userName", data.user.name);
      localStorage.setItem("userId", data.user.id);

      if (warningMessage) {
        setPendingWarningConfirm(true);
        setNotice({
          type: "info",
          text: `Warning from admin. Click OK to continue.`,
        });
        setRedirectSeconds(null);
        return;
      }

      setNotice({
        type: "success",
        text: `Login successful as ${data.user.role}. Redirecting...`,
      });
      beginRedirect();
    } catch (error) {
      console.error(error);
      setNotice({
        type: "error",
        text: "Server error. Please try again in a moment.",
      });
      setModerationInfo(null);
      setPendingWarningConfirm(false);
      setRedirectSeconds(null);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="bg-white w-full max-w-md rounded-xl shadow-lg p-8">
        {/* Heading */}
        <h2 className="text-3xl font-bold text-center mb-2">
          Login to <span className="text-orange-500">PartTimer</span>
        </h2>
        <p className="text-center text-gray-600 mb-8">
          Select your role and continue
        </p>

        {notice?.text ? (
          <div
            className={`mb-5 rounded-lg border px-4 py-3 text-sm font-medium ${
              notice.type === "error"
                ? "border-red-200 bg-red-50 text-red-700"
                : notice.type === "success"
                ? "border-green-200 bg-green-50 text-green-700"
                : "border-orange-200 bg-orange-50 text-orange-700"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div>{notice.text}</div>
                {notice.type === "success" &&
                typeof redirectSeconds === "number" ? (
                  <div className="mt-1 text-xs opacity-80">
                    Redirecting in {redirectSeconds}s
                  </div>
                ) : null}

                {moderationInfo?.warningMessage ? (
                  <div className="mt-2 text-xs opacity-90">
                    Warning: {moderationInfo.warningMessage}
                  </div>
                ) : null}

                {moderationInfo?.isLocked ? (
                  <div className="mt-2 text-xs opacity-90">
                    {moderationInfo.lockMessage ? (
                      <div>Message: {moderationInfo.lockMessage}</div>
                    ) : null}
                    {moderationInfo.lockReason ? (
                      <div>Reason: {moderationInfo.lockReason}</div>
                    ) : null}
                    {moderationInfo.lockedUntilText ? (
                      <div>Locked until: {moderationInfo.lockedUntilText}</div>
                    ) : (
                      <div>Locked until: Not specified</div>
                    )}
                  </div>
                ) : null}
              </div>
            </div>

            {pendingRoleSwitch ? (
              <div className="mt-3 flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setRole(pendingRoleSwitch);
                    setPassword("");
                    setPendingRoleSwitch(null);
                    setRedirectSeconds(null);
                    setModerationInfo(null);
                    setNotice({
                      type: "info",
                      text: `Switched to ${pendingRoleSwitch} tab. Please login again from this tab.`,
                    });
                  }}
                  className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
                >
                  OK
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPendingRoleSwitch(null);
                    setNotice(null);
                    setRedirectSeconds(null);
                    setModerationInfo(null);
                    setPendingWarningConfirm(false);
                  }}
                  className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md font-semibold hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
              </div>
            ) : pendingWarningConfirm ? (
              <div className="mt-3 flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setPendingWarningConfirm(false);
                    setNotice({
                      type: "success",
                      text: "Redirecting...",
                    });
                    beginRedirect();
                  }}
                  className="bg-orange-500 text-white px-4 py-2 rounded-md font-semibold hover:bg-orange-600 transition"
                >
                  OK
                </button>
              </div>
            ) : null}
          </div>
        ) : null}

        {/* Role Selector */}
        <div className="flex justify-center gap-3 mb-6">
          {[
            { id: "jobseeker", label: "Job Seeker" },
            { id: "employer", label: "Employer" },
            { id: "admin", label: "Admin" },
          ].map((r) => (
            <button
              key={r.id}
              onClick={() => {
                setRole(r.id);
                setEmail("");
                setPassword("");
                setNotice(null);
                setPendingRoleSwitch(null);
                setPendingWarningConfirm(false);
                setRedirectSeconds(null);
                setModerationInfo(null);
                if (redirectTimerRef.current) {
                  clearTimeout(redirectTimerRef.current);
                  redirectTimerRef.current = null;
                }
                if (redirectIntervalRef.current) {
                  clearInterval(redirectIntervalRef.current);
                  redirectIntervalRef.current = null;
                }
              }}
              className={`px-4 py-2 rounded-full text-sm font-medium border transition
                ${
                  role === r.id
                    ? "bg-orange-500 text-white border-orange-500"
                    : "bg-white text-gray-700 border-gray-300 hover:border-orange-500"
                }`}
            >
              {r.label}
            </button>
          ))}
        </div>

        {/* Login Form */}
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>

          {/* Button */}
          <button
            type="button"
            onClick={handleLogin}
            className="w-full bg-orange-500 text-white py-2 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            Login as{" "}
            {role === "jobseeker"
              ? "Job Seeker"
              : role === "employer"
              ? "Employer"
              : "Admin"}
          </button>

          <p className="text-center text-sm text-gray-600 mt-6">
            Don’t have an account?{" "}
            <Link
              to="/profile-create"
              state={{ from }}
              className="text-orange-500 font-medium hover:underline"
            >
              Create your profile
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
