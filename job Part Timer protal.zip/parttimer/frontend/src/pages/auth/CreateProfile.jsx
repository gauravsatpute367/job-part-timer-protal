import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

export default function ProfileCreate() {
  const navigate = useNavigate();
  const location = useLocation();

  // previous page jahan se auth flow start hua
  const from = location.state?.from || "/";

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "jobseeker",
  });
  const [role, setRole] = useState("jobseeker");

  const [isAdminRegistrationAllowed, setIsAdminRegistrationAllowed] =
    useState(true);

  const isAdminUnavailable = role === "admin" && !isAdminRegistrationAllowed;

  useEffect(() => {
    let cancelled = false;
    const checkAdmin = async () => {
      try {
        const res = await fetch("http://localhost:5000/api/auth/admin/exists");
        const data = await res.json();
        if (!res.ok) return;
        if (cancelled) return;
        setIsAdminRegistrationAllowed(!data?.exists);
      } catch {
        // If the check fails, don't block registration UI.
      }
    };
    checkAdmin();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleRegister = async () => {
    try {
      if (!String(formData.name || "").trim()) {
        alert("Full name is required.");
        return;
      }
      if (!String(formData.email || "").trim()) {
        alert("Email is required.");
        return;
      }
      if (!String(formData.password || "").trim()) {
        alert("Password is required.");
        return;
      }
      if (role === "admin" && !isAdminRegistrationAllowed) {
        alert("Admin registration is disabled.");
        return;
      }
      const res = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message);
        return;
      }

      alert("Registration successful");

      // redirect to login WITH previous page
      navigate("/login", {
        state: { from },
      });
    } catch (error) {
      console.error(error); // Log the error for debugging
      alert("Server error");
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 pt-24">
      <div className="bg-white w-full max-w-lg rounded-xl shadow-lg p-8">
        {/* Heading */}
        <h2 className="text-3xl font-bold text-center mb-2">
          Create Your <span className="text-orange-500">Profile</span>
        </h2>
        <p className="text-center text-gray-600 mb-8">
          Select your role and enter your details
        </p>

        {/* Role Selector */}
        <div className="flex justify-center gap-3 mb-8">
          {[
            { id: "jobseeker", label: "Job Seeker" },
            { id: "employer", label: "Employer" },
            { id: "admin", label: "Admin" },
          ].map((r) => {
            const isAdminDisabled =
              r.id === "admin" && !isAdminRegistrationAllowed;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => {
                  setRole(r.id);
                  setFormData({
                    name: "",
                    email: "",
                    password: "",
                    role: r.id,
                  });
                }}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition
                ${
                  role === r.id
                    ? "bg-orange-500 text-white border-orange-500"
                    : isAdminDisabled
                    ? "bg-white text-gray-400 border-gray-200"
                    : "bg-white text-gray-700 border-gray-300 hover:border-orange-500"
                }`}
              >
                {r.label}
              </button>
            );
          })}
        </div>

        {isAdminUnavailable && (
          <p className="text-center text-sm text-gray-600 mb-4">
            Admin account already exists.
          </p>
        )}

        {/* FORM */}
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            handleRegister();
          }}
        >
          {/* Common Fields */}
          <div>
            <label className="block text-sm font-medium mb-1">Full Name</label>
            <input
              type="text"
              placeholder="Your full name"
              required
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              placeholder="you@example.com"
              required
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              type="password"
              placeholder="••••••••"
              required
              value={formData.password}
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
              className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-orange-400"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isAdminUnavailable}
            className={`w-full py-2 rounded-lg font-semibold transition ${
              isAdminUnavailable
                ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                : "bg-orange-500 text-white hover:bg-orange-600"
            }`}
          >
            Create{" "}
            {role === "jobseeker"
              ? "Job Seeker"
              : role === "employer"
              ? "Employer"
              : "Admin"}{" "}
            Profile
          </button>
        </form>
      </div>
    </div>
  );
}
