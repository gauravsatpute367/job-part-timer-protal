import { useParams, useNavigate, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function JobDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);

  const loggedIn = isLoggedIn();
  const userRole = getUserRole();

  useEffect(() => {
    fetch(`http://localhost:5000/api/jobs/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setJob(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [id]);

  useEffect(() => {
    if (!loggedIn || userRole !== "jobseeker") return;
    const token = localStorage.getItem("token");
    fetch(`http://localhost:5000/api/applications/job/${id}/me`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data) => setApplied(Boolean(data.applied)))
      .catch((err) => console.error("Check application failed", err));
  }, [id, loggedIn, userRole]);

  const handleApply = async () => {
    // Guard: only job seekers can apply
    if (!loggedIn) {
      alert("Please login to apply");
      navigate("/login", { state: { from: `/jobs/${id}` } });
      return;
    }

    if (userRole !== "jobseeker") {
      alert("Only job seekers can apply for jobs");
      return;
    }

    try {
      setApplying(true);
      const token = localStorage.getItem("token");

      // Get logged-in user ID from token (decode) or store in localStorage during login
      // const userId = localStorage.getItem("userId"); // Add this during login

      const res = await fetch("http://localhost:5000/api/applications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          jobId: job._id, // ✅ Sirf jobId bhejo
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message || "Failed to apply");
        setApplying(false);
        return;
      }

      setApplied(true);
      alert("Application submitted successfully");
    } catch (error) {
      console.error(error);
      alert("Something went wrong");
      setApplying(false);
    }
  };

  if (loading) {
    return <div className="pt-24 text-center">Loading job...</div>;
  }

  if (!job || job.message) {
    return <div className="pt-24 text-center text-gray-600">Job not found</div>;
  }

  const companyName = job.company?.name || "N/A";
  const jobType = job.jobType || "N/A";
  const locationType = job.locationType || "N/A";
  const duration = job.duration || "N/A";
  const paymentAmount = job.payment?.amount ?? "N/A";
  const paymentType = job.payment?.type ?? "";
  const responsibilities = Array.isArray(job.responsibilities)
    ? job.responsibilities
    : [];
  const requirements = Array.isArray(job.requirements) ? job.requirements : [];
  const skills = Array.isArray(job.skills) ? job.skills : [];

  const canApply =
    loggedIn && userRole === "jobseeker" && job.status !== "Closed";

  return (
    <div className="min-h-screen bg-gray-50 px-6 py-10 pt-24">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* ===== BASIC JOB INFO ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h1 className="text-3xl font-bold mb-2">{job.title}</h1>
          <p className="text-gray-600 mb-4">
            {companyName} • {locationType} • {jobType}
          </p>

          <div className="flex flex-wrap gap-3 text-sm">
            <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full">
              {jobType}
            </span>
            <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full">
              {locationType}
            </span>
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
              {duration}
            </span>
          </div>
        </div>

        {/* ===== PAYMENT DETAILS ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Payment Details</h2>
          <p className="text-gray-700">
            <strong>Amount:</strong> {paymentAmount}
          </p>
          <p className="text-gray-700">
            <strong>Payment Type:</strong> {paymentType || "N/A"}
          </p>
        </div>

        {/* ===== JOB DESCRIPTION ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Job Description</h2>
          <p className="text-gray-700 leading-relaxed">{job.description}</p>
        </div>

        {/* ===== RESPONSIBILITIES ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Responsibilities</h2>
          <ul className="list-disc pl-6 text-gray-700 space-y-2">
            {responsibilities.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>

        {/* ===== REQUIREMENTS ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Requirements</h2>
          <ul className="list-disc pl-6 text-gray-700 space-y-2">
            {requirements.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>

        {/* ===== SKILLS REQUIRED ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Skills Required</h2>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <span
                key={index}
                className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* ===== APPLICATION DETAILS ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Application Details</h2>
          <p className="text-gray-700">
            <strong>Number of Openings:</strong>{" "}
            {job.applicationDetails?.openings ?? "N/A"}
          </p>
          <p className="text-gray-700">
            <strong>Last Date to Apply:</strong>{" "}
            {job.applicationDetails?.lastDate ?? "N/A"}
          </p>
        </div>

        {/* ===== COMPANY INFO ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Company Information</h2>
          <p className="text-gray-700">
            <strong>Company:</strong> {companyName}
          </p>
          <p className="text-gray-700">
            <strong>Industry:</strong> {job.company.industry}
          </p>
          <p className="text-gray-700">
            <strong>Location:</strong> {job.company.city}, {job.company.state}
          </p>

          {job.employerId && loggedIn && (
            <div className="mt-4">
              <Link
                to={`/users/${job.employerId}/profile`}
                className="inline-block border border-orange-500 text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-orange-50 transition"
              >
                View Employer Profile
              </Link>
            </div>
          )}
        </div>

        {/* ===== APPLY SECTION ===== */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Apply for this Job</h2>
          <p className="text-gray-600 mb-4">
            {!loggedIn
              ? "Please login as a job seeker to apply."
              : userRole === "employer"
              ? "Employers cannot apply to jobs."
              : "Click the button below to apply. Your profile will be reviewed by the employer."}
          </p>
          <button
            disabled={!canApply || applying || applied}
            onClick={handleApply}
            className={`px-6 py-3 rounded-lg font-semibold ${
              !canApply || applied
                ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                : "bg-orange-500 text-white hover:bg-orange-600"
            }`}
          >
            {job.status === "Closed"
              ? "Job Closed"
              : !loggedIn
              ? "Login to Apply"
              : userRole === "employer"
              ? "Not Eligible"
              : applied
              ? "Applied"
              : applying
              ? "Applying..."
              : "Apply Now"}
          </button>
        </div>
      </div>
    </div>
  );
}
