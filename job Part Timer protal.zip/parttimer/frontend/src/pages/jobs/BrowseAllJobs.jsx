import { Link } from "react-router-dom";
import { useEffect, useState } from "react";

export default function AllJobs() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [jobType, setJobType] = useState("All");
  const [locationType, setLocationType] = useState("All");
  const [status, setStatus] = useState("Active");

  useEffect(() => {
    fetch("http://localhost:5000/api/jobs")
      .then((res) => res.json())
      .then((data) => {
        setJobs(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching jobs:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="pt-24 text-center text-gray-600">Loading jobs...</div>
    );
  }

  const filteredJobs = jobs.filter((job) => {
    const title = (job.title || "").toLowerCase();
    const companyName = (job.company?.name || "").toLowerCase();
    const q = search.trim().toLowerCase();

    const searchOk = !q || title.includes(q) || companyName.includes(q);
    const jobTypeOk = jobType === "All" || job.jobType === jobType;
    const locationOk =
      locationType === "All" || job.locationType === locationType;
    const statusOk = status === "All" || (job.status || "Active") === status;

    return searchOk && jobTypeOk && locationOk && statusOk;
  });

  return (
    <div className="h-screen bg-gray-50 flex flex-col pt-24">
      {/* HEADER */}
      <div className="px-6 py-8">
        <div className="max-w-7xl mx-auto w-full">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">
              Browse <span className="text-orange-500">Jobs</span>
            </h1>
            <p className="text-gray-600 mt-1">
              Explore part-time and flexible job opportunities
            </p>
          </div>

          {/* FILTERS */}
          <div className="bg-white rounded-xl shadow p-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by job title or company..."
              className="w-full md:max-w-md border rounded-lg px-3 py-2"
            />

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <select
                value={jobType}
                onChange={(e) => setJobType(e.target.value)}
                className="w-full sm:w-auto border rounded-lg px-3 py-2"
              >
                <option value="All">All Job Types</option>
                <option value="Part-time">Part-time</option>
                <option value="Internship">Internship</option>
                <option value="Freelance">Freelance</option>
                <option value="Mentorship">Mentorship</option>
                <option value="Labour">Labour</option>
              </select>

              <select
                value={locationType}
                onChange={(e) => setLocationType(e.target.value)}
                className="w-full sm:w-auto border rounded-lg px-3 py-2"
              >
                <option value="All">All Locations</option>
                <option value="Remote">Remote</option>
                <option value="Onsite">Onsite</option>
                <option value="Hybrid">Hybrid</option>
              </select>

              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full sm:w-auto border rounded-lg px-3 py-2"
              >
                <option value="Active">Active</option>
                <option value="All">All Status</option>
                <option value="Closed">Closed</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* JOB LIST */}
      <div className="flex-1 overflow-y-auto px-6 pb-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredJobs.length === 0 && (
            <p className="text-gray-600">No jobs found.</p>
          )}

          {filteredJobs.map((job) => (
            <div
              key={job._id}
              className="bg-white rounded-xl shadow p-6 flex flex-col justify-between"
            >
              <div>
                <h3 className="text-xl font-semibold mb-1">{job.title}</h3>

                {/* ✅ COMPANY NAME */}
                <p className="text-gray-600 text-sm mb-3">
                  {job.company?.name}
                </p>

                <div className="flex flex-wrap gap-2 text-sm mb-4">
                  <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full">
                    {job.jobType}
                  </span>

                  <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full">
                    {job.locationType}
                  </span>

                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                    {job.duration}
                  </span>
                </div>
              </div>

              <div className="mt-4">
                <Link
                  to={`/jobs/${job._id}`}
                  className="border border-orange-500 text-orange-500 px-4 py-2 rounded-lg font-medium hover:bg-orange-50 transition"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
