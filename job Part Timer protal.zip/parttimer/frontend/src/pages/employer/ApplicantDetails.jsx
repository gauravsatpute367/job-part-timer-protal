import { useEffect, useState } from "react";
import { formatDateTime } from "../../utils/date";
import { useParams, useNavigate, Link } from "react-router-dom";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function ViewApplication() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [application, setApplication] = useState(null);
  const token = localStorage.getItem("token");
  const [loading, setLoading] = useState(Boolean(token));
  const [error, setError] = useState(
    token ? "" : "Auth token missing. Please login again."
  );

  useEffect(() => {
    if (!isLoggedIn()) {
      navigate("/login", { state: { from: `/employer/applications/${id}` } });
      return;
    }
    if (getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    if (!token) return;
    fetch(`http://localhost:5000/api/applications/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load application");
        setApplication(data);
      })
      .catch((err) => setError(err.message || "Server error"))
      .finally(() => setLoading(false));
  }, [id, navigate, token]);

  const updateStatus = async (newStatus) => {
    const token = localStorage.getItem("token");
    const res = await fetch(`http://localhost:5000/api/applications/${id}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status: newStatus }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Failed to update");
    setApplication((prev) => ({ ...prev, status: newStatus }));
    alert(`Application ${newStatus}`);
  };

  if (loading) return <div className="pt-24 text-center">Loading...</div>;
  if (error)
    return <div className="pt-24 text-center text-red-600">{error}</div>;
  if (!application)
    return <div className="pt-24 text-center">Application not found</div>;

  const { job = {}, jobSeeker = {} } = application;

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Application Details</h1>
          <p className="text-gray-600 mt-1">Review applicant information</p>
        </div>

        {/* Job Info */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-2">Job Information</h2>
          <p>
            <strong>Job Title:</strong> {job.title}
          </p>
          <p>
            <strong>Company:</strong> {job.company?.name}
          </p>
          <p>
            <strong>Job Type:</strong> {job.jobType}
          </p>
          <p>
            <strong>Location:</strong> {job.locationType}
          </p>
          <p>
            <strong>Duration:</strong> {job.duration}
          </p>
          <p>
            <strong>Payment:</strong> {job.payment?.amount} ({job.payment?.type}
            )
          </p>
          <p>
            <strong>Applied:</strong> {formatDateTime(application.createdAt)}
          </p>
          <p>
            <strong>Last Updated:</strong>{" "}
            {formatDateTime(application.updatedAt || application.createdAt)}
          </p>
          <p>
            <strong>Status:</strong>{" "}
            <span className="font-medium">{application.status}</span>
          </p>
        </div>

        {/* Applicant Info */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Applicant</h2>
          <p>
            <strong>Name:</strong> {jobSeeker.name || "Unknown"}
          </p>
          <p>
            <strong>Email:</strong> {jobSeeker.email || "N/A"}
          </p>
          {jobSeeker?._id && (
            <div className="mt-4">
              <Link
                to={`/users/${jobSeeker._id}/profile`}
                className="inline-block border border-orange-500 text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-orange-50 transition"
              >
                View Job Seeker Profile
              </Link>
            </div>
          )}
        </div>

        {/* Skills */}
        {job.skills?.length ? (
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-3">Skills</h2>
            <div className="flex flex-wrap gap-2">
              {job.skills.map((skill, i) => (
                <span key={i} className="px-3 py-1 bg-blue-100 rounded-full">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        ) : null}

        {/* Job Requirements */}
        {job.requirements?.length ? (
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-3">Job Requirements</h2>
            <ul className="list-disc pl-6 text-gray-700 space-y-1">
              {job.requirements.map((req, i) => (
                <li key={i}>{req}</li>
              ))}
            </ul>
          </div>
        ) : null}

        {/* Actions */}
        <div className="bg-white rounded-xl shadow p-6 flex gap-4">
          <button
            onClick={() => updateStatus("Accepted")}
            disabled={application.status !== "Applied"}
            className={`bg-green-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition ${
              application.status !== "Applied"
                ? "opacity-60 cursor-not-allowed"
                : ""
            }`}
          >
            Accept
          </button>

          <button
            onClick={() => updateStatus("Rejected")}
            disabled={application.status !== "Applied"}
            className={`bg-red-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-600 transition ${
              application.status !== "Applied"
                ? "opacity-60 cursor-not-allowed"
                : ""
            }`}
          >
            Reject
          </button>

          <button
            onClick={() => navigate(-1)}
            className="border border-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            Back
          </button>
        </div>
      </div>
    </div>
  );
}
