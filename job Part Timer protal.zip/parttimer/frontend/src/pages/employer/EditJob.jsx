import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function EditJob() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    jobType: "",
    locationType: "",
    duration: "",
    companyName: "",
    companyIndustry: "",
    companyCity: "",
    companyState: "",
    paymentAmount: "",
    paymentType: "",
    description: "",
    responsibilities: "",
    requirements: "",
    skills: "",
    openings: "",
    lastDate: "",
    autoRemoveDate: "",
  });

  useEffect(() => {
    if (!isLoggedIn() || getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    const token = localStorage.getItem("token");
    fetch(`http://localhost:5000/api/jobs/${jobId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to load job");
        setFormData({
          title: data.title,
          jobType: data.jobType,
          locationType: data.locationType,
          duration: data.duration,
          companyName: data.company?.name || "",
          companyIndustry: data.company?.industry || "",
          companyCity: data.company?.city || "",
          companyState: data.company?.state || "",
          paymentAmount: data.payment?.amount || "",
          paymentType: data.payment?.type || "",
          description: data.description || "",
          responsibilities: (data.responsibilities || []).join("\n"),
          requirements: (data.requirements || []).join("\n"),
          skills: (data.skills || []).join(","),
          openings: data.applicationDetails?.openings || "",
          lastDate: data.applicationDetails?.lastDate || "",
          autoRemoveDate: data.expiresAt
            ? new Date(data.expiresAt).toISOString().slice(0, 10)
            : "",
        });
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message || "Server error");
        setLoading(false);
      });
  }, [jobId, navigate]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem("token");

    const requireText = (value, label) => {
      if (!String(value || "").trim()) {
        alert(`${label} is required.`);
        return false;
      }
      return true;
    };

    if (!requireText(formData.companyIndustry, "Industry")) return;
    if (!requireText(formData.companyCity, "City")) return;
    if (!requireText(formData.companyState, "State")) return;
    if (!requireText(formData.autoRemoveDate, "Auto remove job on")) return;

    const responsibilities = String(formData.responsibilities || "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!responsibilities.length) {
      alert("At least one responsibility is required.");
      return;
    }

    const requirements = String(formData.requirements || "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!requirements.length) {
      alert("At least one requirement is required.");
      return;
    }

    const skills = String(formData.skills || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!skills.length) {
      alert("At least one skill is required.");
      return;
    }

    const payload = {
      title: formData.title,
      jobType: formData.jobType,
      locationType: formData.locationType,
      duration: formData.duration,
      company: {
        name: formData.companyName,
        industry: formData.companyIndustry,
        city: formData.companyCity,
        state: formData.companyState,
      },
      payment: {
        amount: formData.paymentAmount,
        type: formData.paymentType,
      },
      description: formData.description,
      responsibilities,
      requirements,
      skills,
      applicationDetails: {
        openings: Number(formData.openings),
        lastDate: formData.lastDate,
      },
      expiresAt: new Date(
        `${formData.autoRemoveDate}T23:59:59.999`
      ).toISOString(),
    };

    try {
      const res = await fetch(`http://localhost:5000/api/jobs/${jobId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to update job");
      alert("Job updated successfully");
      navigate(`/employer/jobs/${jobId}`);
    } catch (err) {
      alert(err.message || "Error updating job");
    }
  };

  if (loading) {
    return (
      <div className="pt-24 text-center text-gray-600">Loading job...</div>
    );
  }

  if (error) {
    return <div className="pt-24 text-center text-red-600">{error}</div>;
  }

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto bg-white rounded-xl shadow p-6 space-y-6">
        <h1 className="text-3xl font-bold">Edit Job</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Job Information */}
          <div>
            <h2 className="text-xl font-semibold mb-3">
              Basic Job Information
            </h2>

            <input
              name="title"
              placeholder="Job Title"
              value={formData.title}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              required
            />

            <select
              name="jobType"
              value={formData.jobType}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              required
            >
              <option value="">Select Job Type</option>
              <option>Part-time</option>
              <option>Internship</option>
              <option>Freelance</option>
              <option>Mentorship</option>
              <option>Labour</option>
            </select>

            <select
              name="locationType"
              value={formData.locationType}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              required
            >
              <option value="">Select Location Type</option>
              <option>Remote</option>
              <option>Onsite</option>
              <option>Hybrid</option>
            </select>

            <input
              name="duration"
              placeholder="Duration (e.g. 3–6 months)"
              value={formData.duration}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              required
            />

            <input
              name="companyName"
              placeholder="Company Name"
              value={formData.companyName}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
              <input
                name="companyIndustry"
                placeholder="Industry"
                value={formData.companyIndustry}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2"
                required
              />
              <input
                name="companyCity"
                placeholder="City"
                value={formData.companyCity}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2"
                required
              />
              <input
                name="companyState"
                placeholder="State"
                value={formData.companyState}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>
          </div>

          {/* Payment Details */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Payment Details</h2>
            <input
              name="paymentAmount"
              placeholder="Payment Amount"
              value={formData.paymentAmount}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              required
            />
            <select
              name="paymentType"
              value={formData.paymentType}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            >
              <option value="">Payment Type</option>
              <option>Monthly</option>
              <option>Daily</option>
              <option>Hourly</option>
            </select>
          </div>

          {/* Job Description */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Job Description</h2>
            <textarea
              name="description"
              rows="4"
              value={formData.description}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Responsibilities */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Responsibilities</h2>
            <textarea
              name="responsibilities"
              rows="4"
              placeholder="One responsibility per line"
              value={formData.responsibilities}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Requirements */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Requirements</h2>
            <textarea
              name="requirements"
              rows="4"
              placeholder="One requirement per line"
              value={formData.requirements}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Skills */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Skills Required</h2>
            <input
              name="skills"
              placeholder="Comma separated skills"
              value={formData.skills}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Application Details */}
          <div>
            <h2 className="text-xl font-semibold mb-3">Application Details</h2>
            <input
              name="openings"
              type="number"
              placeholder="Number of Openings"
              value={formData.openings}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2 mb-3"
              min={1}
              required
            />
            <input
              name="lastDate"
              type="date"
              value={formData.lastDate}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
              required
            />

            <div className="mt-3">
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                Auto remove job on
              </label>
              <input
                name="autoRemoveDate"
                type="date"
                value={formData.autoRemoveDate}
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                This job will be automatically deleted after that date.
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600"
            >
              Save Changes
            </button>

            <button
              type="button"
              onClick={() => navigate(-1)}
              className="border border-gray-300 px-6 py-3 rounded-lg font-semibold"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
