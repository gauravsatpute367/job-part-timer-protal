import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { isLoggedIn, getUserRole } from "../../utils/auth";
import { formatDate } from "../../utils/date";

export default function EmployerJobApplications() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isLoggedIn() || getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    const token = localStorage.getItem("token");

    // Fetch job details
    fetch(`http://localhost:5000/api/jobs/${jobId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to load job");
        setJob(data);
      })
      .catch((err) => {
        setError(err.message || "Server error");
        setLoading(false);
      });

    // Fetch applications for this job
    fetch(`http://localhost:5000/api/applications/job/${jobId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load applications");
        setApplications(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message || "Server error");
        setLoading(false);
      });
  }, [jobId, navigate]);

  const handleStatusChange = async (appId, newStatus) => {
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(
        `http://localhost:5000/api/applications/${appId}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ status: newStatus }),
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to update status");

      // Update local state
      setApplications((prev) =>
        prev.map((app) =>
          app._id === appId ? { ...app, status: newStatus } : app
        )
      );
      alert(`Application ${newStatus}`);
    } catch (err) {
      alert(err.message || "Error updating application");
    }
  };

  if (loading) {
    return (
      <div className="pt-24 text-center text-gray-600">
        Loading applications...
      </div>
    );
  }

  if (error) {
    return <div className="pt-24 text-center text-red-600">{error}</div>;
  }

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">
            Applications for: {job?.title || "Job"}
          </h1>
          <p className="text-gray-600 mt-1">
            Total applications: {applications.length}
          </p>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 text-left">No.</th>
                <th className="p-4 text-left">Applicant Name</th>
                <th className="p-4 text-left">Email</th>
                <th className="p-4 text-left">Applied Date</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>

            <tbody>
              {applications.map((app, index) => (
                <tr key={app._id} className="border-t">
                  <td className="p-4">{index + 1}</td>
                  <td className="p-4 font-medium">
                    {app.jobSeeker?.name || "Unknown"}
                  </td>
                  <td className="p-4">{app.jobSeeker?.email || "N/A"}</td>
                  <td className="p-4">{formatDate(app.createdAt)}</td>
                  <td className="p-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        app.status === "Applied"
                          ? "bg-blue-100 text-blue-700"
                          : app.status === "Accepted"
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {app.status}
                    </span>
                  </td>
                  <td className="p-4 flex gap-2">
                    <Link
                      to={`/employer/applications/${app._id}`}
                      className="px-3 py-1 rounded text-sm font-medium border border-blue-500 text-blue-600 hover:bg-blue-50"
                    >
                      View
                    </Link>
                    <button
                      onClick={() => handleStatusChange(app._id, "Accepted")}
                      disabled={app.status !== "Applied"}
                      className={`px-3 py-1 rounded text-sm font-medium ${
                        app.status !== "Applied"
                          ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                          : "bg-green-500 text-white hover:bg-green-600"
                      }`}
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => handleStatusChange(app._id, "Rejected")}
                      disabled={app.status !== "Applied"}
                      className={`px-3 py-1 rounded text-sm font-medium ${
                        app.status !== "Applied"
                          ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                          : "bg-red-500 text-white hover:bg-red-600"
                      }`}
                    >
                      Reject
                    </button>
                  </td>
                </tr>
              ))}

              {applications.length === 0 && (
                <tr>
                  <td colSpan="6" className="p-6 text-center text-gray-500">
                    No applications for this job yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
