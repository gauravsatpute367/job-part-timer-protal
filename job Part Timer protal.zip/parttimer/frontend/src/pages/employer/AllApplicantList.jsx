import { useEffect, useState } from "react";
import { formatDate } from "../../utils/date";
import { Link, useNavigate } from "react-router-dom";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function EmployerApplications() {
  const navigate = useNavigate();
  const [applications, setApplications] = useState([]);
  const token = localStorage.getItem("token");
  const [loading, setLoading] = useState(Boolean(token));
  const [error, setError] = useState(
    token ? "" : "Auth token missing. Please login again."
  );

  useEffect(() => {
    if (!isLoggedIn()) {
      navigate("/login", { state: { from: "/employer/applications" } });
      return;
    }
    if (getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    if (!token) return;

    fetch("http://localhost:5000/api/applications/mine", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok)
          throw new Error(data.message || "Failed to load applications");
        setApplications(data || []);
      })
      .catch((err) => setError(err.message || "Failed to load applications"))
      .finally(() => setLoading(false));
  }, [navigate, token]);

  if (loading) {
    return <div className="pt-24 px-6">Loading applications...</div>;
  }

  if (error) {
    return <div className="pt-24 px-6 text-red-600">{error}</div>;
  }

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Job Applications</h1>
          <p className="text-gray-600 mt-1">
            All applications received across your posted jobs
          </p>
        </div>

        {/* Applications Table */}
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 text-left">No.</th>
                <th className="p-4 text-left">Applicant Name</th>
                <th className="p-4 text-left">Job Title</th>
                <th className="p-4 text-left">Applied Date</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left">Action</th>
              </tr>
            </thead>

            <tbody>
              {applications.length === 0 ? (
                <tr>
                  <td colSpan="6" className="p-6 text-center text-gray-500">
                    No applications received yet.
                  </td>
                </tr>
              ) : (
                applications.map((app, index) => (
                  <tr key={app._id} className="border-t">
                    <td className="p-4">{index + 1}</td>
                    <td className="p-4 font-medium">
                      {app.jobSeeker?.name || app.jobSeeker?.email || "—"}
                    </td>
                    <td className="p-4">
                      <div className="font-medium">{app.job?.title}</div>
                      <div className="text-sm text-gray-500">
                        {app.job?.company?.name} • {app.job?.locationType}
                      </div>
                    </td>
                    <td className="p-4">{formatDate(app.createdAt)}</td>
                    <td className="p-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm ${
                          app.status === "Applied"
                            ? "bg-yellow-100 text-yellow-700"
                            : app.status === "Accepted"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="p-4">
                      <Link
                        to={`/employer/applications/${app._id}`}
                        className="text-blue-600 font-medium hover:underline"
                      >
                        View Application
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
