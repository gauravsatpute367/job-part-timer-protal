import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function EmployerJobDetails() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isLoggedIn() || getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    const fetchJob = async () => {
      setLoading(true);
      setError("");

      try {
        const token = localStorage.getItem("token");
        const res = await fetch(`http://localhost:5000/api/jobs/${jobId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.message || "Failed to load job");

        setJob(data);
      } catch (err) {
        setError(err.message || "Server error");
      } finally {
        setLoading(false);
      }
    };

    fetchJob();
  }, [jobId, navigate]);

  const handleCloseJob = async () => {
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(`http://localhost:5000/api/jobs/${jobId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: "Closed" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to close job");
      setJob(data.job);
      alert("Job closed successfully");
    } catch (err) {
      alert(err.message || "Error closing job");
    }
  };

  if (loading) {
    return (
      <div className="pt-24 px-6 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading job details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pt-24 px-6 min-h-screen">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
            <p className="text-red-600">{error}</p>
          </div>
          <Link
            to="/employer/my-jobs"
            className="inline-block bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            ← Back to My Jobs
          </Link>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="pt-24 px-6 min-h-screen">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-gray-600 mb-6">Job not found</p>
          <Link
            to="/employer/my-jobs"
            className="inline-block bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            ← Back to My Jobs
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">{job.title}</h1>
          <p className="text-gray-600 mt-1">
            {job.company?.name} • {job.locationType}
          </p>
        </div>

        {/* Overview */}
        <div className="bg-white rounded-xl shadow p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <p>
            <strong>Job Type:</strong> {job.jobType}
          </p>
          <p>
            <strong>Duration:</strong> {job.duration}
          </p>
          <p>
            <strong>Payment:</strong> {job.payment?.amount} ({job.payment?.type}
            )
          </p>
          <p>
            <strong>Status:</strong>{" "}
            <span
              className={`px-2 py-1 rounded text-sm font-medium ${
                job.status === "Active"
                  ? "bg-green-100 text-green-700"
                  : "bg-red-100 text-red-700"
              }`}
            >
              {job.status || "Active"}
            </span>
          </p>
        </div>

        {/* Description */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Job Description</h2>
          <p className="text-gray-700">{job.description}</p>
        </div>

        {/* Responsibilities */}
        {job.responsibilities && job.responsibilities.length > 0 && (
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-3">Responsibilities</h2>
            <ul className="list-disc pl-6 text-gray-700 space-y-1">
              {job.responsibilities.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Requirements */}
        {job.requirements && job.requirements.length > 0 && (
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-3">Requirements</h2>
            <ul className="list-disc pl-6 text-gray-700 space-y-1">
              {job.requirements.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Skills */}
        {job.skills && job.skills.length > 0 && (
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-xl font-semibold mb-3">Skills Required</h2>
            <div className="flex flex-wrap gap-2">
              {job.skills.map((skill, i) => (
                <span
                  key={i}
                  className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Application Details */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Application Details</h2>
          <p>
            <strong>Openings:</strong>{" "}
            {job.applicationDetails?.openings || "N/A"}
          </p>
          <p>
            <strong>Last Date:</strong>{" "}
            {job.applicationDetails?.lastDate || "N/A"}
          </p>
        </div>

        {/* Actions */}
        <div className="bg-white rounded-xl shadow p-6 flex flex-wrap gap-4">
          <Link
            to={`/employer/jobs/${job._id}/applications`}
            className="bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            📥 View Applications
          </Link>

          <Link
            to={`/employer/jobs/${job._id}/edit`}
            className="border border-blue-500 text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition"
          >
            ✏️ Edit Job
          </Link>

          <button
            onClick={handleCloseJob}
            disabled={job.status === "Closed"}
            className={`px-6 py-3 rounded-lg font-semibold transition ${
              job.status === "Closed"
                ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                : "bg-red-500 text-white hover:bg-red-600"
            }`}
          >
            {job.status === "Closed" ? "Job Closed" : "Close Job"}
          </button>
        </div>
      </div>
    </div>
  );
}
