import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { isLoggedIn, getUserRole } from "../../utils/auth";

export default function MyPostedJobs() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    // Guard: only employers
    if (!isLoggedIn()) {
      navigate("/login", { state: { from: "/employer/my-jobs" } });
      return;
    }
    if (getUserRole() !== "employer") {
      navigate("/dashboard");
      return;
    }

    const token = localStorage.getItem("token");
    fetch("http://localhost:5000/api/jobs/mine", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to load jobs");
        setJobs(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message || "Server error");
        setLoading(false);
      });
  }, [navigate]);

  if (loading) {
    return (
      <div className="pt-24 px-6">
        <div className="max-w-7xl mx-auto">Loading your jobs...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pt-24 px-6">
        <div className="max-w-7xl mx-auto text-red-600">{error}</div>
      </div>
    );
  }

  return (
    <div className="pt-24 px-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">My Posted Jobs</h1>
          <p className="text-gray-600 mt-1">
            Manage and track your posted jobs
          </p>
        </div>

        {/* Jobs Table */}
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full border-collapse">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 text-left">No.</th>
                <th className="p-4 text-left">Job Title</th>
                <th className="p-4 text-left">Type</th>
                <th className="p-4 text-left">Location</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left">Applications</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>

            <tbody>
              {jobs.length === 0 && (
                <tr>
                  <td className="p-4 text-gray-600" colSpan={7}>
                    No jobs posted yet.
                  </td>
                </tr>
              )}

              {jobs.map((job, index) => (
                <tr key={job._id} className="border-t">
                  <td className="p-4">{index + 1}</td>
                  <td className="p-4 font-medium">{job.title}</td>
                  <td className="p-4">{job.jobType}</td>
                  <td className="p-4">{job.locationType}</td>
                  <td className="p-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        (job.status || "Active") === "Active"
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {job.status || "Active"}
                    </span>
                  </td>

                  <td className="p-4">{job.applications || 0}</td>
                  <td className="p-4 flex gap-3">
                    <Link
                      to={`/employer/jobs/${job._id}`}
                      className="text-orange-600 font-medium hover:underline"
                    >
                      View Job
                    </Link>

                    <Link
                      to={`/employer/jobs/${job._id}/applications`}
                      className="text-blue-600 font-medium hover:underline"
                    >
                      View Applications
                    </Link>
                    <Link
                      to={`/employer/jobs/${job._id}/edit`}
                      className="text-green-600 font-medium hover:underline"
                    >
                      Edit
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
