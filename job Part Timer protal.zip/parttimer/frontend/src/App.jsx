import { Routes, Route } from "react-router-dom";
import Navbar from "../src/components/Navbar";
import Index from "./pages/home/Index";
import Login from "./pages/auth/Login";
import BrowseAllJobs from "./pages/jobs/BrowseAllJobs";
import BrowseJobDetails from "./pages/jobs/BrowseJobDetails";
import CreateProfile from "./pages/auth/CreateProfile";
import Dashboard from "./pages/dashboard/Dashboard";

import PostJob from "./pages/employer/PostJob";
import MyJobs from "./pages/employer/MyJobs";
import EmployerJobDetails from "./pages/employer/JobDetails";
import EditJob from "./pages/employer/EditJob";
import AllApplicantList from "./pages/employer/AllApplicantList";
import JobApplications from "./pages/employer/JobApplications";
import ApplicantDetails from "./pages/employer/ApplicantDetails";

import ApplicationDetailsJobseeker from "./pages/jobseeker/ApplicationDetailsJobseeker";
import MyApplications from "./pages/jobseeker/MyApplications";

import ViewProfile from "./pages/profile/ViewProfile";
import EditProfile from "./pages/profile/EditProfile";

import Employers from "./pages/admin/Employers";
import JobSeekers from "./pages/admin/JobSeekers";
import AdminActivities from "./pages/admin/Activities";
import AdminJobSeekerApplications from "./pages/admin/JobSeekerApplications";
import AdminEmployerJobs from "./pages/admin/EmployerJobs";
import AdminAllJobs from "./pages/admin/AllJobs";
import AdminAllApplications from "./pages/admin/AllApplications";

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/login" element={<Login />} />
        <Route path="/jobs" element={<BrowseAllJobs />} />
        <Route path="/profile-create" element={<CreateProfile />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/employer/post-job" element={<PostJob />} />
        <Route path="/jobs/:id" element={<BrowseJobDetails />} />
        <Route path="/employer/my-jobs" element={<MyJobs />} />
        <Route path="/employer/applications" element={<AllApplicantList />} />
        <Route
          path="/employer/jobs/:jobId/applications"
          element={<JobApplications />}
        />
        <Route
          path="/employer/applications/:id"
          element={<ApplicantDetails />}
        />
        <Route path="/employer/jobs/:jobId" element={<EmployerJobDetails />} />
        <Route path="/employer/jobs/:jobId/edit" element={<EditJob />} />
        <Route
          path="/jobseeker/applications/:id"
          element={<ApplicationDetailsJobseeker />}
        />
        <Route path="/jobseeker/my-applications" element={<MyApplications />} />
        <Route path="/admin/employers" element={<Employers />} />
        <Route path="/admin/jobseekers" element={<JobSeekers />} />
        <Route path="/admin/activities" element={<AdminActivities />} />
        <Route path="/admin/jobs" element={<AdminAllJobs />} />
        <Route path="/admin/applications" element={<AdminAllApplications />} />
        <Route
          path="/admin/jobseekers/:id/applications"
          element={<AdminJobSeekerApplications />}
        />
        <Route
          path="/admin/employers/:id/jobs"
          element={<AdminEmployerJobs />}
        />

        {/* Profiles */}
        <Route path="/profile" element={<ViewProfile />} />
        <Route path="/profile/edit" element={<EditProfile />} />
        <Route path="/users/:id/profile" element={<ViewProfile />} />
      </Routes>
    </>
  );
}
