const BACKEND_BASE = "http://localhost:5000";

export const getDefaultProfilePic = (role, gender) => {
  const g = String(gender || "").toLowerCase();
  const r = String(role || "").toLowerCase();

  if (g === "other") {
    // Neutral fallback for "other" unless pride avatar is explicitly enabled.
    if (r === "employer") return "/DefaultProfilePics/MaleEmployerPic.jpg";
    if (r === "jobseeker") return "/DefaultProfilePics/MaleJobSeekerPic.jpg";
    return "/DefaultProfilePics/MaleJobSeekerPic.jpg";
  }

  const isFemale = g === "female";

  if (r === "jobseeker") {
    return isFemale
      ? "/DefaultProfilePics/FemaleJobSeekerPic.jpg"
      : "/DefaultProfilePics/MaleJobSeekerPic.jpg";
  }

  if (r === "employer") {
    return isFemale
      ? "/DefaultProfilePics/FemaleEmployerPic.jpg"
      : "/DefaultProfilePics/MaleEmployerPic.jpg";
  }

  // Fallback
  return "/DefaultProfilePics/MaleJobSeekerPic.jpg";
};

export const getDefaultProfilePicFromPreset = (avatarPreset) => {
  const p = String(avatarPreset || "").trim();
  const allowed = new Set([
    "MaleJobSeekerPic.jpg",
    "FemaleJobSeekerPic.jpg",
    "MaleEmployerPic.jpg",
    "FemaleEmployerPic.jpg",
  ]);
  if (!allowed.has(p)) return "";
  return `/DefaultProfilePics/${p}`;
};

export const resolveProfilePhotoUrl = (
  profilePhotoPath,
  role,
  gender,
  avatarPreset,
  usePrideAvatar
) => {
  const p = String(profilePhotoPath || "").trim();
  if (!p) {
    const g = String(gender || "").toLowerCase();
    if (g === "other" && Boolean(usePrideAvatar)) {
      return "/DefaultProfilePics/OtherGenderLGBTQPic.png";
    }
    const presetUrl = getDefaultProfilePicFromPreset(avatarPreset);
    return presetUrl || getDefaultProfilePic(role, gender);
  }

  if (p.startsWith("http://") || p.startsWith("https://")) return p;

  // stored as /uploads/... (backend static)
  if (p.startsWith("/")) return `${BACKEND_BASE}${p}`;

  return `${BACKEND_BASE}/${p}`;
};
