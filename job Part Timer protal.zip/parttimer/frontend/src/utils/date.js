export const formatDateTime = (value, options = {}) => {
  if (!value) return "";
  const formatter = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    dateStyle: "medium",
    timeStyle: "short",
    ...options,
  });
  return formatter.format(new Date(value));
};

export const formatDate = (value, options = {}) => {
  if (!value) return "";
  const formatter = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    dateStyle: "medium",
    ...options,
  });
  return formatter.format(new Date(value));
};
