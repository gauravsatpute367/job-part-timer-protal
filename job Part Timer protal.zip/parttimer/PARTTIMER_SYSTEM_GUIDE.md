# PartTimer — System Overview, User Flows & How to Use

This document reflects the current **feature-complete (college submission)** build of PartTimer.

PartTimer is a job portal designed for **part-time job hiring**.
It supports three roles:

- **Jobseeker**: browse jobs and apply
- **Employer**: post jobs and manage applications
- **Admin**: view platform stats and monitor activity

> Note: This document describes what is implemented in the current codebase.

> Admin moderation (warn/lock/unlock) and employer/jobseeker profiles (including local photo upload + jobseeker resume PDF upload) are implemented.

---

## Who is PartTimer for?

- **Students / jobseekers** who want part-time work
- **Businesses / employers** who want to post part-time openings
- **Admins** who want visibility into users/jobs/applications and the activity log

---

## How PartTimer works (high-level)

1. User registers as **admin / employer / jobseeker**
2. User logs in → receives a **JWT token**
3. Frontend stores token in `localStorage`
4. Backend authorizes requests using:
   - `protect` middleware (JWT)
   - role middleware (`adminOnly`, `employerOnly`, `jobSeekerOnly`)
5. Activity events are written to the `Activity` collection (audit trail)

---

## Roles & permissions (current implementation)

### Jobseeker

- Can browse all jobs
- Can view job details
- Can apply to a job (only once per job)
- Can view own applications + status
- Can upload a **resume PDF** in profile edit
- Profile details are **mandatory** when saving a profile (no blank fields). Resume upload is required for jobseekers before the profile can be saved.
- Jobseeker dashboard shows basic profile info; top-right header has quick actions (View Profile, Edit Profile, My Applications, Logout).

### Employer

- Can create job posts
- Can view own posted jobs
- Can update own jobs (including closing)
- Job posting requires an **auto-remove date** (`expiresAt`) for a job (TTL-based deletion)
- Can view applications received for own jobs
- Can accept/reject applications
- Profile details are **mandatory** when saving a profile (no blank fields).
- Employer dashboard shows basic company/profile info and job/application stats; top-right header has quick actions (View Profile, Edit Profile, Post Job, Logout).

### Admin

- Can view **admin dashboard stats** (counts)
- Can view all employers (with jobs-posted count)
- Can view all jobseekers (with applications count)
- Can view **all activities** (activity log) via activity endpoints

---

## Core user flows

## 1) Registration flow

- User selects role: `admin` / `employer` / `jobseeker`
- Backend endpoint: `POST /api/auth/register`
- Creates a `User` document
- Logs an `Activity` entry: `user_registered`

## 2) Login flow

- Backend endpoint: `POST /api/auth/login`
- Returns `{ token, user }`
- Frontend stores in `localStorage`:
  - `token`
  - `role`
  - `userName`
  - `userId`

## 3) Employer flow (post and manage jobs)

1. Employer logs in
2. Create job
   - `POST /api/jobs` (employer only)
   - Adds `employerId` automatically from token
   - Required: `expiresAt` must be set (auto-delete date/time)
   - Logs `Activity`: `job_posted`
3. View my jobs
   - `GET /api/jobs/mine` (employer only)
4. Update job
   - `PATCH /api/jobs/:id` (status update)
   - `PUT /api/jobs/:id` (full edit, ownership verified)
   - Required: `expiresAt` must be provided during full edit (auto-delete)
   - Logs `Activity`: `job_updated` / `job_closed`

## 4) Jobseeker flow (browse, apply, track status)

1. Browse jobs
   - `GET /api/jobs`
2. View a job
   - `GET /api/jobs/:id`
3. Apply
   - `POST /api/applications` (jobseeker only)
   - Body: `{ "jobId": "..." }`
   - Duplicate apply prevented by:
     - controller check + unique index on `(job, jobSeeker)`
   - Logs `Activity`: `application_submitted`
4. View my applications
   - `GET /api/applications/my-applications`
5. Check if I already applied to a job

   - `GET /api/applications/job/:jobId/me`

6. Upload resume (PDF)

   - `POST /api/users/me/resume` (jobseeker only)
   - Form field name: `resume`
   - Stores local path in `User.resumePdfPath`
   - Logs `Activity`: `profile_updated`

   Note: Resume PDFs are served from `/uploads/...` with `Content-Disposition: inline` so they open in the browser (when the browser supports PDF viewing).

7. Save profile details (mandatory)
   - `PUT /api/users/me/profile`
   - All common + role-specific profile fields are required by the platform rules.

## 5) Employer flow (review applications)

1. View applications for my jobs
   - `GET /api/applications/mine`
2. View applications for a specific job
   - `GET /api/applications/job/:jobId`
3. Accept / Reject application
   - `PATCH /api/applications/:id` with `{ status: "Accepted" | "Rejected" }`
   - Adds to `Application.statusHistory[]`
   - Logs `Activity`: `application_accepted` / `application_rejected`

## 6) Admin flow (dashboard + monitoring)

1. Admin logs in
2. Dashboard stats
   - `GET /api/auth/admin/stats`
3. View all employers (+ job counts)
   - `GET /api/auth/admin/employers`
4. View all jobseekers (+ application counts)
   - `GET /api/auth/admin/jobseekers`
5. Monitor activity log

   - `GET /api/activities` (admin sees everything)
   - `GET /api/activities/recent`
   - `GET /api/activities/stats`

6. Drill-down monitoring

   - Jobseeker applications (who applied to which jobs + statuses)
     - `GET /api/auth/admin/jobseekers/:id/applications`
   - Employer jobs (what they posted + application counts)
     - `GET /api/auth/admin/employers/:id/jobs`

7. Platform-wide lists

   - All jobs
     - `GET /api/auth/admin/jobs`
   - All applications
     - `GET /api/auth/admin/applications`

8. Moderation actions
   - Warn user (message shown after successful login)
     - `POST /api/auth/admin/users/:id/warn`
       - Required fields: `message`, `reason`
   - Lock user (message/reason shown on login; time-based supported)
     - `POST /api/auth/admin/users/:id/lock`
       - Required fields: `message`, `reason`, and either `lockDays` or `lockedUntil`
   - Unlock user
     - `POST /api/auth/admin/users/:id/unlock`

---

## Activity Log (Audit Trail)

PartTimer stores important events in the `Activity` collection.

- For **jobseekers**: they see activities where they are `user` or `targetUser`
- For **employers**: they see their own activities + activities related to their jobs
- For **admins**: they can see all activities (no filter)

Activity endpoints:

- `GET /api/activities`
- `GET /api/activities/recent`
- `GET /api/activities/stats`

---

## How to run PartTimer locally (Windows)

Prerequisites:

- Node.js (LTS)
- MongoDB (local) or MongoDB Atlas

Backend:

- `cd backend`
- `npm install`
- Create `backend/.env`:
  - `MONGO_URI=...`
  - `JWT_SECRET=...`
- `npm run dev`

Frontend:

- `cd frontend`
- `npm install`
- `npm run dev`

Default URLs:

- Backend: `http://localhost:5000`
- Frontend (Vite): typically `http://localhost:5173`

---

## API endpoints summary (by feature)

Auth

- `POST /api/auth/register`
- `POST /api/auth/login`

Admin (requires `admin` role)

- `GET /api/auth/admin/stats`
- `GET /api/auth/admin/employers`
- `GET /api/auth/admin/jobseekers`
- `GET /api/auth/admin/jobs`
- `GET /api/auth/admin/applications`
- `GET /api/auth/admin/jobseekers/:id/applications`
- `GET /api/auth/admin/employers/:id/jobs`
- `POST /api/auth/admin/users/:id/warn`
- `POST /api/auth/admin/users/:id/lock`
- `POST /api/auth/admin/users/:id/unlock`

Jobs

- `GET /api/jobs` (public)
- `GET /api/jobs/:id` (public)
- `POST /api/jobs` (employer only)
- `GET /api/jobs/mine` (employer only)
- `PATCH /api/jobs/:id` (employer only)
- `PUT /api/jobs/:id` (employer only; ownership checked)

Note: In the current implementation, job creation and full edit **require** `expiresAt` (auto-remove date/time). MongoDB TTL deletes the job after that time.

Applications

- `POST /api/applications` (jobseeker only)
- `GET /api/applications/job/:jobId/me` (jobseeker only)
- `GET /api/applications/job/:jobId` (employer only)
- `PATCH /api/applications/:id` (employer only)
- `GET /api/applications/mine` (employer only)
- `GET /api/applications/my-applications` (jobseeker only)
- `GET /api/applications/:id` (employer or jobseeker who owns it)

Activities (requires login; role-based filtering)

- `GET /api/activities`
- `GET /api/activities/recent`
- `GET /api/activities/stats`

---

## Moderation behavior (important)

- If an **employer** is locked by admin, their posted jobs are hidden from public browsing and jobseekers cannot apply.
- Locked users are blocked from write operations and will see the admin lock message on login.
- Database stores only the file path (example: `/uploads/.../photo.jpg`).
- For resumes, database stores only the file path (example: `/uploads/resumes/jobseeker/<userId>/resume-<timestamp>.pdf`).
- If no photo is uploaded, the frontend displays a default placeholder avatar.

### Important note (how profile fields are stored)

- Profile data is stored as **embedded objects inside the `User` document** (no separate collections).
- Primary shape: `user.profile.common`, `user.profile.employer`, `user.profile.jobseeker`
- Compatibility mirrors also exist: `user.employerProfile` and `user.jobSeekerProfile`
- You read/write these via embedded objects (dot-notation), not through separate tables/collections.

### Where it appears in the product

- On job details page: jobseeker can open employer profile.
- On application details page: employer can open jobseeker profile.

Note: This feature is implemented in the current codebase.

---

## Related documents

- `ER_DIAGRAM.md` — ER diagram (Mermaid)
- `SCHEMA_DESIGN.md` — collection-by-collection schema + sample JSON
- `setup.md` — how to run locally
