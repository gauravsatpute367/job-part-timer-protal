# Activity Tracking System - Implementation Summary

## ✅ What Has Been Implemented

### 1. **Timestamps on All Models**

- ✅ **User Model**: Added `timestamps: true` - tracks user registration time
- ✅ **Job Model**: Already had `timestamps: true` - tracks job creation/updates
- ✅ **Application Model**: Already had `timestamps: true` - tracks application submission

### 2. **Status History Tracking**

- ✅ **Application Model**: Added `statusHistory` array
  - Records every status change (Applied → Accepted/Rejected)
  - Tracks who changed it (`changedBy`)
  - Records exact time of change (`changedAt`)

### 3. **Comprehensive Activity Logging System**

- ✅ **Activity Model**: New model to track ALL activities
  - User registrations
  - Job postings
  - Job updates/closures
  - Application submissions
  - Application acceptances/rejections

### 4. **Activity Logger Utility**

- ✅ **`activityLogger.js`**: Centralized logging function
  - Logs all activities with metadata
  - Includes user, target user, job, and application references
  - Stores additional context in metadata field

### 5. **Updated Controllers with Activity Logging**

- ✅ **Auth Controller**: Logs user registrations
- ✅ **Job Controller**: Logs job creation, updates, and closures
- ✅ **Application Controller**: Logs application submissions and status changes

### 6. **Activity API Endpoints**

New routes under `/api/activities`:

- ✅ `GET /api/activities` - Get filtered activities
  - Query params: `type`, `startDate`, `endDate`, `limit`
  - Role-based filtering (employers see their jobs' activities)
- ✅ `GET /api/activities/stats` - Get activity statistics
  - Returns counts by activity type
  - Supports date range filtering
- ✅ `GET /api/activities/recent` - Get last 10 recent activities
  - Used in dashboard

### 7. **Updated Dashboard**

- ✅ Dynamic Recent Activity section for employers
- ✅ Fetches from new `/api/activities/recent` endpoint
- ✅ Shows real-time activity feed

## 📊 Activity Types Tracked

| Activity Type           | When It Happens               | Who Can See It              |
| ----------------------- | ----------------------------- | --------------------------- |
| `user_registered`       | New user signs up             | Admin                       |
| `profile_updated`       | User updates profile / resume | Admin, That user            |
| `job_posted`            | Employer posts job            | Employer, Admin             |
| `job_updated`           | Employer edits job            | Employer, Admin             |
| `job_closed`            | Employer closes job           | Employer, Admin             |
| `application_submitted` | Job seeker applies            | Job seeker, Employer, Admin |
| `application_accepted`  | Employer accepts application  | Job seeker, Employer, Admin |
| `application_rejected`  | Employer rejects application  | Job seeker, Employer, Admin |
| `user_warned`           | Admin warns user              | Admin, Target user          |
| `user_locked`           | Admin locks user              | Admin, Target user          |
| `user_unlocked`         | Admin unlocks user            | Admin, Target user          |

## 🔍 Data Recorded for Each Activity

Note: `targetUser`, `job`, and `application` are included **only when relevant** to the activity type (e.g., `job_posted` includes `job`, while `user_registered` does not).

```javascript
{
  type: "application_submitted",
  user: ObjectId,              // Who performed the action
  targetUser: ObjectId,         // Who is affected (optional)
  job: ObjectId,               // Related job (optional)
  application: ObjectId,       // Related application (optional)
  description: "Applied for job: Frontend Developer",
  metadata: {                  // Additional context
    jobTitle: "Frontend Developer",
    company: "Tech Corp"
  },
  createdAt: Date,            // Automatic timestamp
  updatedAt: Date             // Automatic timestamp
}
```

## 🎯 Usage Examples

### Filter Activities by Date Range

```javascript
GET /api/activities?startDate=2025-01-01&endDate=2025-01-31
```

### Filter by Activity Type

```javascript
GET /api/activities?type=application_submitted
```

### Get Activity Statistics

```javascript
GET /api/activities/stats?startDate=2025-01-01&endDate=2025-12-31
```

### Get Recent Activities (Dashboard)

```javascript
GET / api / activities / recent;
```

## 🔐 Security & Privacy

- **Role-based filtering**: Users only see relevant activities
  - Employers see activities related to their jobs
  - Job seekers see only their own activities
  - Admins see all activities
- All endpoints require authentication
- Activity logs cannot be deleted (audit trail)

## 📝 Database Indexes

Activity model has indexes on:

- `user` + `createdAt` (for user activity timeline)
- `type` + `createdAt` (for filtering by type)
- `createdAt` (for chronological queries)

## ✨ Benefits

1. **Complete Audit Trail**: Every action is recorded with timestamp
2. **Analytics**: Can build reports, charts, and statistics
3. **User Activity Feeds**: Can show personalized activity streams
4. **Debugging**: Track what happened and when
5. **Compliance**: Meet data retention requirements
