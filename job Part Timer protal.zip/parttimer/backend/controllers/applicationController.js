import Application from "../models/Application.js";
import Job from "../models/Job.js";
import { logActivity } from "../utils/activityLogger.js";
import User from "../models/User.js";

const isCurrentlyLocked = (moderation) => {
  if (!moderation?.isLocked) return false;
  if (!moderation.lockedUntil) return true;
  return new Date(moderation.lockedUntil) > new Date();
};

/**
 * POST /api/applications
 * Job seeker applies to a job
 */
export const createApplication = async (req, res) => {
  try {
    // Role guard
    if (req.user.role !== "jobseeker") {
      return res.status(403).json({
        message: "Only job seekers can apply for jobs",
      });
    }

    const { jobId } = req.body;

    if (!jobId) {
      return res.status(400).json({
        message: "jobId is required",
      });
    }

    // Validate job exists
    const job = await Job.findById(jobId).select(
      "title company employerId status"
    );
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    // If employer is locked, job applications must be blocked.
    if (job.employerId) {
      const employer = await User.findById(job.employerId).select(
        "moderation role"
      );
      const employerLocked = isCurrentlyLocked(employer?.moderation);

      if (employerLocked) {
        return res.status(423).json({
          message:
            "This employer account is locked. Applications are temporarily disabled for this job.",
          locked: true,
        });
      }
    }

    // ✅ Prevent duplicate apply for same job & user
    const existing = await Application.findOne({
      job: jobId,
      jobSeeker: req.user.id,
    });
    if (existing) {
      return res
        .status(400)
        .json({ message: "You have already applied to this job" });
    }

    const application = await Application.create({
      job: jobId,
      jobSeeker: req.user.id, // ✅ Backend extracts from token
      statusHistory: [
        {
          status: "Applied",
          changedAt: new Date(),
          changedBy: req.user.id,
        },
      ],
    });

    // Log activity
    await logActivity({
      type: "application_submitted",
      user: req.user.id,
      targetUser: job?.employerId,
      job: jobId,
      application: application._id,
      description: `Applied for job: ${job?.title || "Unknown"}`,
      metadata: {
        jobTitle: job?.title,
        company: job?.company?.name,
      },
    });

    res.status(201).json({
      message: "Application submitted successfully",
      application,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to submit application",
      error: error.message,
    });
  }
};

/**
 * GET /api/applications/job/:jobId
 * Employer views applications for a job
 */
export const getApplicationsByJob = async (req, res) => {
  try {
    const applications = await Application.find({
      job: req.params.jobId,
    }).populate("jobSeeker", "name email");

    res.json(applications);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch applications",
      error: error.message,
    });
  }
};

/**
 * PATCH /api/applications/:id
 * Accept or Reject application
 */
export const updateApplicationStatus = async (req, res) => {
  try {
    const { status } = req.body;

    if (!["Accepted", "Rejected"].includes(status)) {
      return res.status(400).json({
        message: "Invalid status value",
      });
    }

    const application = await Application.findById(req.params.id).populate(
      "job",
      "title company employerId"
    );

    if (!application) {
      return res.status(404).json({
        message: "Application not found",
      });
    }

    // Update status and add to history
    application.status = status;
    application.statusHistory.push({
      status: status,
      changedAt: new Date(),
      changedBy: req.user.id,
    });

    await application.save();

    // Log activity
    await logActivity({
      type:
        status === "Accepted" ? "application_accepted" : "application_rejected",
      user: req.user.id,
      targetUser: application.jobSeeker,
      job: application.job._id,
      application: application._id,
      description: `Application ${status.toLowerCase()} for job: ${
        application.job?.title || "Unknown"
      }`,
      metadata: {
        jobTitle: application.job?.title,
        company: application.job?.company?.name,
        status,
      },
    });

    // Populate for response
    await application.populate("jobSeeker", "name email");

    res.json({
      message: `Application ${status}`,
      application,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update application",
      error: error.message,
    });
  }
};

/**
 * GET /api/applications/job/:jobId/me
 * Check if I have already applied to this job
 */
export const getMyApplicationForJob = async (req, res) => {
  try {
    if (req.user.role !== "jobseeker") {
      return res
        .status(403)
        .json({ message: "Only job seekers can view this" });
    }
    const existing = await Application.findOne({
      job: req.params.jobId,
      jobSeeker: req.user.id,
    });
    if (!existing) return res.json({ applied: false });
    return res.json({ applied: true, application: existing });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to check application", error: error.message });
  }
};

export const getEmployerApplications = async (req, res) => {
  try {
    const jobIds = await Job.find({ employerId: req.user.id }).distinct("_id");
    if (!jobIds.length) return res.json([]);
    const applications = await Application.find({ job: { $in: jobIds } })
      .populate("job", "title company locationType")
      .populate("jobSeeker", "name email")
      .sort({ createdAt: -1 });
    return res.json(applications);
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch applications", error: error.message });
  }
};

export const getApplicationById = async (req, res) => {
  try {
    const application = await Application.findById(req.params.id)
      .populate(
        "job",
        "title company locationType jobType duration payment description responsibilities requirements skills employerId"
      )
      .populate("jobSeeker", "name email");

    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }

    console.log(
      "Application jobSeeker ID:",
      application.jobSeeker._id.toString()
    );
    console.log("Logged in user ID:", req.user.id);
    console.log("Job employer ID:", application.job.employerId?.toString());

    // Authorization check: Allow if user is the employer OR the job seeker
    const isEmployer =
      application.job.employerId?.toString() === req.user.id.toString();
    const isJobSeeker =
      application.jobSeeker._id.toString() === req.user.id.toString();

    console.log("Is Employer:", isEmployer);
    console.log("Is JobSeeker:", isJobSeeker);

    if (!isEmployer && !isJobSeeker) {
      return res
        .status(403)
        .json({ message: "Not authorized to view this application" });
    }

    return res.json(application);
  } catch (error) {
    console.error("Error in getApplicationById:", error);
    return res
      .status(500)
      .json({ message: "Failed to fetch application", error: error.message });
  }
};

// Get all applications for the logged-in job seeker
export const getJobSeekerApplications = async (req, res) => {
  try {
    const applications = await Application.find({ jobSeeker: req.user.id })
      .populate("job", "title company locationType status")
      .sort({ createdAt: -1 });
    return res.json(applications);
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch applications", error: error.message });
  }
};
