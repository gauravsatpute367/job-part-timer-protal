import User from "../models/User.js";
import { logActivity } from "../utils/activityLogger.js";

const toStringArray = (value) => {
  if (Array.isArray(value)) {
    return value.map((v) => String(v).trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    return value
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean);
  }
  return [];
};

const pick = (obj, keys) => {
  const out = {};
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) out[key] = obj[key];
  }
  return out;
};

export const getMyProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select(
      "name email role profile profilePhotoPath resumePdfPath employerProfile jobSeekerProfile moderation"
    );
    if (!user) return res.status(404).json({ message: "User not found" });

    const employerProfile =
      user.employerProfile || user.profile?.employer || {};
    const jobSeekerProfile =
      user.jobSeekerProfile || user.profile?.jobseeker || {};

    return res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      moderation: user.moderation || {},
      profilePhotoPath: user.profilePhotoPath || "",
      resumePdfPath: user.resumePdfPath || "",
      employerProfile,
      jobSeekerProfile,
      // Backward-compatible shape for existing frontend
      profile: {
        ...(user.profile || {}),
        employer: employerProfile,
        jobseeker: jobSeekerProfile,
      },
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch profile", error: error.message });
  }
};

export const updateMyProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    const body = req.body || {};

    const requireText = (value, label) => {
      if (!String(value ?? "").trim()) return `${label} is required`;
      return null;
    };

    // Enforce mandatory fields for this official platform.
    // (We validate at the controller layer instead of making the schema required,
    // to avoid breaking unrelated saves like resume/photo upload or moderation updates.)
    const commonInput = body.common || {};
    {
      const message =
        requireText(commonInput.phone, "Phone") ||
        requireText(commonInput.location, "Location") ||
        requireText(commonInput.gender, "Gender") ||
        requireText(commonInput.birthDate, "Birth date") ||
        requireText(commonInput.bio, "Bio");
      if (message) return res.status(400).json({ message });
    }

    if (user.role === "jobseeker") {
      const jsPayload = body.jobseeker || body.jobSeekerProfile || {};
      const skills = toStringArray(jsPayload.skills);
      const message =
        requireText(jsPayload.headline, "Headline") ||
        requireText(jsPayload.city, "City") ||
        requireText(jsPayload.state, "State") ||
        (!skills.length ? "Skills is required" : null) ||
        requireText(jsPayload.education, "Education") ||
        requireText(jsPayload.experience, "Experience") ||
        requireText(jsPayload.portfolioUrl, "Portfolio URL");
      if (message) return res.status(400).json({ message });

      const nextResume =
        body.resumePdfPath !== undefined
          ? String(body.resumePdfPath || "")
          : String(user.resumePdfPath || "");
      if (!nextResume.trim()) {
        return res.status(400).json({ message: "Resume (PDF) is required" });
      }
    }

    if (user.role === "employer") {
      const empPayload = body.employer || body.employerProfile || {};
      const message =
        requireText(empPayload.companyName, "Company name") ||
        requireText(empPayload.industry, "Industry") ||
        requireText(empPayload.city, "City") ||
        requireText(empPayload.state, "State") ||
        requireText(empPayload.website, "Website") ||
        requireText(empPayload.companyLocation, "Company location") ||
        requireText(empPayload.about, "About");
      if (message) return res.status(400).json({ message });
    }

    if (body.profilePhotoPath !== undefined) {
      user.profilePhotoPath = String(body.profilePhotoPath || "");
    }

    if (body.resumePdfPath !== undefined && user.role === "jobseeker") {
      user.resumePdfPath = String(body.resumePdfPath || "");
    }

    const common = pick(body.common || {}, [
      "phone",
      "location",
      "gender",
      "birthDate",
      "usePrideAvatar",
      "avatarPreset",
      "bio",
    ]);

    // Gender is required for profile updates
    if (!String(common.gender || "").trim()) {
      return res.status(400).json({ message: "Gender is required" });
    }
    {
      const normalizedGender = String(common.gender).trim().toLowerCase();
      const allowedGenders = new Set(["male", "female", "other"]);
      if (!allowedGenders.has(normalizedGender)) {
        return res.status(400).json({ message: "Invalid gender value" });
      }
      common.gender = normalizedGender;
    }

    if (common.phone !== undefined)
      user.profile.common.phone = String(common.phone);
    if (common.location !== undefined)
      user.profile.common.location = String(common.location);
    if (common.gender !== undefined)
      user.profile.common.gender = String(common.gender);
    if (common.birthDate !== undefined)
      user.profile.common.birthDate = String(common.birthDate);
    if (common.usePrideAvatar !== undefined) {
      const requested = Boolean(common.usePrideAvatar);
      // Only meaningful for gender=other; otherwise force false.
      user.profile.common.usePrideAvatar =
        user.profile.common.gender === "other" ? requested : false;
    }
    if (common.avatarPreset !== undefined) {
      const preset = String(common.avatarPreset || "");
      const allowed = new Set([
        "MaleJobSeekerPic.jpg",
        "FemaleJobSeekerPic.jpg",
        "MaleEmployerPic.jpg",
        "FemaleEmployerPic.jpg",
      ]);
      user.profile.common.avatarPreset = allowed.has(preset) ? preset : "";

      // If user explicitly chooses a default avatar, we should not keep an uploaded path.
      if (user.profile.common.avatarPreset) {
        user.profilePhotoPath = "";
      }
    }
    if (common.bio !== undefined) user.profile.common.bio = String(common.bio);

    if (user.role === "jobseeker") {
      const jsPayload = body.jobseeker || body.jobSeekerProfile || {};
      const js = pick(jsPayload, [
        "headline",
        "city",
        "state",
        "skills",
        "education",
        "experience",
        "portfolioUrl",
      ]);

      if (js.headline !== undefined)
        user.profile.jobseeker.headline = String(js.headline);
      if (js.city !== undefined) user.profile.jobseeker.city = String(js.city);
      if (js.state !== undefined)
        user.profile.jobseeker.state = String(js.state);
      if (js.skills !== undefined)
        user.profile.jobseeker.skills = toStringArray(js.skills);
      if (js.education !== undefined)
        user.profile.jobseeker.education = String(js.education);
      if (js.experience !== undefined)
        user.profile.jobseeker.experience = String(js.experience);
      if (js.portfolioUrl !== undefined)
        user.profile.jobseeker.portfolioUrl = String(js.portfolioUrl);

      user.jobSeekerProfile = {
        ...user.jobSeekerProfile?.toObject?.(),
        ...pick(
          user.profile.jobseeker?.toObject?.() || user.profile.jobseeker,
          [
            "headline",
            "city",
            "state",
            "skills",
            "education",
            "experience",
            "portfolioUrl",
          ]
        ),
      };
    }

    if (user.role === "employer") {
      const empPayload = body.employer || body.employerProfile || {};
      const emp = pick(empPayload, [
        "companyName",
        "industry",
        "city",
        "state",
        "website",
        "about",
        "companyLocation",
      ]);

      if (emp.companyName !== undefined)
        user.profile.employer.companyName = String(emp.companyName);
      if (emp.industry !== undefined)
        user.profile.employer.industry = String(emp.industry);
      if (emp.city !== undefined) user.profile.employer.city = String(emp.city);
      if (emp.state !== undefined)
        user.profile.employer.state = String(emp.state);
      if (emp.website !== undefined)
        user.profile.employer.website = String(emp.website);
      if (emp.about !== undefined)
        user.profile.employer.about = String(emp.about);
      if (emp.companyLocation !== undefined)
        user.profile.employer.companyLocation = String(emp.companyLocation);

      user.employerProfile = {
        ...user.employerProfile?.toObject?.(),
        ...pick(user.profile.employer?.toObject?.() || user.profile.employer, [
          "companyName",
          "industry",
          "city",
          "state",
          "website",
          "about",
          "companyLocation",
        ]),
      };
    }

    await user.save();

    await logActivity({
      type: "profile_updated",
      user: req.user.id,
      description: `Profile updated: ${user.name}`,
      metadata: { role: user.role },
    });

    const fresh = await User.findById(req.user.id).select(
      "name email role profile profilePhotoPath resumePdfPath employerProfile jobSeekerProfile moderation"
    );

    const employerProfile =
      fresh.employerProfile || fresh.profile?.employer || {};
    const jobSeekerProfile =
      fresh.jobSeekerProfile || fresh.profile?.jobseeker || {};

    return res.json({
      message: "Profile saved",
      user: {
        id: fresh._id,
        name: fresh.name,
        email: fresh.email,
        role: fresh.role,
      },
      moderation: fresh.moderation || {},
      profilePhotoPath: fresh.profilePhotoPath || "",
      resumePdfPath: fresh.resumePdfPath || "",
      employerProfile,
      jobSeekerProfile,
      profile: {
        ...(fresh.profile || {}),
        employer: employerProfile,
        jobseeker: jobSeekerProfile,
      },
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to save profile", error: error.message });
  }
};

export const getUserProfileById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id).select(
      "name email role profile profilePhotoPath resumePdfPath employerProfile jobSeekerProfile moderation"
    );

    if (!user) return res.status(404).json({ message: "User not found" });

    const employerProfile =
      user.employerProfile || user.profile?.employer || {};
    const jobSeekerProfile =
      user.jobSeekerProfile || user.profile?.jobseeker || {};

    return res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      moderation: user.moderation || {},
      profilePhotoPath: user.profilePhotoPath || "",
      resumePdfPath: user.resumePdfPath || "",
      employerProfile,
      jobSeekerProfile,
      profile: {
        ...(user.profile || {}),
        employer: employerProfile,
        jobseeker: jobSeekerProfile,
      },
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch profile", error: error.message });
  }
};

export const uploadMyProfilePhoto = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // Convert absolute file path to a URL path under /uploads
    const normalized = String(req.file.path).replace(/\\/g, "/");
    const idx = normalized.lastIndexOf("/uploads/");
    const relative = idx >= 0 ? normalized.slice(idx) : "/uploads/";

    user.profilePhotoPath = relative;
    // Uploaded photo overrides any default preset
    if (user.profile?.common) user.profile.common.avatarPreset = "";
    await user.save();

    await logActivity({
      type: "profile_updated",
      user: req.user.id,
      description: `Profile photo updated: ${user.name}`,
      metadata: { role: user.role },
    });

    return res.json({
      message: "Profile photo uploaded",
      profilePhotoPath: user.profilePhotoPath,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to upload profile photo",
      error: error.message,
    });
  }
};

export const uploadMyResumePdf = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.role !== "jobseeker") {
      return res
        .status(403)
        .json({ message: "Access denied. Job seeker only." });
    }

    // Convert absolute file path to a URL path under /uploads
    const normalized = String(req.file.path).replace(/\\/g, "/");
    const idx = normalized.lastIndexOf("/uploads/");
    const relative = idx >= 0 ? normalized.slice(idx) : "/uploads/";

    user.resumePdfPath = relative;
    await user.save();

    await logActivity({
      type: "profile_updated",
      user: req.user.id,
      description: `Resume uploaded: ${user.name}`,
      metadata: { role: user.role },
    });

    return res.json({
      message: "Resume uploaded",
      resumePdfPath: user.resumePdfPath,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to upload resume",
      error: error.message,
    });
  }
};
