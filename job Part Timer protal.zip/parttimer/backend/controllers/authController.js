import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { logActivity } from "../utils/activityLogger.js";

export const adminExists = async (req, res) => {
  try {
    const exists = Boolean(await User.exists({ role: "admin" }));
    return res.json({ exists });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// REGISTER USER
export const registerUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // Only allow a single admin account to be registered.
    if (role === "admin") {
      const existingAdmin = await User.exists({ role: "admin" });
      if (existingAdmin) {
        return res.status(403).json({
          message: "Admin registration is disabled. An admin already exists.",
        });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      name,
      email,
      password: hashedPassword,
      role,
    });

    await user.save();

    // Log activity
    await logActivity({
      type: "user_registered",
      user: user._id,
      description: `New ${role} registered: ${name}`,
      metadata: { email, role },
    });

    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// LOGIN USER WITH JWT
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const moderation = user.moderation || {};
    const now = new Date();
    const isLocked =
      Boolean(moderation.isLocked) &&
      (!moderation.lockedUntil || new Date(moderation.lockedUntil) > now);

    // ✅ JWT generate HERE
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        email: user.email,
        moderation: {
          isLocked,
          lockedUntil: moderation.lockedUntil || null,
          message: moderation.message || "",
          reason: moderation.reason || "",
          warningMessage: moderation.warningMessage || "",
        },
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET ALL USERS (testing/admin)
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
