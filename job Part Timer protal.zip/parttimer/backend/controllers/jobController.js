import Job from "../models/Job.js";
import Application from "../models/Application.js";
import { logActivity } from "../utils/activityLogger.js";
import User from "../models/User.js";

const isCurrentlyLocked = (moderation) => {
  if (!moderation?.isLocked) return false;
  if (!moderation.lockedUntil) return true;
  return new Date(moderation.lockedUntil) > new Date();
};

const getLockedEmployerIds = async () => {
  const now = new Date();
  const lockedEmployers = await User.find({
    role: "employer",
    "moderation.isLocked": true,
    $or: [
      { "moderation.lockedUntil": null },
      { "moderation.lockedUntil": { $gt: now } },
    ],
  })
    .select("_id")
    .lean();

  return lockedEmployers.map((u) => u._id);
};

const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

const requireText = (value, label) => {
  if (!String(value ?? "").trim()) return `${label} is required`;
  return null;
};

const toStringArray = (value, mode) => {
  if (Array.isArray(value)) {
    return value.map((v) => String(v).trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    const parts = mode === "lines" ? value.split(/\r?\n/) : value.split(",");
    return parts.map((v) => v.trim()).filter(Boolean);
  }
  return [];
};

const normalizeJobBody = (body) => {
  const out = { ...(body || {}) };
  if (out.company && typeof out.company === "object") {
    out.company = { ...out.company };
  }
  if (out.payment && typeof out.payment === "object") {
    out.payment = { ...out.payment };
  }
  out.responsibilities = toStringArray(out.responsibilities, "lines");
  out.requirements = toStringArray(out.requirements, "lines");
  out.skills = toStringArray(out.skills, "csv");

  if (!out.applicationDetails || typeof out.applicationDetails !== "object") {
    out.applicationDetails = {};
  } else {
    out.applicationDetails = { ...out.applicationDetails };
  }

  if (out.applicationDetails.openings !== undefined) {
    out.applicationDetails.openings = Number(out.applicationDetails.openings);
  }

  return out;
};

const validateJobPayload = (payload, expiresAtValue) => {
  const message =
    requireText(payload.title, "Title") ||
    requireText(payload.jobType, "Job type") ||
    requireText(payload.locationType, "Location type") ||
    requireText(payload.duration, "Duration") ||
    requireText(payload.company?.name, "Company name") ||
    requireText(payload.company?.industry, "Company industry") ||
    requireText(payload.company?.city, "Company city") ||
    requireText(payload.company?.state, "Company state") ||
    requireText(payload.payment?.amount, "Payment amount") ||
    requireText(payload.payment?.type, "Payment type") ||
    requireText(payload.description, "Description") ||
    (!Array.isArray(payload.responsibilities) ||
    payload.responsibilities.length < 1
      ? "Responsibilities is required"
      : null) ||
    (!Array.isArray(payload.requirements) || payload.requirements.length < 1
      ? "Requirements is required"
      : null) ||
    (!Array.isArray(payload.skills) || payload.skills.length < 1
      ? "Skills is required"
      : null) ||
    (!Number.isFinite(payload.applicationDetails?.openings) ||
    payload.applicationDetails.openings < 1
      ? "Number of openings is required"
      : null) ||
    requireText(payload.applicationDetails?.lastDate, "Last date") ||
    (!expiresAtValue ? "Auto remove date (expiresAt) is required" : null);

  return message;
};

const parseExpiresAtFromBody = (body) => {
  // Supports either:
  // - expiresAt: ISO date string / Date
  // - autoRemoveAfterDays: number
  // If neither is present, returns { hasValue: false }.
  if (!body || typeof body !== "object") return { hasValue: false };

  if (hasOwn(body, "autoRemoveAfterDays") && !hasOwn(body, "expiresAt")) {
    const rawDays = body.autoRemoveAfterDays;
    if (rawDays === "" || rawDays === null || rawDays === undefined) {
      return { hasValue: true, value: null };
    }

    const days = Number(rawDays);
    if (!Number.isFinite(days) || days <= 0) {
      return { error: "autoRemoveAfterDays must be a positive number" };
    }
    return {
      hasValue: true,
      value: new Date(Date.now() + days * 24 * 60 * 60 * 1000),
    };
  }

  if (!hasOwn(body, "expiresAt")) return { hasValue: false };

  const raw = body.expiresAt;
  if (raw === "" || raw === null || raw === undefined) {
    return { hasValue: true, value: null };
  }

  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) {
    return { error: "Invalid expiresAt date" };
  }

  return { hasValue: true, value: parsed };
};

export const createJob = async (req, res) => {
  try {
    const expiresAtParsed = parseExpiresAtFromBody(req.body);
    if (expiresAtParsed.error) {
      return res.status(400).json({ message: expiresAtParsed.error });
    }

    if (!expiresAtParsed.hasValue || !expiresAtParsed.value) {
      return res
        .status(400)
        .json({ message: "Auto remove date (expiresAt) is required" });
    }

    const body = { ...req.body };
    delete body.autoRemoveAfterDays;
    delete body.expiresAt;

    const normalized = normalizeJobBody(body);
    const validationMessage = validateJobPayload(
      normalized,
      expiresAtParsed.value
    );
    if (validationMessage) {
      return res.status(400).json({ message: validationMessage });
    }

    const job = new Job({
      ...normalized,
      employerId: req.user.id,
      expiresAt: expiresAtParsed.value,
    });

    await job.save();

    // Log activity
    await logActivity({
      type: "job_posted",
      user: req.user.id,
      job: job._id,
      description: `Job posted: ${job.title}`,
      metadata: {
        company: job.company?.name,
        jobType: job.jobType,
        locationType: job.locationType,
      },
    });

    res.status(201).json({
      message: "Job created successfully",
      job,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      return res
        .status(400)
        .json({ message: "Validation failed", errors: error.errors });
    }
    res.status(500).json({ message: error.message });
  }
};

export const getAllJobs = async (req, res) => {
  try {
    // Admin can browse everything (even locked-employer jobs) for moderation.
    if (req.user?.role === "admin") {
      const jobs = await Job.find();
      return res.status(200).json(jobs);
    }

    // Hide jobs posted by currently-locked employers from public browsing.
    const lockedEmployerIds = await getLockedEmployerIds();
    const filter = lockedEmployerIds.length
      ? {
          $or: [
            { employerId: { $nin: lockedEmployerIds } },
            { employerId: { $exists: false } },
            { employerId: null },
          ],
        }
      : {};

    const jobs = await Job.find(filter);
    res.status(200).json(jobs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getJobById = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    // If the job's employer is currently locked, hide it from everyone except:
    // - admins (for investigation)
    // - the owning employer (so they can still view their own listing)
    if (job.employerId) {
      const employer = await User.findById(job.employerId).select(
        "role moderation"
      );

      const employerLocked = isCurrentlyLocked(employer?.moderation);
      const isAdmin = req.user?.role === "admin";
      const isOwnerEmployer =
        req.user?.role === "employer" &&
        String(req.user?.id) === String(job.employerId);

      if (employerLocked && !isAdmin && !isOwnerEmployer) {
        return res.status(404).json({ message: "Job not found" });
      }
    }

    res.status(200).json(job);
  } catch (error) {
    res.status(400).json({ message: "Invalid job ID" });
  }
};

export const getEmployerJobs = async (req, res) => {
  try {
    const employerId = req.user.id;

    const jobs = await Job.find({ employerId }).lean();

    const jobIds = jobs.map((j) => j._id);

    const counts = await Application.aggregate([
      { $match: { job: { $in: jobIds } } },
      { $group: { _id: "$job", count: { $sum: 1 } } },
    ]);

    const countMap = Object.fromEntries(
      counts.map((c) => [c._id.toString(), c.count])
    );

    const enrichedJobs = jobs.map((j) => ({
      ...j,
      applications: countMap[j._id.toString()] || 0,
    }));

    res.json(enrichedJobs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateJob = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const job = await Job.findByIdAndUpdate(id, { status }, { new: true });

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    // Log activity
    if (status === "Closed") {
      await logActivity({
        type: "job_closed",
        user: req.user.id,
        job: job._id,
        description: `Job closed: ${job.title}`,
        metadata: { previousStatus: job.status },
      });
    } else {
      await logActivity({
        type: "job_updated",
        user: req.user.id,
        job: job._id,
        description: `Job updated: ${job.title}`,
        metadata: { status },
      });
    }

    res.json({ message: "Job updated successfully", job });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateJobFull = async (req, res) => {
  try {
    const { id } = req.params;
    const employerId = req.user.id;

    const job = await Job.findById(id);
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    // Verify ownership
    if (job.employerId.toString() !== employerId) {
      return res
        .status(403)
        .json({ message: "Not authorized to edit this job" });
    }

    const expiresAtParsed = parseExpiresAtFromBody(req.body);
    if (expiresAtParsed.error) {
      return res.status(400).json({ message: expiresAtParsed.error });
    }

    if (!expiresAtParsed.hasValue || !expiresAtParsed.value) {
      return res
        .status(400)
        .json({ message: "Auto remove date (expiresAt) is required" });
    }

    const body = { ...req.body };
    delete body.autoRemoveAfterDays;
    delete body.expiresAt;

    const normalized = normalizeJobBody(body);
    const mergedCandidate = {
      title: normalized.title ?? job.title,
      jobType: normalized.jobType ?? job.jobType,
      locationType: normalized.locationType ?? job.locationType,
      duration: normalized.duration ?? job.duration,
      company: {
        ...(job.company?.toObject?.() || job.company || {}),
        ...(normalized.company || {}),
      },
      payment: {
        ...(job.payment?.toObject?.() || job.payment || {}),
        ...(normalized.payment || {}),
      },
      description: normalized.description ?? job.description,
      responsibilities:
        normalized.responsibilities?.length > 0
          ? normalized.responsibilities
          : job.responsibilities,
      requirements:
        normalized.requirements?.length > 0
          ? normalized.requirements
          : job.requirements,
      skills: normalized.skills?.length > 0 ? normalized.skills : job.skills,
      applicationDetails: {
        ...(job.applicationDetails?.toObject?.() ||
          job.applicationDetails ||
          {}),
        ...(normalized.applicationDetails || {}),
      },
    };

    const validationMessage = validateJobPayload(
      mergedCandidate,
      expiresAtParsed.value
    );
    if (validationMessage) {
      return res.status(400).json({ message: validationMessage });
    }

    // Update fields
    Object.assign(job, normalized);
    job.expiresAt = expiresAtParsed.value;
    await job.save();

    // Log activity
    await logActivity({
      type: "job_updated",
      user: req.user.id,
      job: job._id,
      description: `Job fully updated: ${job.title}`,
      metadata: { updatedFields: Object.keys(req.body) },
    });

    res.json({ message: "Job updated successfully", job });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
