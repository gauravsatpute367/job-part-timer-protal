import Activity from "../models/Activity.js";
import Job from "../models/Job.js";

/**
 * GET /api/activities
 * Get activities with optional filters
 * Query params: type, startDate, endDate, limit
 */
export const getActivities = async (req, res) => {
  try {
    const { type, startDate, endDate, limit = 50 } = req.query;
    const userId = req.user.id;
    const userRole = req.user.role;

    let query = {};

    // For employers: show their activities + activities on their jobs
    if (userRole === "employer") {
      const employerJobs = await Job.find({ employerId: userId }).distinct(
        "_id"
      );
      query.$or = [
        { user: userId },
        { targetUser: userId },
        { job: { $in: employerJobs } },
      ];
    }
    // For job seekers: show only their activities
    else if (userRole === "jobseeker") {
      query.$or = [{ user: userId }, { targetUser: userId }];
    }
    // For admin: show all activities
    // (no filter needed)

    // Apply optional filters
    if (type) {
      query.type = type;
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const activities = await Activity.find(query)
      .populate("user", "name email role")
      .populate("targetUser", "name email role")
      .populate("job", "title company")
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json(activities);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch activities",
      error: error.message,
    });
  }
};

/**
 * GET /api/activities/stats
 * Get activity statistics
 */
export const getActivityStats = async (req, res) => {
  try {
    const userId = req.user.id;
    const userRole = req.user.role;
    const { startDate, endDate } = req.query;

    let matchQuery = {};

    // Apply role-based filtering
    if (userRole === "employer") {
      const employerJobs = await Job.find({ employerId: userId }).distinct(
        "_id"
      );
      matchQuery.$or = [
        { user: userId },
        { targetUser: userId },
        { job: { $in: employerJobs } },
      ];
    } else if (userRole === "jobseeker") {
      matchQuery.$or = [{ user: userId }, { targetUser: userId }];
    }

    // Apply date filtering
    if (startDate || endDate) {
      matchQuery.createdAt = {};
      if (startDate) matchQuery.createdAt.$gte = new Date(startDate);
      if (endDate) matchQuery.createdAt.$lte = new Date(endDate);
    }

    // Aggregate stats by type
    const stats = await Activity.aggregate([
      { $match: matchQuery },
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 },
        },
      },
    ]);

    // Get total count
    const total = await Activity.countDocuments(matchQuery);

    res.json({
      total,
      byType: stats.reduce((acc, item) => {
        acc[item._id] = item.count;
        return acc;
      }, {}),
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch activity stats",
      error: error.message,
    });
  }
};

/**
 * GET /api/activities/recent
 * Get recent activities (last 10)
 */
export const getRecentActivities = async (req, res) => {
  try {
    const userId = req.user.id;
    const userRole = req.user.role;
    const limit = Number(req.query.limit) || 10;

    let query = {};

    if (userRole === "employer") {
      // For the employer dashboard recent activity, show ONLY actions
      // performed by the logged-in employer (not all actions happening
      // on their jobs by other users).
      query.user = userId;
    } else if (userRole === "jobseeker") {
      query.$or = [{ user: userId }, { targetUser: userId }];
    }

    const activities = await Activity.find(query)
      .populate("user", "name")
      .populate("job", "title")
      .sort({ createdAt: -1 })
      .limit(limit)
      .select("type description createdAt");

    res.json(activities);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch recent activities",
      error: error.message,
    });
  }
};
