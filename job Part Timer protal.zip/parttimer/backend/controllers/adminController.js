import User from "../models/User.js";
import Job from "../models/Job.js";
import Application from "../models/Application.js";
import { logActivity } from "../utils/activityLogger.js";

const isCurrentlyLocked = (moderation) => {
  if (!moderation?.isLocked) return false;
  if (!moderation.lockedUntil) return true;
  return new Date(moderation.lockedUntil) > new Date();
};

const requireText = (value, label) => {
  if (!String(value ?? "").trim()) return `${label} is required`;
  return null;
};

// GET ALL EMPLOYERS WITH JOB COUNT
export const getAllEmployers = async (req, res) => {
  try {
    const employers = await User.find({ role: "employer" }).select(
      "name email"
    );

    const employerIds = employers.map((emp) => emp._id);

    const jobCounts = await Job.aggregate([
      { $match: { employerId: { $in: employerIds } } },
      { $group: { _id: "$employerId", count: { $sum: 1 } } },
    ]);

    const jobCountMap = Object.fromEntries(
      jobCounts.map((jc) => [jc._id.toString(), jc.count])
    );

    const enrichedEmployers = employers.map((emp) => ({
      _id: emp._id,
      name: emp.name,
      email: emp.email,
      jobsPosted: jobCountMap[emp._id.toString()] || 0,
    }));

    res.json(enrichedEmployers);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to fetch employers", error: error.message });
  }
};

// GET ALL JOB SEEKERS WITH APPLICATION COUNT
export const getAllJobSeekers = async (req, res) => {
  try {
    const jobSeekers = await User.find({ role: "jobseeker" }).select(
      "name email"
    );

    const jobSeekerIds = jobSeekers.map((js) => js._id);

    const appCounts = await Application.aggregate([
      { $match: { jobSeeker: { $in: jobSeekerIds } } },
      { $group: { _id: "$jobSeeker", count: { $sum: 1 } } },
    ]);

    const appCountMap = Object.fromEntries(
      appCounts.map((ac) => [ac._id.toString(), ac.count])
    );

    const enrichedJobSeekers = jobSeekers.map((js) => ({
      _id: js._id,
      name: js.name,
      email: js.email,
      applications: appCountMap[js._id.toString()] || 0,
    }));

    res.json(enrichedJobSeekers);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to fetch job seekers", error: error.message });
  }
};

// GET ADMIN DASHBOARD STATS
export const getAdminStats = async (req, res) => {
  try {
    const [totalEmployers, totalJobSeekers, totalJobs, totalApplications] =
      await Promise.all([
        User.countDocuments({ role: "employer" }),
        User.countDocuments({ role: "jobseeker" }),
        Job.countDocuments(),
        Application.countDocuments(),
      ]);

    return res.json({
      totalEmployers,
      totalJobSeekers,
      totalJobs,
      totalApplications,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch admin stats", error: error.message });
  }
};

// ADMIN: Get all jobs (with employer and application counts)
// GET /api/auth/admin/jobs
export const getAllJobsForAdmin = async (req, res) => {
  try {
    const jobs = await Job.find()
      .populate("employerId", "name email")
      .sort({ createdAt: -1 })
      .lean();

    const jobIds = jobs.map((j) => j._id);
    const counts = jobIds.length
      ? await Application.aggregate([
          { $match: { job: { $in: jobIds } } },
          { $group: { _id: "$job", count: { $sum: 1 } } },
        ])
      : [];

    const countMap = Object.fromEntries(
      counts.map((c) => [c._id.toString(), c.count])
    );

    const enriched = jobs.map((j) => ({
      ...j,
      applications: countMap[j._id.toString()] || 0,
    }));

    return res.json({ jobs: enriched });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch jobs", error: error.message });
  }
};

// ADMIN: Get all applications
// GET /api/auth/admin/applications
export const getAllApplicationsForAdmin = async (req, res) => {
  try {
    const applications = await Application.find()
      .populate("job", "title company status")
      .populate("jobSeeker", "name email")
      .sort({ createdAt: -1 })
      .lean();

    return res.json({ applications });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to fetch applications",
      error: error.message,
    });
  }
};

// ADMIN: Get applications for a specific jobseeker
// GET /api/auth/admin/jobseekers/:id/applications
export const getJobSeekerApplicationsForAdmin = async (req, res) => {
  try {
    const { id } = req.params;

    const jobSeeker = await User.findById(id).select("name email role");
    if (!jobSeeker) return res.status(404).json({ message: "User not found" });
    if (jobSeeker.role !== "jobseeker") {
      return res.status(400).json({ message: "User is not a jobseeker" });
    }

    const applications = await Application.find({ jobSeeker: id })
      .populate("job", "title company status employerId")
      .sort({ createdAt: -1 });

    return res.json({
      jobSeeker: {
        id: jobSeeker._id,
        name: jobSeeker.name,
        email: jobSeeker.email,
      },
      applications,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to fetch jobseeker applications",
      error: error.message,
    });
  }
};

// ADMIN: Get jobs posted by a specific employer (with application counts)
// GET /api/auth/admin/employers/:id/jobs
export const getEmployerJobsForAdmin = async (req, res) => {
  try {
    const { id } = req.params;

    const employer = await User.findById(id).select("name email role");
    if (!employer) return res.status(404).json({ message: "User not found" });
    if (employer.role !== "employer") {
      return res.status(400).json({ message: "User is not an employer" });
    }

    const jobs = await Job.find({ employerId: id }).lean();
    const jobIds = jobs.map((j) => j._id);

    const counts = jobIds.length
      ? await Application.aggregate([
          { $match: { job: { $in: jobIds } } },
          { $group: { _id: "$job", count: { $sum: 1 } } },
        ])
      : [];

    const countMap = Object.fromEntries(
      counts.map((c) => [c._id.toString(), c.count])
    );

    const enrichedJobs = jobs.map((j) => ({
      ...j,
      applications: countMap[j._id.toString()] || 0,
    }));

    return res.json({
      employer: {
        id: employer._id,
        name: employer.name,
        email: employer.email,
      },
      jobs: enrichedJobs,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to fetch employer jobs", error: error.message });
  }
};

// ADMIN: Warn a user (does not lock)
// POST /api/auth/admin/users/:id/warn
export const warnUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { message = "", reason = "" } = req.body || {};

    // If message is empty, treat it as a clear-warning request.
    const isClearing = !String(message || "").trim();
    if (!isClearing) {
      const validationMessage =
        requireText(message, "Warning message") ||
        requireText(reason, "Reason");
      if (validationMessage) {
        return res.status(400).json({ message: validationMessage });
      }
    }

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.role === "admin") {
      return res.status(400).json({ message: "Cannot warn an admin user" });
    }

    user.moderation.warningMessage = String(message || "");
    user.moderation.warnedAt = new Date();
    user.moderation.warnedBy = req.user.id;
    if (!isClearing) {
      user.moderation.reason = String(reason || "");
    }

    await user.save();

    await logActivity({
      type: "user_warned",
      user: req.user.id,
      targetUser: user._id,
      description: `User warned: ${user.name}`,
      metadata: {
        role: user.role,
        reason: String(reason || ""),
        message: String(message || ""),
      },
    });

    return res.json({
      message: "User warned",
      moderation: user.moderation,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to warn user", error: error.message });
  }
};

// ADMIN: Lock a user (optional time-based)
// POST /api/auth/admin/users/:id/lock
export const lockUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { lockDays, lockedUntil, message = "", reason = "" } = req.body || {};

    const validationMessage =
      requireText(message, "Lock message") || requireText(reason, "Reason");
    if (validationMessage) {
      return res.status(400).json({ message: validationMessage });
    }

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.role === "admin") {
      return res.status(400).json({ message: "Cannot lock an admin user" });
    }

    let until = null;
    if (lockedUntil) {
      const parsed = new Date(lockedUntil);
      if (Number.isNaN(parsed.getTime())) {
        return res.status(400).json({ message: "Invalid lockedUntil date" });
      }
      until = parsed;
    } else if (
      lockDays !== undefined &&
      lockDays !== null &&
      String(lockDays).trim() !== ""
    ) {
      const days = Number(lockDays);
      if (!Number.isFinite(days) || days <= 0) {
        return res
          .status(400)
          .json({ message: "lockDays must be a positive number" });
      }
      until = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    }

    if (!until) {
      return res.status(400).json({
        message: "Lock duration is required (lockDays or lockedUntil)",
      });
    }

    user.moderation.isLocked = true;
    user.moderation.lockedUntil = until;
    user.moderation.message = String(message || "");
    user.moderation.reason = String(reason || "");
    user.moderation.lockedAt = new Date();
    user.moderation.lockedBy = req.user.id;

    await user.save();

    await logActivity({
      type: "user_locked",
      user: req.user.id,
      targetUser: user._id,
      description: `User locked: ${user.name}`,
      metadata: {
        role: user.role,
        lockedUntil: until,
        reason: String(reason || ""),
        message: String(message || ""),
      },
    });

    return res.json({
      message: "User locked",
      locked: isCurrentlyLocked(user.moderation),
      moderation: user.moderation,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to lock user", error: error.message });
  }
};

// ADMIN: Unlock a user
// POST /api/auth/admin/users/:id/unlock
export const unlockUser = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.role === "admin") {
      return res.status(400).json({ message: "Cannot unlock an admin user" });
    }

    user.moderation.isLocked = false;
    user.moderation.lockedUntil = null;
    user.moderation.message = "";
    user.moderation.reason = "";
    user.moderation.lockedAt = null;
    user.moderation.lockedBy = null;

    await user.save();

    await logActivity({
      type: "user_unlocked",
      user: req.user.id,
      targetUser: user._id,
      description: `User unlocked: ${user.name}`,
      metadata: { role: user.role },
    });

    return res.json({
      message: "User unlocked",
      locked: isCurrentlyLocked(user.moderation),
      moderation: user.moderation,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to unlock user", error: error.message });
  }
};
