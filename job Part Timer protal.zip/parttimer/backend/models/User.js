import mongoose from "mongoose";

const commonProfileSchema = new mongoose.Schema(
  {
    phone: { type: String, default: "" },
    location: { type: String, default: "" },
    gender: { type: String, default: "" },
    birthDate: { type: String, default: "" },
    usePrideAvatar: { type: Boolean, default: false },
    // Stores only a preset key/filename (not the image bytes)
    avatarPreset: { type: String, default: "" },
    bio: { type: String, default: "" },
  },
  { _id: false }
);

const jobSeekerProfileSchema = new mongoose.Schema(
  {
    headline: { type: String, default: "" },
    city: { type: String, default: "" },
    state: { type: String, default: "" },
    skills: { type: [String], default: [] },
    education: { type: String, default: "" },
    experience: { type: String, default: "" },
    portfolioUrl: { type: String, default: "" },
  },
  { _id: false }
);

const employerProfileSchema = new mongoose.Schema(
  {
    companyName: { type: String, default: "" },
    industry: { type: String, default: "" },
    city: { type: String, default: "" },
    state: { type: String, default: "" },
    website: { type: String, default: "" },
    about: { type: String, default: "" },
    companyLocation: { type: String, default: "" },
  },
  { _id: false }
);

const moderationSchema = new mongoose.Schema(
  {
    isLocked: { type: Boolean, default: false },
    lockedUntil: { type: Date, default: null },
    message: { type: String, default: "" },
    reason: { type: String, default: "" },
    lockedAt: { type: Date, default: null },
    lockedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    warningMessage: { type: String, default: "" },
    warnedAt: { type: Date, default: null },
    warnedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
    },

    password: {
      type: String,
      required: true,
    },

    role: {
      type: String,
      enum: ["admin", "employer", "jobseeker"],
      required: true,
    },

    // Planned in docs: local server path for user profile photo/logo
    profilePhotoPath: {
      type: String,
      default: "",
    },

    // Local server path for uploaded jobseeker resume PDF
    resumePdfPath: {
      type: String,
      default: "",
    },

    // Doc-aligned embedded profiles (kept for schema/report consistency)
    employerProfile: {
      type: employerProfileSchema,
      default: () => ({}),
    },
    jobSeekerProfile: {
      type: jobSeekerProfileSchema,
      default: () => ({}),
    },

    // Resume-style profile data (editable)
    profile: {
      common: { type: commonProfileSchema, default: () => ({}) },
      jobseeker: { type: jobSeekerProfileSchema, default: () => ({}) },
      employer: { type: employerProfileSchema, default: () => ({}) },
    },

    // Admin moderation controls
    moderation: {
      type: moderationSchema,
      default: () => ({}),
    },
  },
  { timestamps: true }
);

export default mongoose.model("User", userSchema);
