import mongoose from "mongoose";

const applicationSchema = new mongoose.Schema(
  {
    job: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Job",
      required: true,
    },

    jobSeeker: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    status: {
      type: String,
      enum: ["Applied", "Accepted", "Rejected"],
      default: "Applied",
    },

    statusHistory: [
      {
        status: {
          type: String,
          enum: ["Applied", "Accepted", "Rejected"],
        },
        changedAt: {
          type: Date,
          default: Date.now,
        },
        changedBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
      },
    ],
  },
  { timestamps: true }
);

// Creates a unique compound index on (job, jobSeeker).
// Prevents a user from inserting a second application for the same job.
// Mongo will throw a duplicate key error if attempted.
applicationSchema.index({ job: 1, jobSeeker: 1 }, { unique: true });

export default mongoose.model("Application", applicationSchema);
