import mongoose from "mongoose";

const activitySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: [
        "user_registered",
        "profile_updated",
        "user_warned",
        "user_locked",
        "user_unlocked",
        "job_posted",
        "job_updated",
        "job_closed",
        "application_submitted",
        "application_accepted",
        "application_rejected",
      ],
      required: true,
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    targetUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    job: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Job",
    },

    application: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Application",
    },

    description: {
      type: String,
      required: true,
    },

    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  { timestamps: true }
);

// Index for faster queries
activitySchema.index({ user: 1, createdAt: -1 });
activitySchema.index({ type: 1, createdAt: -1 });
activitySchema.index({ createdAt: -1 });

export default mongoose.model("Activity", activitySchema);
