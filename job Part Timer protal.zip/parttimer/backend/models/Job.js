import mongoose from "mongoose";

const jobSchema = new mongoose.Schema(
  {
    title: String,
    jobType: String,
    locationType: String,
    duration: String,
    status: {
      type: String,
      enum: ["Active", "Closed"],
      default: "Active",
    },

    company: {
      name: {
        type: String,
        required: true,
      },
      industry: String,
      city: String,
      state: String,
    },

    payment: {
      amount: {
        type: String,
        required: true,
      },
      type: {
        type: String,
        required: true,
      },
    },

    description: String,
    responsibilities: [String],
    requirements: [String],
    skills: [String],

    applicationDetails: {
      openings: Number,
      lastDate: String,
    },

    // Optional TTL-based auto-removal. When set, MongoDB will automatically
    // delete the job after this date/time.
    expiresAt: {
      type: Date,
      default: null,
      expires: 0,
    },

    employerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Job", jobSchema);
