import Activity from "../models/Activity.js";

/**
 * Log activity to database
 * @param {Object} params - Activity parameters
 * @param {String} params.type - Activity type (user_registered, job_posted, etc.)
 * @param {String} params.user - User ID who performed the action
 * @param {String} params.description - Human-readable description
 * @param {String} params.targetUser - Optional: User affected by action
 * @param {String} params.job - Optional: Job ID related to action
 * @param {String} params.application - Optional: Application ID related to action
 * @param {Object} params.metadata - Optional: Additional data
 */
export const logActivity = async ({
  type,
  user,
  description,
  targetUser = null,
  job = null,
  application = null,
  metadata = {},
}) => {
  try {
    await Activity.create({
      type,
      user,
      targetUser,
      job,
      application,
      description,
      metadata,
    });
  } catch (error) {
    console.error("Failed to log activity:", error);
    // Don't throw error - logging failures shouldn't break main flow
  }
};
