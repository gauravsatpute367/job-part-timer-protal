import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import connectDB from "./config/db.js";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Static files (uploaded profile photos)
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"), {
    setHeaders: (res, filePath) => {
      if (String(filePath).toLowerCase().endsWith(".pdf")) {
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", 'inline; filename="resume.pdf"');
        res.setHeader("X-Content-Type-Options", "nosniff");
      }
    },
  })
);

connectDB();

app.get("/", (req, res) => {
  res.send("PartTimer Backend Running");
});

// ✅ ONLY AUTH ROUTES FOR NOW
import authRoutes from "./routes/authRoutes.js";
app.use("/api/auth", authRoutes);
import jobRoutes from "./routes/jobRoutes.js";
app.use("/api/jobs", jobRoutes);
import applicationRoutes from "./routes/applicationRoutes.js";
app.use("/api/applications", applicationRoutes);
import activityRoutes from "./routes/activityRoutes.js";
app.use("/api/activities", activityRoutes);

import userRoutes from "./routes/userRoutes.js";
app.use("/api/users", userRoutes);

// ❌ TEMPORARILY REMOVE THESE
// import jobRoutes from "./routes/jobRoutes.js";
// import applicationRoutes from "./routes/applicationRoutes.js";

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
