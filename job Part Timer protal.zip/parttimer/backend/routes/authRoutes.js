import express from "express";
import {
  adminExists,
  registerUser,
  getAllUsers,
  loginUser,
} from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";
import {
  getAllEmployers,
  getAllJobSeekers,
  getAdminStats,
  getAllJobsForAdmin,
  getAllApplicationsForAdmin,
  getJobSeekerApplicationsForAdmin,
  getEmployerJobsForAdmin,
  warnUser,
  lockUser,
  unlockUser,
} from "../controllers/adminController.js";
import { adminOnly } from "../middleware/roleMiddleware.js";

const router = express.Router();

// Public helper: check if an admin account already exists
router.get("/admin/exists", adminExists);

// Register user (admin / employer / jobseeker)
router.post("/register", registerUser);

router.post("/login", loginUser);

// Get all users (testing/admin)
router.get("/", getAllUsers);

router.get("/protected-test", protect, (req, res) => {
  res.json({
    message: "Access granted",
    user: req.user,
  });
});

// ADMIN ROUTES
router.get("/admin/employers", protect, adminOnly, getAllEmployers);
router.get("/admin/jobseekers", protect, adminOnly, getAllJobSeekers);
router.get("/admin/stats", protect, adminOnly, getAdminStats);
router.get("/admin/jobs", protect, adminOnly, getAllJobsForAdmin);
router.get(
  "/admin/applications",
  protect,
  adminOnly,
  getAllApplicationsForAdmin
);

// Admin drill-down views
router.get(
  "/admin/jobseekers/:id/applications",
  protect,
  adminOnly,
  getJobSeekerApplicationsForAdmin
);
router.get(
  "/admin/employers/:id/jobs",
  protect,
  adminOnly,
  getEmployerJobsForAdmin
);

// Admin moderation actions
router.post("/admin/users/:id/warn", protect, adminOnly, warnUser);
router.post("/admin/users/:id/lock", protect, adminOnly, lockUser);
router.post("/admin/users/:id/unlock", protect, adminOnly, unlockUser);

export default router;
