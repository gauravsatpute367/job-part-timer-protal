import express from "express";
import {
  getActivities,
  getActivityStats,
  getRecentActivities,
} from "../controllers/activityController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// All routes require authentication
router.get("/", protect, getActivities);
router.get("/stats", protect, getActivityStats);
router.get("/recent", protect, getRecentActivities);

export default router;
