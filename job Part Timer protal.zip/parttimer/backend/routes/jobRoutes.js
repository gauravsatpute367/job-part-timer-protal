import express from "express";
import {
  createJob,
  getAllJobs,
  getJobById,
  getEmployerJobs,
  updateJob,
  updateJobFull,
} from "../controllers/jobController.js";
import { protect } from "../middleware/authMiddleware.js";
import { employerOnly } from "../middleware/roleMiddleware.js";
import { optionalAuth } from "../middleware/optionalAuthMiddleware.js";

const router = express.Router();

router.post("/", protect, employerOnly, createJob);
router.get("/", optionalAuth, getAllJobs);
router.get("/mine", protect, employerOnly, getEmployerJobs); // MUST be before :id
router.get("/:id", optionalAuth, getJobById);
router.patch("/:id", protect, employerOnly, updateJob); // update job status
router.put("/:id", protect, employerOnly, updateJobFull); // full job update

export default router;
