import express from "express";
import {
  createApplication,
  getApplicationsByJob,
  updateApplicationStatus,
  getMyApplicationForJob,
  getEmployerApplications,
  getApplicationById,
  getJobSeekerApplications,
} from "../controllers/applicationController.js";
import { protect } from "../middleware/authMiddleware.js";
import { employerOnly, jobSeekerOnly } from "../middleware/roleMiddleware.js";

const router = express.Router();

// Apply for a job (jobseeker only handled inside controller)
router.post("/", protect, createApplication);

// Check if current jobseeker already applied
router.get("/job/:jobId/me", protect, jobSeekerOnly, getMyApplicationForJob);

// Get applications for a specific job (employer only)
router.get("/job/:jobId", protect, employerOnly, getApplicationsByJob);

// Accept/Reject application (employer only)
router.patch("/:id", protect, employerOnly, updateApplicationStatus);

// ⚠️ IMPORTANT: Specific routes MUST come before dynamic :id routes
// Get all applications for the logged-in employer
router.get("/mine", protect, employerOnly, getEmployerApplications);

// Get all applications for the logged-in jobseeker
router.get(
  "/my-applications",
  protect,
  jobSeekerOnly,
  getJobSeekerApplications
);

// Get single application by ID (employer OR jobseeker can view their own)
// ⚠️ This MUST be last because /:id will match anything
router.get("/:id", protect, getApplicationById);

export default router;
