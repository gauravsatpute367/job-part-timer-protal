import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import {
  uploadProfilePhoto,
  uploadResumePdf,
} from "../middleware/uploadMiddleware.js";
import { jobSeekerOnly } from "../middleware/roleMiddleware.js";
import {
  getMyProfile,
  updateMyProfile,
  getUserProfileById,
  uploadMyProfilePhoto,
  uploadMyResumePdf,
} from "../controllers/userController.js";

const router = express.Router();

// Logged-in user's profile
router.get("/me/profile", protect, getMyProfile);
router.put("/me/profile", protect, updateMyProfile);

// Local profile photo upload
router.post(
  "/me/profile-photo",
  protect,
  uploadProfilePhoto.single("photo"),
  uploadMyProfilePhoto
);

// Jobseeker resume upload (PDF)
router.post(
  "/me/resume",
  protect,
  jobSeekerOnly,
  uploadResumePdf.single("resume"),
  uploadMyResumePdf
);

// Other user's profile (requires login)
router.get("/:id/profile", protect, getUserProfileById);

export default router;
