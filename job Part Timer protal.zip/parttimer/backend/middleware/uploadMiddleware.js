import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const safeExt = (originalname) => {
  const ext = path.extname(originalname || "").toLowerCase();
  // allow common image extensions only
  const allowed = new Set([".png", ".jpg", ".jpeg", ".webp"]);
  return allowed.has(ext) ? ext : ".jpg";
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userId = req.user?.id;
    const role = req.user?.role || "user";
    const dest = path.join(
      __dirname,
      "..",
      "uploads",
      "profile-photos",
      role,
      String(userId)
    );
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = safeExt(file.originalname);
    const name = `photo-${Date.now()}${ext}`;
    cb(null, name);
  },
});

const fileFilter = (req, file, cb) => {
  if (!file?.mimetype?.startsWith("image/")) {
    return cb(new Error("Only image uploads are allowed"), false);
  }
  cb(null, true);
};

export const uploadProfilePhoto = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

const safePdfExt = (originalname) => {
  const ext = path.extname(originalname || "").toLowerCase();
  return ext === ".pdf" ? ".pdf" : ".pdf";
};

const resumeStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userId = req.user?.id;
    const dest = path.join(
      __dirname,
      "..",
      "uploads",
      "resumes",
      "jobseeker",
      String(userId)
    );
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = safePdfExt(file.originalname);
    const name = `resume-${Date.now()}${ext}`;
    cb(null, name);
  },
});

const resumeFileFilter = (req, file, cb) => {
  const mimetype = String(file?.mimetype || "").toLowerCase();
  const ext = path.extname(file?.originalname || "").toLowerCase();
  if (mimetype !== "application/pdf" && ext !== ".pdf") {
    return cb(new Error("Only PDF resume uploads are allowed"), false);
  }
  cb(null, true);
};

export const uploadResumePdf = multer({
  storage: resumeStorage,
  fileFilter: resumeFileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});
