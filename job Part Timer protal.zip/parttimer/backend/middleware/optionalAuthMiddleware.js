import jwt from "jsonwebtoken";

// Optional auth: if a valid Bearer token is provided, attach minimal req.user.
// If missing/invalid, continue without failing (for public routes).
export const optionalAuth = (req, _res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next();
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded?.id && decoded?.role) {
      req.user = { id: decoded.id, role: decoded.role };
    }
  } catch {
    // Ignore invalid tokens for public endpoints.
  }

  return next();
};
