import jwt from "jsonwebtoken";
import User from "../models/User.js";

export const protect = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Not authorized" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.id).select("role moderation");
    if (!user) {
      return res.status(401).json({ message: "Not authorized" });
    }

    const moderation = user.moderation || {};
    const now = new Date();
    const isLocked =
      Boolean(moderation.isLocked) &&
      (!moderation.lockedUntil || new Date(moderation.lockedUntil) > now);

    // Block non-admin locked accounts from write operations.
    const isWriteMethod = !["GET", "HEAD", "OPTIONS"].includes(req.method);
    if (user.role !== "admin" && isLocked && isWriteMethod) {
      return res.status(423).json({
        message:
          moderation.message ||
          "Your profile is locked due to suspicious/unethical activity.",
        locked: true,
        lockedUntil: moderation.lockedUntil || null,
        reason: moderation.reason || "",
      });
    }

    req.user = {
      id: user._id,
      role: user.role,
      moderation: {
        isLocked,
        lockedUntil: moderation.lockedUntil || null,
        message: moderation.message || "",
        reason: moderation.reason || "",
        warningMessage: moderation.warningMessage || "",
      },
    };
    next();
  } catch (err) {
    return res.status(401).json({ message: "Token invalid" });
  }
};
